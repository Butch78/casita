# casita

A generic, verified content-addressed object repository written in Rust.

Casita stores immutable object graphs without forcing every format into one
filesystem-shaped model. Filesystem trees, IPLD, and native Git
objects keep their own identities while sharing the same publication, named
roots, synchronization, collection, and integrity machinery.

Runs on Linux, macOS, and Windows. The minimum supported Rust version is 1.94.1.

## Architecture

```mermaid
%%{init: {"themeCSS": ".edgeLabel p { padding: 3px 10px; }"}}%%
flowchart TD
    FS["filesystem import / checkout"] --> API
    Git["native Git import / view / fetch"] --> API
    Custom["IPLD and custom ObjectFormat publications"] --> API

    API["Repository API"] --> Repo["Repository&lt;PS, SS&gt;"]
    Inspect["object / tree / root inspection"] --> API
    GC["collect / preview_collection"] -->|collector ownership| Repo
    Audit["fsck"] -->|online snapshot pin| Repo

    Local["local repository"] --> Source["TransferSource"]
    SSH["ssh:// source"] -->|OpenSSH authenticated channel| Source
    Source -->|one held revision| Sync["sync operation<br/>receiver protocol"]
    Sync -->|receiver-verified publication| Repo

    Repo --> Formats["FormatRegistry<br/>identity + canonical links"]
    Repo --> State[["MetadataStore"]]
    Repo --> Payloads[["BlobStore"]]
    Repo --> Coordination["mutation / read / collection coordination"]

    State --> Revision["RepositoryRevision"]
    State --> Roots["RootName → ObjectKey"]
    State --> Records["ObjectRecord<br/>key + payload + size + links"]
    Roots -->|retains closure| Records
    Records -->|forward links| Records
    Records -->|BlobId| Payloads
    Payloads --> Physical["BLAKE3 plaintext identity<br/>FastCDC chunks + zstd"]
```

`Repository` is the application handle for built-in storage. The optional
`casita::experimental::Repository<PS, SS>` exposes the same engine for custom
composition. `PS` stores verified
physical payloads and `SS` stores one revisioned logical snapshot containing
immutable records and named roots. An `ObjectFormat` reproduces an object's
native identity and exact forward links before publication.

This separation is load-bearing:

- Logical identity does not depend on chunking, compression, transfer framing,
  or the physical backend.
- Traversal, roots, synchronization, collection, and `fsck` consume stored
  `ObjectRecord` links instead of parsing format payloads again.
- A receiver reruns the namespace verifier. Sender-provided identities and
  links are discovery hints, not trusted facts.
- Mutation sessions and stable reads retain their data with online pins.
  Collectors serialize mark, atomic logical prune, and physical sweep with
  other collectors while ordinary work continues.

The CLI exposes one `sync` operation. The library's experimental `transfer()`
function is the receiver-verified protocol engine behind it, not a second
repository lifecycle.

Sync discovers the complete source closure by default. `sync --incremental`
reuses matching, verified destination closures and skips source discovery below
them. This is useful for repeated synchronization; it does not audit those
source descendants. Both modes use bounded discovery batches and spill large
queues and visited sets under the configured temporary-storage budget.

With `git` and `experimental`, `experimental::CasitaGixOdb` implements Gix's `Find`, `Write`,
`FindHeader`, `Exists`, and ODB `Header` traits without introducing another
storage engine. A dedicated worker bridges those synchronous traits to
Casita's async APIs through bounded channels. Writes have immediate overlay
visibility; callers finish a successful Git operation with `flush()`, or use
`publish_git_view()` to commit the final object batch and an immutable ref view
under one compare-and-swap mutation.

## Quick start

Install the CLI and import a filesystem tree:

```console
$ cargo install --path . --features cli
$ casita --repository ./casita-data import ./src --root examples/source
$ casita --repository ./casita-data root ls
```

Filesystem imports stage up to 16 files concurrently. Each blob writer allows
up to 32 chunk uploads, further constrained by the store's shared 64 MiB chunk
working-set budget. Tune these separately; both accept positive integers and
`1` makes that level serial:

```console
$ casita --repository ./casita-data import ./src --root examples/source \
    --filesystem-concurrency 8 --chunk-upload-concurrency 16
```

These are per-command settings, not persisted repository settings. The file
option applies only to filesystem imports; the chunk option applies to blob
writers for all importers. In Rust, use `FilesystemImport::with_file_concurrency`
and, for custom storage tuning, the experimental `ChunkedBlobStore` or typed
`Repository` method `with_chunk_upload_concurrency`. They accept `NonZeroUsize`.
The file window is also bounded by the 1,024-entry walk page. Completed files
immediately free slots for new reads; results are restored to traversal order
before directory construction. Each page still waits for all its files before
publication. Sequential metadata checkpoints and storage locks can reduce actual
concurrency.

Inspect or restore the resulting directory object:

```console
$ casita --repository ./casita-data tree list casita.directory.v1:...
$ casita --repository ./casita-data checkout casita.directory.v1:... ./restored
```

Runtime tracing is off by default. Enable Casita's operation spans, completion
counts, contention waits, and storage decisions with a scoped filter:

```console
$ casita --log-filter casita=info --repository ./casita-data fsck --dry-run
$ RUST_LOG=casita=debug casita --log-format json sync \
    --from ./casita-data --to ./mirror-data --root examples/source
```

Trace output always goes to standard error. `info` is intended for lifecycle
and outcome diagnostics; `debug` adds batch, payload, lock, spill, and protocol
detail. Casita does not attach filesystem paths, root names, credentials, or
payload contents to its trace fields, but immutable object IDs and repository
revisions may appear. Broad filters such as `debug` can also enable dependency
events with different data policies, so prefer `casita=debug` when collecting
diagnostics for sharing.

Synchronize a named graph between two local repositories:

```console
$ casita sync \
    --from ./casita-data \
    --to ./mirror-data \
    --root examples/source
```

Select one authenticated path without copying its siblings, and retain the
result under an explicit destination name:

```console
$ casita sync \
    --from ./casita-data \
    --to ./mirror-data \
    --root examples/source \
    --path lib/python3.12 \
    --destination-root partial/python3.12
```

Or read the same stable source snapshot over SSH:

```console
$ cargo install --path . --features cli,ssh
$ casita sync \
    --from ssh://alice@example.com/var/lib/casita \
    --to ./mirror-data \
    --root examples/source
```

The remote machine must have an SSH-accessible `casita` built with
`cli,ssh` on its `PATH`. Authentication, encryption, host-key checking, agent
use, and proxy jumps follow OpenSSH configuration; Casita does not disable
known-host verification. The remote process is read-only and holds one exact
repository revision while the destination resolves roots and transfers data.
For path-selected transfers, current peers return the complete bounded
directory proof in one request; the destination independently verifies its
revision, records, payloads, and links before using the selected object.
For missing blob and directory batches of up to 64 objects, the receiver can
pipeline metadata and payload requests under a 1 MiB payload reservation.
This uses the existing negotiated batch commands and retains streaming
fallback for larger batches, smaller memory budgets, and older peers.

With the experimental S3 profile enabled, either endpoint may instead be an
S3 URL. The bucket and prefix identify one shared repository; every runner
must use the same pair and should use its own diagnostic WAL writer name:

```console
$ cargo install --path . --features cli,s3
$ casita sync \
    --from ./casita-data \
    --to s3://casita-mirror/releases \
    --writer ci-runner-1 \
    --root examples/source
```

Use `--from-blobs` to read payloads from a different Casita repository while
`--from` supplies roots and object records. For example, discover metadata over
SSH and read immutable payloads directly from an S3 replica:

```console
$ casita sync \
    --from ssh://alice@example.com/var/lib/casita \
    --from-blobs s3://casita-mirror/releases \
    --to ./mirror-data \
    --root examples/source \
    --incremental
```

Build with `cli,ssh,s3` for that combination. The blob endpoint accepts the same
local, S3, or SSH repository locations as `--from`; it is not a raw bucket of
files. Its roots need not match the metadata source, but it must contain the
exact required payloads (and, for SSH payload reads, their object records).
Both source repositories remain retained during sync. All payloads, including
directory bodies used by `--path`, come from the blob endpoint and pass receiver
verification against metadata from `--from`. Missing payloads fail the sync
without falling back; destination roots move only after successful verification.
Without `--from-blobs`, `--from` supplies both metadata and payloads.

Credentials come from the standard AWS credential chain. The committed
`secretspec.toml` declares the optional static credential inputs, so local and
CI invocations can resolve them once for both of Casita's S3 clients:

```console
$ secretspec run --reason "Casita S3 sync" -- casita sync \
    --from ./casita-data \
    --to s3://casita-mirror/releases \
    --root examples/source
```

This remains compatible with instance roles, workload identity, shared AWS
profiles, and other credential-chain sources when SecretSpec is not used.
Region and an optional S3-compatible endpoint remain ordinary `AWS_*`
configuration. `CASITA_WRITER` supplies a default writer name when `--writer`
is omitted. S3 URLs do not include credentials.

SecretSpec is only the external secret-resolution boundary. Casita does not
load provider vaults, persist resolved credentials, or place them in its
immutable object graph. No encryption key is declared yet; a future encrypted
storage profile will add its key declaration only after its threat model and
key hierarchy are fixed.

Preview and perform collection through the same repository API:

```console
$ casita --repository ./casita-data gc --dry-run
$ casita --repository ./casita-data gc
$ casita --repository ./casita-data vacuum
$ casita --repository ./casita-data fsck --source ./casita-replica
```

Ordinary `gc` avoids high amplification by recording dead entries in a durable
footer-ordinal bitmap inside one immutable GC delta per pass while a partially
live pack is less than 50% garbage by compressed bytes. `vacuum` performs the
same reachability collection and then forces those deferred packs to be
rewritten. Disk-pressure collection uses the forced path automatically; wholly
dead packs are always deleted immediately.

The standard local profile probes disk pressure when a `MutationSession`
starts. At 80% used capacity it attempts one nonblocking collection before
registering the session's staging pin; `Busy` admits the mutation and leaves the
attempt for a later session. Casita runs no background timer, and generic
repository compositions have no implicit policy. Deployments can also schedule
`DiskPressurePolicy` directly. The standard local profile still opens an
existing repository without writing. If a collection's logical prune reaches
`ENOSPC`, Casita uses only the already-marked unreachable payloads as emergency
headroom and retries the prune. No fixed reserve is preallocated.

Native Git import is an optional feature:

```console
$ cargo install --path . --features cli,git
$ casita --repository ./casita-data import -i git ./project \
    --git-view upstream \
    --git-ref refs/heads/main
$ casita --repository ./casita-data git show upstream
```

Git import stages up to 16 objects concurrently, with a 64 MiB budget for
decoded source bytes awaiting staging. Set `--git-concurrency` and
`--git-max-buffered-bytes` to tune these positive limits; concurrency 1 selects
serial staging. An object larger than the byte budget runs alone. The budget
excludes Gix caches, decoding workspace and payload-store buffers. Rust requests
expose `GitImport::with_concurrency` and `with_max_buffered_bytes`; experimental
`NativeGitImportOptions` exposes the same limits. Source decoding remains
synchronous, while verification and payload staging can overlap. Incremental
imports preserve parent-first discovery and reuse the previous immutable closure.
Publication checkpoints finish active writes before flushing storage.

With `git-http`, an immutable Git view can be served to ordinary Git clients:

```console
$ cargo run --features cli,git-http -- \
    --repository ./casita-data git serve upstream --listen 127.0.0.1:9418
```

The server defaults to loopback-only exposure and refuses a non-loopback bind.
It does not terminate TLS or authenticate clients. For network exposure, run it
behind a reverse proxy that provides TLS, authentication, request filtering,
and any deployment-specific rate limits. Library users may set
`GitHttpOptions::allow_non_loopback` only when an equivalent trusted boundary
already exists.

`GitHttpOptions` independently bounds accepted connections, concurrent pack
generation, aggregate buffered request bodies, and each streaming response
pipe. It also configures header, body, idle, total-request, response-write, pack,
and graceful-shutdown deadlines. `serve_git_smart_http_with_shutdown` accepts a
shutdown future, while `GitHttpObserver` exposes structured per-connection
outcomes for logging and metrics adapters.

## Library example

All public imports use `repository.import(input)` through the `Importer<R>`
trait. Configure requests through constructors and builders; their fields are private.
Use `TarImport::with_limits` for tar bounds and `CasitarImport::with_conflict_policy`
for destination replacement. `CasitarImport::new(reader, destinations)` takes all
destination names in canonical archive-root order; pass `[name]` for one root.
Git options use individual builders such as `with_refs`
and `with_max_cached_pack_bytes`; the experimental `with_options` method was removed.
Built-in requests are `FilesystemImport`, `TarImport`, `CasitarImport`,
and (with `git`) `GitImport`. The same requests work with the standard and
experimental repositories; reports retain the facts specific to each format.
Filesystem requests return an `ObjectKey`; tar reports expose `root`, Casitar
reports expose `mappings`, and Git reports expose `view`.

The supported Rust API uses a non-generic `Repository`, identities, filesystem
data types, and application errors and reports. Backend implementations,
custom formats, protocol services, and detailed tuning are available only
under `casita::experimental` with the `experimental` feature. The CLI enables
that feature for its advanced commands.

```rust no_run
use casita::{FilesystemImport, Repository, RootName};

#[tokio::main(flavor = "current_thread")]
async fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let repository = Repository::local("./data").await?;
    let root = repository
        .import(FilesystemImport::new(
            "/some/directory",
            RootName::try_from("projects/example")?,
        ))
        .await?;

    repository.checkout(&root, "./restored").await?;
    let preview = repository.preview_collection().await?;
    println!("collectible objects: {}", preview.logical_objects);
    repository.flush().await?;
    Ok(())
}
```

Stream payloads with a reader whose lifetime protects the data from collection:

```rust no_run
use casita::{Repository, RootName};
use tokio::io::AsyncReadExt;

#[tokio::main(flavor = "current_thread")]
async fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let repository = Repository::local("./data").await?;
    let key = repository
        .put_blob(&b"hello"[..], RootName::try_from("example/blob")?)
        .await?;
    let mut reader = repository.open(&key).await?.ok_or("missing payload")?;
    let mut bytes = Vec::new();
    reader.read_to_end(&mut bytes).await?;
    drop(reader); // Release protection against collection.
    repository.flush().await?; // Await writes and dropped-lease cleanup.
    assert_eq!(bytes, b"hello");
    Ok(())
}
```

Cloning a repository shares its coordination and caches. Readers keep their
data alive even after the repository handle is dropped. Drop readers before
collection or the final `flush()`; flushing does not release live readers.

`compare_and_set_root(name, expected, target)` conditionally publishes an
existing graph: `None` requires an absent name, and `Some(&key)` requires that
exact current target. A mismatch returns `false` without changing the root.
Import under a staging name first, then promote it to a shared name.
`set_root` unconditionally replaces a name. `copy_root_from` copies one named
source graph and atomically creates or replaces its destination root.

For ephemeral use, `Repository::memory()` provides the same logical behavior.
Custom deployments enable `experimental` and compose
`experimental::Repository::new(payloads, state)` from
`experimental::BlobStore` and `experimental::MetadataStore`. Full physical collection is available when the
payload backend also implements `BlobGc`. A shared remote payload service can
instead call `preview_logical_collection` and `collect_logical` to prune only
one repository's records; the service retains responsibility for global
payload liveness and deletion.

The local profile stores its payload catalog as an immutable object under
`blobs/pack-indexes/`. SQLite and durable pins carry a 56-byte versioned
reference containing its digest, catalog generation, and length. Catalog
objects are durable before their references commit; collection retains roots
and their children while current state or pins reference them. A missing or
corrupt committed catalog is an error, never a reason to adopt unpublished
objects from an inventory scan.

Opening a schema-4 or schema-5 local repository upgrades it to schema 6 and
migrates its inline catalog under the repository's exclusive publication lock.
The catalog column is renamed to `payload_catalog_ref`, fencing older
publication SQL, including already-open writers. Interrupted migration resumes
from the last committed witness. Existing inline pin witnesses remain readable;
new pins use the small reference. Older Casita binaries cannot write schema 6.

The opt-in `s3` feature adds `Repository::s3` for shared storage. With
`experimental` also enabled, `experimental::Wal3MetadataStore` exposes its
object-store-authoritative state backend built on Chroma's wal3 Git source. Multiple runners can share one
wal3 prefix: a racing mutation returns `StaleRevision` and the caller retries
against the newly published state. Each WAL3 tail record carries up to eight
cumulative deltas against an immutable state checkpoint. The ninth mutation,
a tail over 1 MiB, or collection installs a new checkpoint; only changed logical
object shards are rewritten. Root and catalog changes share that revision;
payload chunks are sealed into immutable, content-addressed packs in the same
bucket. A first chunk access uses an exact range read and reuse promotes its
pack through one single-flight whole-object fetch. After eviction pressure,
scattered accesses retain only their ranges and consecutive range misses
trigger promotion. Ranges and whole packs share a bounded 64 MiB cache. Pack
inventory is summarized by catalog v1: an inline checkpoint followed by exact,
byte-bounded deltas and immutable binary-leveled runs. State stores without
payload-catalog coordination discover it through an advisory pointer. An exact
catalog avoids all pack-footer, replacement, and GC-delta reads; a missing,
stale, or corrupt advisory catalog falls back to bounded concurrent reads of
each pack's 16-byte trailer and exact encoded footer, then repairs the pointer
best-effort. Packs, replacement records, and GC deltas remain authoritative.
The default compressed target is
16 MiB for S3 and 4 MiB for local repositories; both profiles expose an
explicit target for measured deployment tuning. S3 syncs additionally expose
`--pack-cache-bytes` and `--pack-cache-promotion-reads`.
`Repository::s3(bucket, prefix, writer)` opens this standard profile with AWS's
standard credential chain; use
`Wal3MetadataStore::open` with `wal3_storage` for custom S3-compatible stores.
State readers verify the latest tail and its referenced checkpoint, then apply
the bounded cumulative deltas. Logical object shards load on demand. Decoded
state is shared while its WAL3 witness remains valid; a changed manifest
refreshes the tail. Packed catalog v1 roots are committed inside that
same logical revision, so publishing a WAL3-backed repository needs no
standalone payload-index pointer PUT and a reader reconstructs exactly the
catalog named by its state snapshot. Immutable catalog runs remain separate
content-addressed objects. Repository construction recovers WAL3 first and
seeds payload discovery from its already-validated checkpoint, avoiding an
advisory-pointer GET. New WAL3 logs start with an explicit empty v1 catalog;
state without one is rejected rather than migrated. A maintenance runner can call
`Wal3MetadataStore::collect_wal(reader_grace_period)` to advance WAL3's intrinsic
cursor and run its three-phase state-log garbage collection protocol; the grace
period must exceed the longest manifest-to-fragment reader lifetime.
Remote readers and mutation sessions register durable online pins. Collection
uses those pins to retain data in use while reclaiming unrelated garbage.
Collectors serialize through a separate WAL3 admission log, and publish the
payload catalog before deleting retired packs. `try_collect` and `try_vacuum`
report `Busy` when collector ownership or a conflicting pin change prevents a
pass. All runners must use
this protocol. Holds never expire automatically. Library applications must drop
sessions and call `flush_repository_leases()` before shutting down Tokio; the
CLI drains releases automatically. Interrupted collectors remain fenced until
offline recovery. See the [S3 maintenance guide](docs/src/content/docs/guides/s3-maintenance.md)
for recovery and log maintenance.

## Application metadata

Local repositories provide opaque, namespaced records alongside content storage
and GC roots. Index entries never retain payloads: only explicit roots protect
object graphs. Values can contain path descriptors, reverse-reference entries,
or realisations without giving Casita any Nix-specific semantics.

```rust,no_run
# async fn example() -> Result<(), Box<dyn std::error::Error>> {
use casita::{Repository, MetadataKey, MetadataCheck, MetadataChange, MetadataCommitResult};

let repo = Repository::local("./data").await?;
let namespace = "obrador.v1".parse()?;
let path = MetadataKey::new(namespace, "paths/hash");
let result = repo.commit(
    vec![MetadataCheck::Record { key: path.clone(), expected: None }],
    vec![MetadataChange::Set { key: path.clone(), value: "descriptor".into() }],
).await?;
assert!(matches!(result, MetadataCommitResult::Committed { .. }));
let values = repo.get(&[path]).await?;
assert_eq!(values[0].as_deref(), Some(b"descriptor".as_slice()));

let reader = repo.metadata_reader().await?;
let prefix = MetadataKey::new("obrador.v1".parse()?, "referrers/target/");
let mut cursor = None;
loop {
    let page = reader.scan(&prefix, cursor.as_ref(), 256).await?;
    // Consume page.records; all pages and reader.get/root calls share a revision.
    cursor = page.cursor;
    if cursor.is_none() { break; }
}
# Ok(())
# }
```

`MetadataChange::SetRoot` and `RemoveRoot` share the record transaction, and
`MetadataCheck::Root` compares expected root targets. Failed checks return the
first mismatching input index and change nothing; unrelated writes do not cause
value conflicts. Checks compare current values, so a change away and back to
the same value is not detected. Root targets must already exist and pass graph
verification. Import under a staging root, then register the descriptor and
reverse references while promoting/removing roots in one commit. Advanced
callers can use `MutationSession::publish_with_metadata` to publish staged
content in the same transaction too.

Keys are raw bytes within a versioned namespace. Prefix matching is bytewise,
so include `/` when selecting a path segment. Cursors are bound to their prefix
and revision. Keep a `MetadataReader` while paging amid writes; the convenience
`Repository::scan` rejects old-revision cursors. Metadata readers do not pin
payloads, and should be released after use so old database WAL pages can be
reclaimed. On S3 they retain only the metadata shards needed by the snapshot.

`metadata_reader()` works on every backend, including S3. Its `object`, `root`, `roots`,
and `revision` methods share one stable snapshot. Application-record `get` and
`scan` return `Unsupported` on backends without record support.

When metadata or a root selects content to read, acquire `retained_reader()`
**before** the lookup and open content through that same session. Its `get`,
`scan`, `root`, `object`, and `open` methods share one protected snapshot, so a
concurrent root replacement and GC cannot retire the selected snapshot content
between lookup and open. Metadata values remain opaque: a referenced object
might already be absent when the session starts.

```rust,no_run
# async fn example(repo: &casita::Repository) -> Result<(), Box<dyn std::error::Error>> {
use tokio::io::AsyncReadExt;

let session = repo.retained_reader().await?;
let root = session.root(&"current".try_into()?).await?.ok_or("missing root")?;
let mut content = session.open(&root).await?.ok_or("missing content")?;
drop(session); // The content reader now keeps the protection alive.
let mut bytes = Vec::new();
content.read_to_end(&mut bytes).await?;
# Ok(())
# }
```

For an already known immutable key, `repo.open(&key)` retains just that object's
reachable closure and the physical packs its reader needs. Unrelated garbage can
be collected while the reader remains open. Immutable packs may also contain
neighboring bytes that remain until the reader closes. A separate `root()` then
`open()` is still two operations; use a retained session for an atomic protected
lookup and open.

Local ordinary readers share a kernel-locked owner across repository handles in
one process. Their object and pack pins live in a separate atomic inventory, so
warm opens and releases do not sync the durable ledger. First-owner setup and
renewing a 65,536-transition revision reservation remain durable. Collectors use
the same lock and combined revision to arbitrate reads, pruning, and deletion.
After a process exits, its read protection is released automatically. Staging,
explicit retained sessions, and deletion claims still require durable recovery;
remote readers retain their existing durable protocol. Drop readers and call
`flush()` to drain releases during normal operation. Reopen local repositories
after `fork`; inherited pin-store handles are rejected.

The first local ordinary read upgrades the inventory codec to `CASPIN04`. Older
binaries reject this format; upgrade every process using the repository before
activating it. Missing or corrupt reader state blocks collection while any owner
is alive. Once all owners have exited, recovery preserves durable write records
and advances beyond their reserved revisions, including when a host crash leaves
an intact but older reader inventory.

On Linux, durable pin changes append checksummed deltas to a `CASPJL01` journal.
Up to 64 queued operations share a file sync, in queue order, and replies wait for
that barrier. A checkpoint replaces the journal before it exceeds 256 operations
or 1 MiB of frames. Two preallocated files and atomic exchange preserve bounded
collection bookkeeping when storage fills; growth still needs free space. Existing
ledgers migrate on the first durable update. If preallocation runs out of space
before activation, the old replacement path remains usable for collection. Older
binaries reject the journal, so upgrade all repository processes before activation.
See the [local ledger protocol](docs/local-pin-journal.md) for recovery details.

A retained session can be cloned and can outlive its repository handle. Release
sessions and their content readers promptly: they share one snapshot pin against
GC. Local retained sessions use process-owned protection: the final drop releases
that session's pin, and an OS file lock lets GC safely recover after process death.
Writes and remote repositories retain durable protection.
Root/content reads work on all built-in backends; application-record reads are
supported on local and in-memory repositories.

Limits are 4 KiB keys, 1 MiB values, 4096 checks/changes or get keys, and 16 MiB
of record input per commit or returned values per get. Scan limits are 1..1024
rows and 16 MiB of key/value bytes, with continuation on either boundary.
Existing local version-4 databases migrate additively to version 5 on open;
objects, roots, and revisions are preserved. In-memory repositories implement
the same semantics. S3 supports root-only commits through its existing publication
protocol; application-record operations remain unsupported. `set_root`,
`compare_and_set_root`, and `remove_root` are convenience wrappers over `commit`.

## Object model

- `ObjectKey` is a validated namespace plus that format's canonical native ID.
- `ObjectRecord` immutably binds a key to a BLAKE3 payload, byte length, and
  ordered forward links.
- `RootName` gives one complete graph a durable, atomically replaceable name.
- `RepositoryRevision` changes whenever committed logical state or coordinated
  physical catalog metadata changes and is compared for equality, never ordering.
- `BlobId`, `DirectoryId`, and `ChunkId` are distinct typed BLAKE3 identities.

Built-in formats include raw blobs, canonical filesystem directories, raw and
linked IPLD, native Git SHA-1 and SHA-256 objects, and immutable Git ref views.

## Storage and integrity

The standard local profile stores payloads below `<repository>/blobs` and
logical state in `<repository>/casita.sqlite`:

```text
<repository>/
  blobs/
    blobs/b3/<xx>/<hex>    multi-chunk and empty-payload manifests
    packs/b3/<xx>/<hex>    immutable packs of zstd-compressed FastCDC chunks
    pack-replacements/...  content-addressed compaction records
    pack-tombstones/...    content-addressed batched sparse-GC deltas
    pack-indexes/...       immutable catalog roots, checkpoints, runs and shard maps
    pack-index-current     standalone packed-store pointer; WAL3 advisory root
    chunks/b3/<xx>/<hex>   chunks used only by unpacked repositories
    bao/b3/<xx>/<hex>      verified-range outboards or page-tree descriptors
    pages/b3/<xx>/<hex>    shared immutable manifest and outboard pages
  casita.sqlite            records, links, roots, and repository revision
  casita.sqlite.online-pins  durable scoped pins, deletion claims, reader fence
  casita.sqlite.online-pins.readers  atomic live-reader inventory
  casita.sqlite.online-pins.reader-<token>.lock  process owner liveness
  gc.lock                  one cross-process collector
```

Payload identity is always the BLAKE3 hash of plaintext bytes. FastCDC
boundaries, zstd frames, and bao outboards are private physical choices. Every
chunk is checked when read, full streams verify the payload at EOF, and
namespace verification checks canonical identity and links before publication.

New chunked writes retain Bao proof metadata while hashing the input. Use
`Repository::open_verified()` to authenticate each block before the reader
returns its bytes. Opening freezes the payload's chunk plan; file contents and
proof nodes are then read on demand without buffering the complete file or
outboard. Existing files without proof metadata can be prepared once with
`Repository::prepare_verified()`.

Ordinary and verified object readers retain the selected object's graph and
required physical data. Checkout, Casitar export, closure verification, and
proof preparation retain their selected graphs plus the snapshot catalog;
that catalog can temporarily retain extra physical bytes. Explicit
`retained_reader()` sessions and explicit `TransferSelection::Snapshot` transfer
sessions retain the whole snapshot. Standard copies, syncs, and remote verified
reads select their source graphs during acquisition. Path transfers retain the
containing root's graph; split payload endpoints keep snapshot-wide protection.
SSH peers without selection support safely retain their entire snapshot.

The CLI can stream verified contents locally or directly from a transfer source:

```console
$ casita --repository ./casita-data cat --verified casita.blob.v1:...
$ casita cat --verified --from ssh://alice@example.com/var/lib/casita casita.blob.v1:...
```

`Repository::overwrite_blob(key, offset, replacement, root)` creates a new raw
blob by replacing the same number of bytes, then atomically updates the supplied
root. It verifies a proof of the old range, derives the new ordinary BLAKE3 ID,
and reuses unchanged storage chunks. Chunked storage reads and rehashes only the
affected blocks/chunks and copies only affected metadata pages and their tree
paths. New large files use shared metadata pages automatically. Preparing an
older flat file also migrates its large metadata; otherwise its first edit pays
that conversion cost. Older Casita binaries cannot read the new page descriptors.
In-memory storage copies and rehashes its byte buffer. See the
[verified files protocol](specs/verified-files.md) for guarantees and limits.

Collection marks the union of named-root closures from one immutable snapshot,
atomically removes unreachable logical records, then deletes unreferenced
payloads and chunks. A deletion failure may leak storage for a later retry but
cannot make reachable state invalid. On a full colocated local filesystem, a
typed `StorageFull` result activates an emergency path that deletes only the
verified stale physical set before retrying the logical prune.

## CLI

The main commands are:

```text
init
import PATH [--root NAME]
object show KEY
tree list KEY
import -i git ...
git show|checkout|serve ...
sync --from PATH|S3_URL|SSH_URL [--from-blobs PATH|S3_URL|SSH_URL] --to PATH|S3_URL [--writer NAME] (--object KEY | --root NAME)... [--path PATH] [--destination-root NAME] [--shallow] [--incremental]
root set|rm|ls ...
checkout KEY DIR [--no-root]
cat KEY
gc [--dry-run]
vacuum
fsck [--audit-only | --dry-run] [--source REPOSITORY]
```

## Cargo features

| Feature | Adds |
|---|---|
| `native` (default) | local payload/state backends, repository orchestration, filesystem workflows, collection, sync, and structured trace emission |
| `cli` | the `casita` command-line tool and compact/JSON trace subscriber |
| `git` | native Git import from local working trees or bare repositories |
| `git-fetch` | experimental read-only Git fetch planning and pack generation |
| `git-http` | read-only Git smart-HTTP serving for immutable views |
| `ssh` | authenticated remote transfer sources through the system OpenSSH client |
| `s3` | experimental wal3-backed shared object-store state; requires `protoc` to build Chroma's current Git dependency |

With `default-features = false`, identity types, canonical encodings, format
definitions, Casitar framing, IPLD, and native Git object
parsing remain available without local I/O backends.

## Design documents

Project policy and release documents:

- [Changelog](CHANGELOG.md)
- [Security policy](SECURITY.md)
- [Release process](RELEASING.md)

Architecture and format documents:

- [Product goals](specs/goals.md)
- [Repository backbone](specs/backbone.md)
- [Implemented design](specs/design.md)
- [Casita and Lore comparison](specs/lore-comparison.md)
- [Casitar portable closure archives](specs/casitar.md)
- [Frozen encodings](specs/encodings.md)
- [v0.1 filesystem repository](specs/v0.1.md)
- [v0.2 generic transfer](specs/v0.2.md)
- [v0.4 native Git](specs/v0.4.md)

## Benchmarks

The checked-in [end-to-end benchmark harness](benchmarks/README.md) measures
repeatable import, incremental import, checkout, local sync, verification, and
collection workflows. It compares only overlapping operations with Git,
restic, Borg, and tar+zstd, validates restored trees, and preserves every raw
sample in JSON before rendering summary tables.

Published results are available in the
[interactive benchmark report](https://casita.rs/benchmarks/).

Casita is a clean-room implementation built from standard algorithms and is
licensed under Apache-2.0.

The companion [`casita-fs`](casita-fs/README.md) crate exposes filesystem trees
through Linux FUSE and macOS FSKit, with application-supplied roots and access policy.
