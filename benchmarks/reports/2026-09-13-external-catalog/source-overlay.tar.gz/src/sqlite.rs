//! The shared Turso connection layer behind persistent repository state.
//!
//! Turso operates directly on the repository's SQLite-format database.
//! [`TursoMetadataStore`](crate::TursoMetadataStore) speaks SQL through [`TursoDb`]
//! and shares pooled connections across snapshots.
//!
//! The SQL above this module deliberately stays in the conservative SQLite
//! subset: plain tables, `INSERT OR REPLACE`, parameterized reads/deletes,
//! bytewise `BLOB` keys, and binary-collated `TEXT`. The on-disk contract is
//! `<repository>/casita.sqlite`.
//!
//! Turso's experimental multi-process WAL is enabled when the database is
//! built, on every supported platform. MVCC is intentionally not enabled:
//! casita serializes writes on one connection in-process, while the WAL
//! coordinates separate processes and keeps readers moving during a write.
//!
//! Database transactions protect logical state; durable repository pins retain
//! data used by mutations and stable reads during physical collection.

use std::ops::Deref;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

use futures::FutureExt;
use futures::future::BoxFuture;
use turso::{Builder, Connection, Database};

use crate::error::Error;

/// Accumulated lock-wait budget.
const BUSY_TIMEOUT_MS: u64 = 30_000;
/// Bound idle connections, not live snapshots: readers never wait for a slot.
const IDLE_READ_CONNECTIONS: usize = 8;

/// A snapshot has exclusive use of this connection. End its transaction before
/// returning it to the pool so an idle connection cannot hold an old WAL view.
pub(crate) struct ReadConnection {
    connection: Option<Connection>,
    idle: Arc<Mutex<Vec<Connection>>>,
}

impl Deref for ReadConnection {
    type Target = Connection;
    fn deref(&self) -> &Connection {
        self.connection.as_ref().expect("live read connection")
    }
}

impl Drop for ReadConnection {
    fn drop(&mut self) {
        let Some(connection) = self.connection.take() else {
            return;
        };
        // Local read rollback normally completes on its first poll. Never run a
        // nested executor or leave a transaction waiting in the idle pool: if
        // cleanup needs asynchronous work or fails, discard the connection just
        // as an unpooled snapshot would. This also works outside any runtime.
        if !matches!(
            connection.execute_batch("ROLLBACK;").now_or_never(),
            Some(Ok(()))
        ) || !matches!(connection.is_autocommit(), Ok(true))
        {
            return;
        }
        if let Ok(mut idle) = self.idle.lock()
            && idle.len() < IDLE_READ_CONNECTIONS
        {
            idle.push(connection);
        }
    }
}

/// Generic logical schema at `<repository>/casita.sqlite`; payload bytes live
/// separately under `blobs/`.
const REPOSITORY_SCHEMA: &str = "
CREATE TABLE IF NOT EXISTS repository_state (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    revision  BLOB NOT NULL,
    generation INTEGER NOT NULL DEFAULT 0 CHECK (generation >= 0),
    payload_catalog_ref BLOB
);
CREATE TABLE IF NOT EXISTS objects (
    namespace    TEXT NOT NULL,
    native_id    BLOB NOT NULL,
    payload      BLOB NOT NULL,
    payload_size BLOB NOT NULL,
    record        BLOB NOT NULL,
    created_generation INTEGER NOT NULL CHECK (created_generation >= 0),
    validated    INTEGER NOT NULL DEFAULT 0 CHECK (validated IN (0, 1)),
    PRIMARY KEY (namespace, native_id)
);
CREATE TABLE IF NOT EXISTS named_roots (
    name      TEXT PRIMARY KEY,
    namespace TEXT NOT NULL,
    native_id BLOB NOT NULL
);
CREATE INDEX IF NOT EXISTS named_roots_target ON named_roots(namespace, native_id);
CREATE TABLE IF NOT EXISTS metadata_records (
    namespace TEXT NOT NULL,
    key BLOB NOT NULL,
    value BLOB NOT NULL,
    PRIMARY KEY (namespace, key)
);
CREATE TABLE IF NOT EXISTS ingest_cache (
    device      INTEGER NOT NULL,
    inode       INTEGER NOT NULL,
    size        INTEGER NOT NULL,
    mtime_sec   INTEGER NOT NULL,
    mtime_nsec  INTEGER NOT NULL,
    ctime_sec   INTEGER NOT NULL,
    ctime_nsec  INTEGER NOT NULL,
    blob_digest BLOB NOT NULL,
    PRIMARY KEY (device, inode)
);
";

/// The current pre-release generic repository schema's `PRAGMA user_version`.
///
/// Earlier development schemas expanded every object link into its own SQL
/// row. They are deliberately not migration inputs: repositories can be
/// recreated while Casita remains unreleased.
/// Versions 4 and 5 are migration inputs. Version 6 renames the catalog column
/// to fence legacy publication SQL before local catalogs become external roots.
const REPOSITORY_USER_VERSION: i64 = 6;

/// A Turso database shared by persistent repository-state components.
///
/// One connection is reserved for writes and guarded by an async mutex so a
/// process issues at most one write transaction at a time. Reads borrow a
/// small pool of independent Turso connections and may proceed concurrently.
pub struct TursoDb {
    path: PathBuf,
    database: Database,
    writer: Arc<tokio::sync::Mutex<Connection>>,
    idle_readers: Arc<Mutex<Vec<Connection>>>,
}

impl TursoDb {
    pub(crate) fn path(&self) -> &Path {
        &self.path
    }
    /// Open or create the SQLite-format database at `path`, enable Turso's
    /// multi-process WAL, and apply the repository schema.
    ///
    /// Turso's asynchronous open and schema setup are driven to completion
    /// here; query execution remains fully async.
    ///
    /// `path` must be valid UTF-8 because Turso's builder takes a `&str`.
    ///
    /// This drives async setup to completion with a blocking executor, so an
    /// async caller should run it under [`spawn_blocking`](tokio::task::spawn_blocking)
    /// rather than on a runtime worker.
    #[tracing::instrument(name = "state.turso.open", skip_all)]
    pub fn open(path: impl AsRef<Path>) -> Result<Arc<Self>, Error> {
        let path = path.as_ref().to_path_buf();
        let database_existed = path.exists();
        let path_str = path.to_str().ok_or_else(|| {
            Error::from(format!(
                "Turso database path is not valid UTF-8: {}",
                path.display()
            ))
        })?;

        let (database, writer) = futures::executor::block_on(async {
            let builder = Builder::new_local(path_str);
            // Windows coordinates the shared WAL through the IOCP backend:
            // the default syscall backend does not implement the byte-range
            // locking and shutdown checkpointing a second process needs.
            // `tests/turso_multiprocess.rs` is the regression test.
            #[cfg(windows)]
            let builder = builder.with_io("experimental_win_iocp");
            let database = builder.experimental_multiprocess_wal(true).build().await?;
            let mut writer = database.connect()?;
            // Acquire the WAL write lock before reading a revision. A deferred
            // read-to-write upgrade can fail BUSY_SNAPSHOT under foreign writers.
            writer.set_transaction_behavior(turso::transaction::TransactionBehavior::Immediate);
            configure_connection(&writer)?;

            let mut rows = writer.query("PRAGMA user_version", ()).await?;
            let found: i64 = rows
                .next()
                .await?
                .ok_or("PRAGMA user_version returned no row")?
                .get(0)?;
            let initialize = found == 0 && !database_existed;
            if found != REPOSITORY_USER_VERSION && found != 4 && found != 5 && !initialize {
                return Err(Error::from(format!(
                    "database {} has unsupported schema version {found}; this casita release \
                     supports only version {REPOSITORY_USER_VERSION} and does not migrate \
                     pre-release repositories; recreate or re-import it",
                    path.display()
                )));
            }

            // Opening an already-current repository is a read-only operation.
            // Besides avoiding needless WAL traffic in the common case, this
            // is what lets an existing repository open after its filesystem
            // has reached ENOSPC so collection can reclaim space.
            if initialize {
                writer
                    .execute_batch(format!(
                        "BEGIN IMMEDIATE;\n{REPOSITORY_SCHEMA}\n\
                         PRAGMA user_version = {REPOSITORY_USER_VERSION};\nCOMMIT;"
                    ))
                    .await?;
            }
            if found == 4 {
                // Additive migration: existing objects, roots and revisions are
                // untouched. Subsequent opens remain read-only.
                writer
                    .execute_batch(
                        "BEGIN IMMEDIATE; CREATE TABLE IF NOT EXISTS metadata_records (
                     namespace TEXT NOT NULL, key BLOB NOT NULL, value BLOB NOT NULL,
                     PRIMARY KEY (namespace, key)); CREATE INDEX IF NOT EXISTS named_roots_target ON named_roots(namespace, native_id); PRAGMA user_version = 5; COMMIT;",
                    )
                    .await?;
            }
            if found == 4 || found == 5 {
                // Rename, rather than merely adding a format flag: an old
                // already-open writer's catalog UPDATE must fail after schema
                // invalidation. Old read snapshots keep their original view.
                writer.execute_batch(
                    "BEGIN IMMEDIATE; ALTER TABLE repository_state RENAME COLUMN payload_catalog TO payload_catalog_ref; PRAGMA user_version = 6; COMMIT;"
                ).await?;
            }
            // `synchronous` is connection-local and changes no persistent
            // page, so configuring it does not consume filesystem space.
            writer.execute_batch("PRAGMA synchronous = FULL;").await?;
            Ok::<_, Error>((database, writer))
        })?;

        Ok(Arc::new(Self {
            path,
            database,
            writer: Arc::new(tokio::sync::Mutex::new(writer)),
            idle_readers: Arc::new(Mutex::new(Vec::new())),
        }))
    }

    /// Run one operation on the process's serialized write connection.
    ///
    /// The operation runs to completion on the blocking pool via
    /// [`spawn_blocking`](tokio::task::spawn_blocking). This keeps two
    /// properties the previous rusqlite engine had for free:
    ///
    /// - **off the executor**: Turso's local backend performs its file I/O
    ///   (including the commit fsync) synchronously inside `poll`, so running
    ///   it on a runtime worker would block every other task on a
    ///   current-thread runtime; the blocking pool absorbs it instead.
    /// - **cancellation-safe**: a `spawn_blocking` task runs to completion even
    ///   if the caller drops the returned future, so a cancelled write cannot
    ///   abandon a half-applied transaction on the shared writer connection and
    ///   strand it (Turso only rolls a dropped transaction back lazily, on the
    ///   connection's next use).
    pub(crate) async fn write<T, F>(self: &Arc<Self>, f: F) -> Result<T, Error>
    where
        F: for<'a> FnOnce(&'a mut Connection) -> BoxFuture<'a, Result<T, Error>> + Send + 'static,
        T: Send + 'static,
    {
        // The owned guard keeps the one writer connection (and its lazy
        // dangling-transaction state) across calls; the blocking task holds it
        // until the write finishes, so the next write waits rather than racing.
        let mut guard = self.writer.clone().lock_owned().await;
        tokio::task::spawn_blocking(move || futures::executor::block_on(f(&mut guard))).await?
    }

    /// Replace the serialized writer after a failed transaction.
    ///
    /// Turso rolls abandoned transactions back lazily when their connection is
    /// reused. An ENOSPC during commit can leave that cleanup path unable to
    /// distinguish an already-aborted transaction, so emergency collection
    /// retries on a fresh connection instead.
    pub(crate) async fn reset_writer(&self) -> Result<(), Error> {
        let mut writer = self.database.connect()?;
        writer.set_transaction_behavior(turso::transaction::TransactionBehavior::Immediate);
        configure_connection(&writer)?;
        writer.execute_batch("PRAGMA synchronous = FULL;").await?;
        *self.writer.lock().await = writer;
        Ok(())
    }

    /// Borrow an exclusive query-only connection and begin a fresh transaction.
    /// The first state query establishes its WAL snapshot; retaining the
    /// returned connection keeps every later query on that same immutable
    /// logical view.
    pub(crate) async fn begin_read_snapshot(self: &Arc<Self>) -> Result<ReadConnection, Error> {
        let this = self.clone();
        tokio::task::spawn_blocking(move || {
            futures::executor::block_on(async move {
                let cached = this
                    .idle_readers
                    .lock()
                    .ok()
                    .and_then(|mut idle| idle.pop());
                let connection = match cached {
                    Some(connection) => connection,
                    None => {
                        let connection = this.database.connect()?;
                        configure_reader(&connection).await?;
                        connection
                    }
                };
                // Own cleanup before BEGIN: a failed/cancelled acquisition
                // cannot return a connection with an unfinished transaction.
                let connection = ReadConnection {
                    connection: Some(connection),
                    idle: this.idle_readers.clone(),
                };
                connection
                    .execute_batch("BEGIN DEFERRED TRANSACTION;")
                    .await?;
                Ok(connection)
            })
        })
        .await?
    }
}

impl std::fmt::Debug for TursoDb {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("TursoDb").field("path", &self.path).finish()
    }
}

fn configure_connection(conn: &Connection) -> Result<(), Error> {
    conn.busy_timeout(std::time::Duration::from_millis(BUSY_TIMEOUT_MS))?;
    Ok(())
}

/// Configure a read connection. Beyond the busy timeout, reads run under
/// `PRAGMA query_only` so a mistaken write on a read path fails at the engine
/// level instead of mutating repository state or taking the WAL write lock.
async fn configure_reader(conn: &Connection) -> Result<(), Error> {
    configure_connection(conn)?;
    conn.execute_batch("PRAGMA query_only = true;").await?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    async fn snapshot_generation(connection: &Connection) -> i64 {
        connection
            .query("SELECT generation FROM repository_state", ())
            .await
            .unwrap()
            .next()
            .await
            .unwrap()
            .unwrap()
            .get(0)
            .unwrap()
    }

    #[tokio::test]
    async fn reused_readers_are_fresh_query_only_and_do_not_retain_transactions() {
        let temp = tempfile::tempdir().unwrap();
        let path = temp.path().join("casita.sqlite");
        let database = TursoDb::open(&path).unwrap();
        database.writer.lock().await.execute_batch(
            "INSERT INTO repository_state(singleton, revision, generation) VALUES (1, X'01', 1);"
        ).await.unwrap();
        let old = database.begin_read_snapshot().await.unwrap();
        assert_eq!(snapshot_generation(&old).await, 1);
        let other = TursoDb::open(&path).unwrap();
        other
            .writer
            .lock()
            .await
            .execute_batch("UPDATE repository_state SET generation = 2;")
            .await
            .unwrap();
        let fresh = database.begin_read_snapshot().await.unwrap();
        assert_eq!(snapshot_generation(&fresh).await, 2);
        assert_eq!(snapshot_generation(&old).await, 1);
        // Drop inside a futures executor, then on a plain thread with no Tokio
        // runtime. Neither cleanup path may depend on an ambient executor.
        futures::executor::block_on(async {
            drop(fresh);
        });
        std::thread::spawn(move || drop(old)).join().unwrap();
        {
            let idle = database.idle_readers.lock().unwrap();
            assert_eq!(idle.len(), 2);
            assert!(
                idle.iter()
                    .all(|connection| connection.is_autocommit().unwrap())
            );
        }
        other
            .writer
            .lock()
            .await
            .execute_batch("UPDATE repository_state SET generation = 3;")
            .await
            .unwrap();
        let reused = database.begin_read_snapshot().await.unwrap();
        assert_eq!(snapshot_generation(&reused).await, 3);
        assert!(
            reused
                .execute_batch("DELETE FROM repository_state;")
                .await
                .is_err()
        );
        assert!(
            reused
                .query("SELECT missing FROM repository_state", ())
                .await
                .is_err()
        );
        drop(reused);
        assert_eq!(database.idle_readers.lock().unwrap().len(), 2);
        let reused = database.begin_read_snapshot().await.unwrap();
        assert_eq!(snapshot_generation(&reused).await, 3);
    }

    #[tokio::test]
    async fn reader_cache_bounds_idle_connections_without_limiting_live_snapshots() {
        let temp = tempfile::tempdir().unwrap();
        let database = TursoDb::open(temp.path().join("casita.sqlite")).unwrap();
        for count in [7, 8, 9, 16] {
            let readers =
                futures::future::try_join_all((0..count).map(|_| database.begin_read_snapshot()))
                    .await
                    .unwrap();
            assert_eq!(readers.len(), count);
            assert!(database.idle_readers.lock().unwrap().is_empty());
            drop(readers);
            let idle = database.idle_readers.lock().unwrap();
            assert_eq!(idle.len(), count.min(IDLE_READ_CONNECTIONS));
            assert!(
                idle.iter()
                    .all(|connection| connection.is_autocommit().unwrap())
            );
        }
    }

    /// Permanent benchmark: acquisition/query/release bursts across the idle
    /// cache bound. The fresh control empties the idle cache after every burst;
    /// connection destruction is included in its timed cost.
    #[tokio::test]
    #[ignore = "run through benchmark run snapshot-connections"]
    async fn benchmark_snapshot_connections() {
        let width: usize = std::env::var("CASITA_SNAPSHOT_WIDTH")
            .unwrap()
            .parse()
            .unwrap();
        let iterations: usize = std::env::var("CASITA_SNAPSHOT_ITERATIONS")
            .unwrap()
            .parse()
            .unwrap();
        let mode = std::env::var("CASITA_SNAPSHOT_MODE").unwrap();
        assert!(width > 0 && iterations > 0);
        assert!(matches!(mode.as_str(), "reused" | "fresh"));
        let temp = tempfile::tempdir().unwrap();
        let database = TursoDb::open(temp.path().join("casita.sqlite")).unwrap();
        database.writer.lock().await.execute_batch(
            "INSERT INTO repository_state(singleton, revision, generation) VALUES (1, X'01', 0);"
        ).await.unwrap();
        let mut elapsed = std::time::Duration::ZERO;
        for generation in 0..=iterations {
            // Commit outside the measured burst. Each lease must observe the
            // new state, including reused connections from the previous burst.
            database
                .writer
                .lock()
                .await
                .execute_batch(format!(
                    "UPDATE repository_state SET generation = {generation};"
                ))
                .await
                .unwrap();
            let started = std::time::Instant::now();
            let readers = futures::future::try_join_all((0..width).map(|_| async {
                let connection = database.begin_read_snapshot().await.unwrap();
                assert_eq!(snapshot_generation(&connection).await, generation as i64);
                Ok::<_, Error>(connection)
            }))
            .await
            .unwrap();
            drop(readers);
            if mode == "fresh" {
                database.idle_readers.lock().unwrap().clear();
            }
            let duration = started.elapsed();
            if generation > 0 {
                elapsed += duration;
            }
            let idle = database.idle_readers.lock().unwrap();
            assert_eq!(
                idle.len(),
                if mode == "fresh" {
                    0
                } else {
                    width.min(IDLE_READ_CONNECTIONS)
                }
            );
            assert!(
                idle.iter()
                    .all(|connection| connection.is_autocommit().unwrap())
            );
        }
        let reader = database.begin_read_snapshot().await.unwrap();
        assert!(
            reader
                .execute_batch("DELETE FROM repository_state;")
                .await
                .is_err()
        );
        drop(reader);
        println!(
            "snapshot_connection_sample {}",
            serde_json::json!({
                "width": width, "iterations": iterations, "mode": mode,
                "idle_limit": IDLE_READ_CONNECTIONS, "wall_nanos": elapsed.as_nanos() as u64,
                "correctness": "fresh committed generation, query-only, bounded idle cache, no idle transaction"
            })
        );
    }

    fn user_version(database: &Arc<TursoDb>) -> i64 {
        futures::executor::block_on(async {
            let writer = database.writer.lock().await;
            let mut rows = writer.query("PRAGMA user_version", ()).await.unwrap();
            rows.next().await.unwrap().unwrap().get(0).unwrap()
        })
    }

    fn set_user_version(database: &Arc<TursoDb>, version: i64) {
        futures::executor::block_on(async {
            database
                .writer
                .lock()
                .await
                .execute_batch(format!("PRAGMA user_version = {version};"))
                .await
                .unwrap();
        });
    }

    #[test]
    fn fresh_database_starts_at_current_schema_and_reopens_without_migration() {
        let temp = tempfile::tempdir().unwrap();
        let path = temp.path().join("casita.sqlite");

        let database = TursoDb::open(&path).unwrap();
        assert_eq!(user_version(&database), REPOSITORY_USER_VERSION);
        drop(database);

        let reopened = TursoDb::open(&path).unwrap();
        assert_eq!(user_version(&reopened), REPOSITORY_USER_VERSION);
    }

    #[test]
    fn version_four_metadata_migration_preserves_existing_state() {
        let temp = tempfile::tempdir().unwrap();
        let path = temp.path().join("casita.sqlite");
        let database = TursoDb::open(&path).unwrap();
        futures::executor::block_on(async {
            database.writer.lock().await.execute_batch(
                "INSERT INTO repository_state(singleton, revision, generation) VALUES (1, X'010203', 42); ALTER TABLE repository_state RENAME COLUMN payload_catalog_ref TO payload_catalog; DROP TABLE metadata_records; PRAGMA user_version = 4;"
            ).await.unwrap();
        });
        drop(database);
        let database = TursoDb::open(&path).unwrap();
        assert_eq!(user_version(&database), REPOSITORY_USER_VERSION);
        futures::executor::block_on(async {
            let writer = database.writer.lock().await;
            let mut rows = writer
                .query("SELECT generation FROM repository_state", ())
                .await
                .unwrap();
            assert_eq!(
                rows.next().await.unwrap().unwrap().get::<i64>(0).unwrap(),
                42
            );
            let mut rows = writer
                .query("SELECT count(*) FROM metadata_records", ())
                .await
                .unwrap();
            assert_eq!(
                rows.next().await.unwrap().unwrap().get::<i64>(0).unwrap(),
                0
            );
        });
    }

    #[test]
    fn existing_nonrelease_schema_versions_are_rejected() {
        let temp = tempfile::tempdir().unwrap();

        for version in [0, 1, 2, 3, 7] {
            let path = temp.path().join(format!("schema-{version}.sqlite"));
            let database = TursoDb::open(&path).unwrap();
            set_user_version(&database, version);
            drop(database);

            let error = TursoDb::open(&path).unwrap_err().to_string();
            assert!(error.contains(&format!("unsupported schema version {version}")));
            assert!(error.contains(&format!("supports only version {REPOSITORY_USER_VERSION}")));
            assert!(error.contains("does not migrate pre-release repositories"));
        }
    }

    #[test]
    fn catalog_schema_migration_fences_an_already_prepared_legacy_writer() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("casita.sqlite");
        let database = TursoDb::open(&path).unwrap();
        futures::executor::block_on(async {
            let writer = database.writer.lock().await;
            writer.execute_batch("INSERT INTO repository_state(singleton, revision, payload_catalog_ref) VALUES(1, X'01', X'0203'); ALTER TABLE repository_state RENAME COLUMN payload_catalog_ref TO payload_catalog; PRAGMA user_version = 5;").await.unwrap();
        });
        let legacy = database.database.connect().unwrap();
        let mut prepared = futures::executor::block_on(legacy.prepare("UPDATE repository_state SET revision = X'04', payload_catalog = COALESCE(NULL, payload_catalog) WHERE singleton = 1")).unwrap();
        let migrated = TursoDb::open(&path).unwrap();
        futures::executor::block_on(async {
            assert!(
                prepared.execute(()).await.is_err(),
                "old cached publication SQL must fail after migration"
            );
            let writer = migrated.writer.lock().await;
            let mut rows = writer
                .query(
                    "SELECT revision, payload_catalog_ref FROM repository_state",
                    (),
                )
                .await
                .unwrap();
            let row = rows.next().await.unwrap().unwrap();
            assert_eq!(row.get::<Vec<u8>>(0).unwrap(), vec![1]);
            assert_eq!(row.get::<Vec<u8>>(1).unwrap(), vec![2, 3]);
        });
    }
}
