//! Generic repository facade over physical payloads and revisioned state.
//!
//! Durable pins retain staged payloads and held snapshots during collection.
//! Collector ownership serializes maintenance; pin admission and deletion
//! claims coordinate data lifetimes across independent repository handles.

use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Duration;

use async_trait::async_trait;
use bytes::Bytes;
use futures::{StreamExt, TryStreamExt};
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWriteExt};
use tokio::sync::{Mutex as AsyncMutex, OwnedMutexGuard};

use crate::blob::{BlobReader, BlobStore, is_integrity_error, is_integrity_io_error};
use crate::coordination::{ExclusiveLease, FsCoordination};
use crate::directory::Directory;
use crate::export::DirectorySource;
use crate::filesystem::FilesystemEntry;
use crate::format::{
    BlobFormat, DirectLinkView, DirectoryFormat, FormatError, FormatLimits, FormatRegistry,
    PayloadReader, VerificationContext, VerifiedObject,
};
use crate::metadata::{
    CommitResult, MetadataError, MetadataMutation, MetadataSnapshot, MetadataStore, RootChange,
};
use crate::object::{ObjectKey, ObjectRecord, RootName};
use crate::path::{PathComponent, SymlinkTarget};
use crate::spill::{
    FrozenSpillSet, SpillArea, SpillLimits, SpillMetrics, SpillSet, TraversalQueue,
};
use crate::{BlobGc, BlobId, ChunkId, Digest, DirectoryId, Node};

mod collection_timing;
#[cfg(test)]
mod mutation_catalog_tests;
mod publication;
use collection_timing::CollectionPhase;
use publication::Publication;

/// Semantic result of checking one object's complete forward graph.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ClosureStatus {
    /// Every reachable record and payload exists and all format relations hold.
    Complete {
        /// Distinct objects traversed, including the root itself.
        ///
        /// The traversal spills past its memory budget, so the set itself is
        /// deliberately not returned: a complete closure can be larger than
        /// the process that verified it.
        objects: usize,
    },
    /// One deterministic reachable boundary is absent.
    Missing {
        /// Object containing the missing link, or `None` for the requested
        /// root itself.
        from: Option<ObjectKey>,
        /// First missing key in breadth-first canonical traversal.
        missing: ObjectKey,
    },
    /// An object, payload, or intrinsic direct-link relation is invalid.
    Invalid {
        /// Object at which validation failed.
        object: ObjectKey,
        /// Stable human-readable reason; callers classify the variant rather
        /// than parsing this text.
        reason: String,
    },
    /// A reachable namespace has no registered verifier.
    Unsupported {
        /// Object that selected the unavailable namespace.
        object: ObjectKey,
    },
}

/// One root value that must still match before a conditional mutation can
/// commit.
///
/// `None` requires the name to be absent. Expectations are checked again after
/// every repository revision race, so unrelated mutations can be retried
/// without overwriting a concurrently changed root.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RootExpectation {
    /// Exact root name to compare.
    pub name: RootName,
    /// Exact required target, or `None` when the root must be absent.
    pub target: Option<ObjectKey>,
}

/// Outcome of a mutation guarded by root-value expectations.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConditionalPublishResult {
    /// Staged objects and root changes committed atomically.
    Committed(CommitResult),
    /// A watched root no longer has the value used to derive the mutation.
    RootMismatch {
        /// First mismatched name in canonical root-name order.
        name: RootName,
        /// Value required by the caller.
        expected: Option<ObjectKey>,
        /// Value observed in the current snapshot.
        actual: Option<ObjectKey>,
    },
}

/// Errors from repository orchestration rather than object validity.
#[derive(Debug, thiserror::Error)]
#[non_exhaustive]
pub enum RepositoryError {
    /// A requested generic repository item is absent.
    #[error("repository item is absent: {0}")]
    Absent(String),
    /// Physical payload bytes expected by a staged or committed record are
    /// absent.
    #[error("payload {0} is missing from physical storage")]
    MissingPayload(BlobId),
    /// A physical store returned bytes under the wrong content identity.
    #[error("payload store returned {actual} while opening {expected}")]
    PayloadIdentityMismatch {
        /// Address requested from storage.
        expected: BlobId,
        /// Digest observed by the format verifier.
        actual: BlobId,
    },
    /// A physical writer reported a byte count different from the source it
    /// consumed.
    #[error("payload writer returned size {actual}, expected {expected}")]
    PayloadSizeMismatch {
        /// Number of source bytes written.
        expected: u64,
        /// Number of bytes reported by the completed writer.
        actual: u64,
    },
    /// A requested root is not complete and valid.
    #[error("cannot publish root {root}: closure is {status:?}")]
    RootNotPublishable {
        /// Requested root target.
        root: ObjectKey,
        /// Exact closure result.
        status: ClosureStatus,
    },
    /// A requested read requires a complete valid closure.
    #[error("cannot read object {object}: closure is {status:?}")]
    ObjectNotReadable {
        /// Requested object.
        object: ObjectKey,
        /// Exact closure result.
        status: ClosureStatus,
    },
    /// Two staged values claim different records under one immutable key.
    #[error("staged immutable object conflict at {0}")]
    StagedConflict(ObjectKey),
    /// A staged value was verified against a different repository instance.
    #[error("staged object {0} belongs to a different repository")]
    ForeignStagedObject(ObjectKey),
    /// A caller request cannot be represented by the selected repository
    /// operation.
    #[error("invalid repository input: {0}")]
    InvalidInput(String),
    /// A bounded operation exceeded its configured deployment limit.
    #[error("repository limit exceeded: {0}")]
    LimitExceeded(String),
    /// A caller requested a nonblocking operation while its required
    /// ownership was held elsewhere.
    #[error("repository is busy: {0}")]
    Busy(String),
    /// An unheld best-effort read lost unrooted data to collection.
    #[error("object {0} was collected during a best-effort read")]
    CollectedDuringRead(ObjectKey),
    /// Format verification failed while staging a payload.
    #[error(transparent)]
    Format(#[from] FormatError),
    /// Revisioned state operation failed.
    #[error(transparent)]
    Metadata(#[from] MetadataError),
    /// Physical payload storage failed.
    #[error(transparent)]
    Payload(#[from] crate::error::Error),
    /// Streaming a staged payload failed.
    #[error(transparent)]
    Io(#[from] std::io::Error),
}

/// Stable error categories shared by repository operations and frontends.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[non_exhaustive]
pub enum RepositoryErrorCategory {
    /// A requested object, root, or payload is absent.
    Absent,
    /// A caller supplied a malformed or over-limit request.
    InvalidInput,
    /// Stored or supplied object data failed verification.
    InvalidData,
    /// One immutable key already names a different record.
    ImmutableConflict,
    /// The expected state revision is obsolete.
    StaleRevision,
    /// A filesystem destination is already occupied.
    DestinationConflict,
    /// Required ownership is held elsewhere.
    Busy,
    /// A namespace, format, or backend capability is unavailable.
    Unsupported,
    /// Committed state violates a repository invariant.
    Corrupt,
    /// Unrooted data disappeared during a best-effort read.
    CollectedDuringRead,
    /// An I/O, backend, or other operational failure occurred.
    Backend,
}

impl RepositoryErrorCategory {
    /// Stable machine-readable spelling.
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Absent => "absent",
            Self::InvalidInput => "invalid_input",
            Self::InvalidData => "invalid_data",
            Self::ImmutableConflict => "immutable_conflict",
            Self::StaleRevision => "stale_revision",
            Self::DestinationConflict => "destination_conflict",
            Self::Busy => "busy",
            Self::Unsupported => "unsupported",
            Self::Corrupt => "corrupt",
            Self::CollectedDuringRead => "collected_during_read",
            Self::Backend => "backend",
        }
    }
}

fn is_storage_full(error: &RepositoryError) -> bool {
    // Transparent error wrappers may omit their immediate inner error from
    // source(), so preserve the physical/metadata boundary explicitly.
    let error: &(dyn std::error::Error + 'static) = match error {
        RepositoryError::Metadata(MetadataError::StorageFull) => return true,
        RepositoryError::Io(error) | RepositoryError::Payload(crate::error::Error::Io(error)) => {
            error
        }
        RepositoryError::Payload(crate::error::Error::Backend(error)) => error.as_ref(),
        RepositoryError::Payload(error) => error,
        _ => error,
    };
    let mut current = Some(error);
    while let Some(error) = current {
        if matches!(
            error.downcast_ref::<MetadataError>(),
            Some(MetadataError::StorageFull)
        ) {
            return true;
        }
        if let Some(io) = error.downcast_ref::<std::io::Error>() {
            if io.kind() == std::io::ErrorKind::StorageFull {
                return true;
            }
            current = io
                .get_ref()
                .map(|inner| inner as &(dyn std::error::Error + 'static));
        } else {
            current = error.source();
        }
    }
    false
}

impl RepositoryError {
    /// Classify this failure without parsing its display text.
    pub fn category(&self) -> RepositoryErrorCategory {
        use RepositoryErrorCategory as Category;

        match self {
            Self::Absent(_) => Category::Absent,
            Self::MissingPayload(_) => Category::Absent,
            Self::PayloadIdentityMismatch { .. } | Self::PayloadSizeMismatch { .. } => {
                Category::InvalidData
            }
            Self::RootNotPublishable { status, .. } => match status {
                ClosureStatus::Missing { .. } => Category::Absent,
                ClosureStatus::Invalid { .. } => Category::InvalidData,
                ClosureStatus::Unsupported { .. } => Category::Unsupported,
                ClosureStatus::Complete { .. } => Category::InvalidData,
            },
            Self::ObjectNotReadable { status, .. } => match status {
                ClosureStatus::Missing { .. } => Category::Absent,
                ClosureStatus::Invalid { .. } => Category::InvalidData,
                ClosureStatus::Unsupported { .. } => Category::Unsupported,
                ClosureStatus::Complete { .. } => Category::InvalidData,
            },
            Self::StagedConflict(_) => Category::ImmutableConflict,
            Self::ForeignStagedObject(_) | Self::InvalidInput(_) | Self::LimitExceeded(_) => {
                Category::InvalidInput
            }
            Self::Busy(_) => Category::Busy,
            Self::CollectedDuringRead(_) => Category::CollectedDuringRead,
            Self::Format(error) => match error {
                FormatError::MissingDirectLink { .. } => Category::Absent,
                FormatError::UnsupportedNamespace(_) => Category::Unsupported,
                FormatError::DuplicateNamespace(_) => Category::InvalidInput,
                FormatError::Io(_) => Category::Backend,
                _ => Category::InvalidData,
            },
            Self::Metadata(error) => match error {
                MetadataError::StorageFull => Category::Backend,
                MetadataError::UnsupportedMetadata => Category::Unsupported,
                MetadataError::InvalidMetadata(_) => Category::InvalidInput,
                MetadataError::RootVerificationRequired => Category::InvalidInput,
                MetadataError::CheckFailed { .. } => Category::DestinationConflict,
                MetadataError::StaleRevision { .. } => Category::StaleRevision,
                MetadataError::ImmutableConflict(_) => Category::ImmutableConflict,
                MetadataError::MissingObject { .. } => Category::Absent,
                MetadataError::InvalidRetainedSet(_) | MetadataError::MixedCollectionMutation => {
                    Category::InvalidInput
                }
                MetadataError::Corruption(_) => Category::Corrupt,
                MetadataError::Poisoned
                | MetadataError::RevisionEntropy(_)
                | MetadataError::Transient(_)
                | MetadataError::Backend(_) => Category::Backend,
            },
            Self::Payload(error) => match error {
                crate::error::Error::NotFound { .. } => Category::Absent,
                crate::error::Error::TargetNotEmpty { .. }
                | crate::error::Error::TargetNameConflict { .. } => Category::DestinationConflict,
                crate::error::Error::LimitExceeded(_) => Category::InvalidInput,
                crate::error::Error::Digest(_)
                | crate::error::Error::Directory(_)
                | crate::error::Error::PathComponent(_)
                | crate::error::Error::SymlinkTarget(_) => Category::InvalidData,
                crate::error::Error::Io(_)
                | crate::error::Error::Msg(_)
                | crate::error::Error::Transient(_)
                | crate::error::Error::Throttled { .. }
                | crate::error::Error::Backend(_) => Category::Backend,
            },
            Self::Io(_) => Category::Backend,
        }
    }

    /// Typed retry guidance propagated from coordination, state
    /// compare-and-swap, I/O, and payload backends.
    pub fn retry_disposition(&self) -> crate::RetryDisposition {
        use crate::RetryDisposition;

        match self {
            Self::Busy(_)
            | Self::Metadata(MetadataError::StaleRevision { .. })
            | Self::Metadata(MetadataError::Transient(_)) => RetryDisposition::Retry,
            Self::Payload(error) => error.retry_disposition(),
            Self::Io(error) | Self::Format(FormatError::Io(error)) => {
                crate::error::wrapped_retry_disposition(error)
            }
            Self::Metadata(MetadataError::Backend(_)) | Self::Metadata(MetadataError::Poisoned) => {
                RetryDisposition::Unknown
            }
            Self::Metadata(MetadataError::StorageFull) => RetryDisposition::Retry,
            Self::Absent(_)
            | Self::MissingPayload(_)
            | Self::PayloadIdentityMismatch { .. }
            | Self::PayloadSizeMismatch { .. }
            | Self::RootNotPublishable { .. }
            | Self::ObjectNotReadable { .. }
            | Self::StagedConflict(_)
            | Self::ForeignStagedObject(_)
            | Self::InvalidInput(_)
            | Self::LimitExceeded(_)
            | Self::CollectedDuringRead(_)
            | Self::Format(_)
            | Self::Metadata(_) => RetryDisposition::Never,
        }
    }
}

/// A verified payload staged in this repository during a live mutation
/// session. Its private seal prevents publishing verification performed
/// against another physical store.
#[derive(Debug)]
pub struct StagedObject<'hold> {
    verified: VerifiedObject,
    repository: Arc<()>,
    _hold: std::marker::PhantomData<&'hold ()>,
}

impl StagedObject<'_> {
    /// Verified immutable record that mutation will install.
    pub fn record(&self) -> &ObjectRecord {
        self.verified.record()
    }
}

/// Candidate counts from a mark pass, shared by dry-run and real collection.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct CollectionPreview {
    /// Unreachable immutable logical records.
    pub logical_objects: usize,
    /// Unreferenced physical blob manifests or whole-blob entries.
    pub payload_blobs: usize,
    /// Unreferenced physical chunks.
    pub chunks: usize,
}

/// Candidate count from a logical-only mark pass.
///
/// Logical collection is for repositories whose payload backend does not own
/// physical deletion, such as a remote backend that shares payload bytes with
/// other repositories. It prunes unreachable records but deliberately makes
/// no statement about reclaimable blobs or chunks.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct LogicalCollectionPreview {
    /// Unreachable immutable logical records.
    pub logical_objects: usize,
}

/// Completed generic collection outcome.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct CollectionOutcome {
    /// Fresh logical revision, or `None` when no logical records needed pruning.
    pub revision: Option<crate::RepositoryRevision>,
    /// What the mark pass selected for removal.
    pub removed: CollectionPreview,
    /// Temporary traversal-state use while computing this collection plan.
    pub spill: SpillMetrics,
}

/// Completed logical-only collection outcome.
///
/// The remote payload service, not this per-repository operation, owns any
/// later physical reclamation.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct LogicalCollectionOutcome {
    /// Fresh logical revision, or `None` when no logical records needed pruning.
    pub revision: Option<crate::RepositoryRevision>,
    /// What the mark pass selected for logical removal.
    pub removed: LogicalCollectionPreview,
    /// Temporary traversal-state use while computing this collection plan.
    pub spill: SpillMetrics,
}

/// How an integrity finding affects repository correctness.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsckDisposition {
    /// Reachable state violates a repository invariant.
    Corrupt,
    /// Unrooted staging residue or unreferenced physical data may be collected.
    Collectible,
    /// Exact validation could not run because a format is unavailable.
    Unchecked,
}

/// Stable category of an integrity finding.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsckIssueKind {
    /// Primary state could not be decoded or enumerated.
    StateEncoding,
    /// A stored forward link or root target has no record.
    MissingRecord,
    /// A record's payload is physically absent.
    MissingPayload,
    /// Payload identity, canonical encoding, stored links, or a direct relation
    /// failed verification.
    InvalidObject,
    /// No verifier is registered for the object's namespace.
    UnsupportedNamespace,
    /// A valid logical record is unreachable from every named root.
    UnrootedObject,
    /// Physical data is referenced by no logical record.
    UnreferencedPayload,
    /// A physical chunk is referenced by no present logical payload.
    UnreferencedChunk,
}

/// One deterministic integrity finding.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FsckIssue {
    /// Correctness disposition.
    pub disposition: FsckDisposition,
    /// Machine-readable category.
    pub kind: FsckIssueKind,
    /// Logical object involved, when one can be identified.
    pub object: Option<ObjectKey>,
    /// Human-readable detail.
    pub message: String,
}

/// Integrity report over one logical snapshot and an exclusively held physical
/// store view.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FsckReport {
    /// Exact logical revision inspected.
    pub revision: crate::RepositoryRevision,
    /// Successfully decoded logical records inspected.
    pub objects_checked: usize,
    /// Successfully decoded named roots inspected.
    pub roots_checked: usize,
    /// Unique record payload identities checked.
    pub payloads_checked: usize,
    /// Temporary traversal-state use while inspecting this repository.
    pub spill: SpillMetrics,
    /// Findings in deterministic logical order followed by physical order.
    pub issues: Vec<FsckIssue>,
}

/// The remaining condition of one physical representation after an fsck repair.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsckRepairFindingKind {
    /// A payload named by an authoritative record is absent.
    MissingPayload,
    /// A payload failed a checksum, size, manifest, or chunk verification.
    CorruptPayload,
    /// A payload could not be checked because storage returned an unrelated
    /// operational failure.
    UnavailablePayload,
    /// An existing Bao outboard does not match the verified payload.
    CorruptOutboard,
    /// An existing Bao outboard could not be read or verified.
    UnavailableOutboard,
}

/// One unresolved physical-storage condition reported by [`FsckRepairReport`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FsckRepairFinding {
    /// Stable category of the condition.
    pub kind: FsckRepairFindingKind,
    /// Authoritative payload identity affected by the condition.
    pub payload: BlobId,
    /// Expected plaintext payload bytes, when known from the object record.
    pub bytes: u64,
    /// Human-readable backend or verification detail.
    pub message: String,
}

/// A safe physical action an fsck repair can plan or complete.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsckRepairActionKind {
    /// Replaced a missing or corrupt local representation from a replica.
    RepairPayloadFromReplica,
    /// Recomputed an existing Bao outboard from verified payload bytes.
    RebuildOutboard,
}

/// Whether an fsck-repair action was only reported or actually completed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsckRepairActionStatus {
    /// Dry-run found an action that a normal fsck repair would perform.
    Planned,
    /// The action completed and its replacement was verified before use.
    Repaired,
}

/// One safe action reported by [`FsckRepairReport`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FsckRepairAction {
    /// What the fsck repair rebuilt or replaced.
    pub kind: FsckRepairActionKind,
    /// Payload identity whose representation was affected.
    pub payload: BlobId,
    /// Plaintext bytes represented by the action.
    pub bytes: u64,
    /// Whether this was a dry-run plan or a completed repair.
    pub status: FsckRepairActionStatus,
}

/// Physical integrity report for one retained repository snapshot.
///
/// A normal fsck repair repairs only a corrupt local representation when an
/// independently verified replica is supplied, and rebuilds an already
/// present Bao outboard. It never modifies object records, roots, or other
/// logical state.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FsckRepairReport {
    /// Exact logical snapshot whose authoritative payload identities were
    /// inspected.
    pub revision: crate::RepositoryRevision,
    /// Unique payload identities inspected.
    pub payloads_checked: usize,
    /// Plaintext bytes completely verified from the local representation.
    pub bytes_checked: u64,
    /// Existing Bao outboards compared against recomputed values.
    pub outboards_checked: usize,
    /// Repairs planned or performed, in payload order.
    pub actions: Vec<FsckRepairAction>,
    /// Conditions that could not be safely repaired.
    pub findings: Vec<FsckRepairFinding>,
    /// Temporary traversal-state use while deduplicating payload identities.
    pub spill: SpillMetrics,
}

impl FsckRepairReport {
    /// Whether every inspected physical representation is healthy after the
    /// requested fsck-repair mode completed.
    pub fn is_healthy(&self) -> bool {
        self.findings.is_empty()
    }
}

impl FsckReport {
    /// Whether no reachable corruption was found. Unrooted garbage and
    /// unavailable format implementations do not make this false.
    pub fn is_healthy(&self) -> bool {
        !self
            .issues
            .iter()
            .any(|issue| issue.disposition == FsckDisposition::Corrupt)
    }

    /// Whether every object could be checked with no findings of any kind.
    pub fn is_clean(&self) -> bool {
        self.issues.is_empty()
    }
}

type OpenedObject = (ObjectRecord, Box<dyn BlobReader>);

/// Generic repository over one physical payload store and one logical state
/// store.
pub struct Repository<PS, SS> {
    payloads: Arc<PS>,
    state: Arc<SS>,
    formats: FormatRegistry,
    limits: FormatLimits,
    coordination: Arc<AsyncMutex<()>>,
    publication: Publication,
    #[cfg(test)]
    publication_profile: Arc<std::sync::Mutex<PublicationProfile>>,
    fs_coordination: Option<Arc<FsCoordination>>,
    /// Optional deployment hook run before a mutation registers its staging
    /// pin. The standard local profile uses it for once-per-handle
    /// disk-pressure collection; generic compositions have no implicit
    /// scheduling policy.
    mutation_start: Option<Arc<dyn MutationStart>>,
    /// Remembers which content each imported file held, so an unchanged file
    /// is not read again. A local accelerator, absent from generic
    /// compositions, and never something a reader depends on.
    ingest_cache: Option<Arc<dyn crate::filesystem::IngestCache>>,
    emergency_collection: bool,
    staging_identity: Arc<()>,
    /// Where traversal state spills once it outgrows memory, and how large it
    /// may grow. `None` selects the platform temporary directory, which is what
    /// a repository composed without a filesystem root has.
    spill_directory: Option<PathBuf>,
    spill_limits: SpillLimits,
}

impl<PS, SS> Clone for Repository<PS, SS> {
    fn clone(&self) -> Self {
        Self {
            payloads: self.payloads.clone(),
            state: self.state.clone(),
            formats: self.formats.clone(),
            limits: self.limits.clone(),
            coordination: self.coordination.clone(),
            publication: self.publication.clone(),
            #[cfg(test)]
            publication_profile: self.publication_profile.clone(),
            fs_coordination: self.fs_coordination.clone(),
            mutation_start: self.mutation_start.clone(),
            ingest_cache: self.ingest_cache.clone(),
            emergency_collection: self.emergency_collection,
            staging_identity: self.staging_identity.clone(),
            spill_directory: self.spill_directory.clone(),
            spill_limits: self.spill_limits,
        }
    }
}

/// Phase measurements for the permanent object-read benchmark; no production timers.
#[cfg(test)]
#[derive(Default)]
pub(crate) struct ObjectReadProfile {
    /// Benchmark control: retain the previous durable object-read protocol.
    pub durable_readers: bool,
    pub admission_nanos: u64,
    pub resolve_nanos: u64,
    pub pause_after_pin: Option<(
        tokio::sync::oneshot::Sender<()>,
        tokio::sync::oneshot::Receiver<()>,
    )>,
}

#[cfg(test)]
pub(crate) const PUBLICATION_PHASES: [&str; 6] = [
    "coordination_wait",
    "snapshot",
    "validation",
    "payload_prepare",
    "state_commit",
    "payload_finish",
];

#[cfg(test)]
#[derive(Clone, Copy, Default)]
pub(crate) struct PublicationProfile {
    pub(crate) calls: [u64; 6],
    pub(crate) nanos: [u64; 6],
}

#[cfg(test)]
struct PublicationTimer<'a> {
    profile: &'a std::sync::Mutex<PublicationProfile>,
    phase: usize,
    started: std::time::Instant,
}

#[cfg(test)]
impl Drop for PublicationTimer<'_> {
    fn drop(&mut self) {
        let nanos = self
            .started
            .elapsed()
            .as_nanos()
            .try_into()
            .unwrap_or(u64::MAX);
        let mut profile = self.profile.lock().unwrap();
        profile.calls[self.phase] += 1;
        profile.nanos[self.phase] += nanos;
    }
}

impl<PS, SS> Repository<PS, SS> {
    /// Erase backend types without rebuilding the repository's coordination,
    /// publication, retention, or cache state. Useful for applications sharing
    /// one content domain between local stores, builders, and transfer services.
    #[cfg(feature = "experimental")]
    pub fn into_erased(self) -> Repository<Arc<dyn BlobGc>, Arc<dyn MetadataStore>>
    where
        PS: BlobGc + 'static,
        SS: MetadataStore + 'static,
    {
        self.into_builtin()
    }

    /// Open an application retained reader without rebuilding this repository's
    /// coordination or caches. Lookup and opening share one protected snapshot.
    #[cfg(feature = "experimental")]
    pub async fn retained_reader(&self) -> Result<crate::RetainedReader, RepositoryError>
    where
        PS: BlobGc + 'static,
        SS: MetadataStore + 'static,
    {
        let hold = self.clone().into_builtin().owned_read_hold().await?;
        Ok(crate::RetainedReader::new(hold))
    }

    /// Erase built-in backend types while preserving the exact coordination,
    /// admission, staging, and cache state established by the constructor.
    pub(crate) fn into_builtin(self) -> Repository<Arc<dyn BlobGc>, Arc<dyn MetadataStore>>
    where
        PS: BlobGc + 'static,
        SS: MetadataStore + 'static,
    {
        Repository {
            payloads: Arc::new(self.payloads as Arc<dyn BlobGc>),
            state: Arc::new(self.state as Arc<dyn MetadataStore>),
            formats: self.formats,
            limits: self.limits,
            coordination: self.coordination,
            publication: self.publication,
            #[cfg(test)]
            publication_profile: self.publication_profile,
            fs_coordination: self.fs_coordination,
            mutation_start: self.mutation_start,
            ingest_cache: self.ingest_cache,
            emergency_collection: self.emergency_collection,
            staging_identity: self.staging_identity,
            spill_directory: self.spill_directory,
            spill_limits: self.spill_limits,
        }
    }

    /// Import an external input through its format-specific request.
    #[cfg(feature = "experimental")]
    pub async fn import<I: crate::Importer<Self>>(&self, input: I) -> Result<I::Report, I::Error> {
        input.import(self).await
    }

    #[cfg(not(feature = "experimental"))]
    pub(crate) async fn import<I: crate::importer::BackendImporter<Self>>(
        &self,
        input: I,
    ) -> Result<I::Report, I::Error> {
        input.import_into(self).await
    }

    /// Compose physical payloads and revisioned metadata with all current
    /// production formats through v0.5.
    ///
    /// The metadata backend must coordinate retention with the actual payload
    /// storage. Merely pairing independent stores does not establish a shared
    /// collection boundary across processes or services.
    /// Publication capabilities are selected once here, before payload writes.
    /// Backends must own their dependencies (`'static`) so an admitted publication
    /// can finish safely after its caller is cancelled. They need not be `Clone`.
    pub fn new(payloads: PS, metadata: SS) -> Self
    where
        PS: BlobStore + 'static,
        SS: MetadataStore + 'static,
    {
        Self::with_formats(
            payloads,
            metadata,
            FormatRegistry::builtin(),
            FormatLimits::default(),
        )
    }

    /// Compose a repository with an explicit immutable format registry and
    /// deployment limits.
    pub fn with_formats(
        payloads: PS,
        metadata: SS,
        formats: FormatRegistry,
        limits: FormatLimits,
    ) -> Self
    where
        PS: BlobStore + 'static,
        SS: MetadataStore + 'static,
    {
        let payloads = Arc::new(payloads);
        let metadata = Arc::new(metadata);
        let publication = Publication::new(payloads.clone(), metadata.clone());
        Self {
            payloads,
            state: metadata,
            formats,
            limits,
            coordination: Arc::new(AsyncMutex::new(())),
            publication,
            #[cfg(test)]
            publication_profile: Arc::default(),
            fs_coordination: None,
            mutation_start: None,
            ingest_cache: None,
            emergency_collection: false,
            staging_identity: Arc::new(()),
            spill_directory: None,
            spill_limits: SpillLimits::default(),
        }
    }

    /// Extend retention/collection ownership across every process opening the
    /// same local repository root.
    ///
    /// Traversal state also spills below this root rather than into the
    /// platform temporary directory, so its bytes are accounted against the
    /// repository's own filesystem.
    pub fn with_fs_coordination(mut self, root: impl AsRef<Path>) -> Self {
        let root = root.as_ref();
        self.fs_coordination = Some(Arc::new(FsCoordination::new(root)));
        self.spill_directory = Some(root.join(crate::spill::SPILL_DIRECTORY));
        self
    }

    #[cfg(test)]
    pub(crate) fn publication_profile(&self) -> PublicationProfile {
        *self.publication_profile.lock().unwrap()
    }

    #[cfg(test)]
    pub(crate) fn pause_catalog_maintenance_for_test(&self) -> Arc<publication::MaintenancePause> {
        self.publication.pause_maintenance()
    }

    #[cfg(test)]
    fn time_publication_phase(&self, phase: usize) -> PublicationTimer<'_> {
        PublicationTimer {
            profile: &self.publication_profile,
            phase,
            started: std::time::Instant::now(),
        }
    }

    /// Bound the memory and temporary bytes a traversal may use before, and
    /// after, it spills to local storage.
    pub fn with_spill_limits(mut self, limits: SpillLimits) -> Self {
        self.spill_limits = limits;
        self
    }

    /// Active traversal spill bounds.
    pub fn spill_limits(&self) -> SpillLimits {
        self.spill_limits
    }

    /// Where this repository's traversals spill, and how far they may grow.
    pub(crate) fn spill_area(&self) -> SpillArea {
        SpillArea::new(self.spill_directory.clone(), self.spill_limits)
    }

    /// What one closure verification needs from this repository.
    fn closure_verifier(&self) -> ClosureVerifier<'_, PS> {
        ClosureVerifier {
            payloads: &self.payloads,
            formats: &self.formats,
            limits: &self.limits,
            area: self.spill_area(),
        }
    }

    /// Physical payload backend.
    pub fn payloads(&self) -> &PS {
        &self.payloads
    }

    /// Revisioned metadata backend for object records, roots, and catalogs.
    pub fn metadata(&self) -> &SS {
        &self.state
    }

    /// Registered deterministic object formats.
    pub fn formats(&self) -> &FormatRegistry {
        &self.formats
    }

    /// Active deployment and hostile-input limits.
    pub fn limits(&self) -> &FormatLimits {
        &self.limits
    }
}

impl Repository<crate::MemoryBlobStore, crate::MemoryMetadataStore> {
    /// Create an ephemeral full repository.
    pub fn memory() -> Result<Self, RepositoryError> {
        Ok(Self::new(
            crate::MemoryBlobStore::new(),
            crate::MemoryMetadataStore::new()?,
        ))
    }
}

impl Repository<crate::ChunkedBlobStore, crate::TursoMetadataStore> {
    /// Open the standard persistent local profile under `root`.
    ///
    /// Payloads live below `<root>/blobs`, revisioned logical state lives in
    /// `<root>/casita.sqlite`, and lock files under `root` coordinate
    /// mutation, stable reads, and collection across processes. Repeated pack
    /// reads use the default bounded adaptive range and pack cache.
    pub async fn local(root: impl AsRef<Path>) -> Result<Self, RepositoryError> {
        Self::local_with_pack_target(root, crate::DEFAULT_LOCAL_PACK_TARGET_SIZE).await
    }

    /// Open the standard local profile with an explicit compressed pack target.
    ///
    /// This has the same format and durability guarantees as [`Self::local`];
    /// only the approximate size at which a staged pack is sealed changes.
    pub async fn local_with_pack_target(
        root: impl AsRef<Path>,
        pack_target_size: u64,
    ) -> Result<Self, RepositoryError> {
        Self::local_with_pack_options(
            root,
            pack_target_size,
            crate::DEFAULT_PACK_CACHE_CAPACITY,
            crate::DEFAULT_PACK_CACHE_PROMOTION_READS,
        )
        .await
    }

    /// Open the local profile with explicit immutable-pack cache tuning.
    ///
    /// The cache is process-local and bounded. Set `pack_cache_capacity` to
    /// zero to disable payload caching; `pack_cache_promotion_reads` must
    /// remain at least one.
    #[tracing::instrument(
        name = "repository.open",
        skip_all,
        fields(
            profile = "local",
            pack_target_bytes = pack_target_size,
            pack_cache_bytes = pack_cache_capacity,
            pack_cache_promotion_reads = pack_cache_promotion_reads
        )
    )]
    pub async fn local_with_pack_options(
        root: impl AsRef<Path>,
        pack_target_size: u64,
        pack_cache_capacity: u64,
        pack_cache_promotion_reads: u8,
    ) -> Result<Self, RepositoryError> {
        let root = root.as_ref().to_path_buf();
        let payload_root = root.join("blobs");
        std::fs::create_dir_all(&payload_root)?;
        let fs_coordination = Arc::new(FsCoordination::new(&root));
        fs_coordination.initialize().await?;
        // Traversal state that died with an earlier process is removed here,
        // while a spill still held by a live traversal in another process is
        // left alone.
        let spill_directory = root.join(crate::spill::SPILL_DIRECTORY);
        let sweep = spill_directory.clone();
        tokio::task::spawn_blocking(move || SpillArea::sweep_stale(&sweep))
            .await
            .map_err(|error| RepositoryError::Payload(error.into()))?;
        // Initialization and supported format migrations may write. Keep them
        // in the same cross-process domain as every other state mutation.
        // Already-migrated repositories open without a migration write, so
        // collection can still be the operation that recovers disk space.
        let initialization_lease = fs_coordination.exclusive().await?;
        let db = tokio::task::spawn_blocking({
            let path = root.join("casita.sqlite");
            move || crate::sqlite::TursoDb::open(path)
        })
        .await
        .map_err(|error| RepositoryError::Payload(error.into()))??;
        let state = crate::TursoMetadataStore::from_db(db.clone()).await?;
        let snapshot = state.snapshot().await?;
        let catalog = snapshot.payload_catalog().map(ToOwned::to_owned);
        if catalog.is_none() && snapshot.objects().next().await.is_some() {
            return Err(MetadataError::Corruption(
                "local repository state does not contain a payload catalog".to_owned(),
            )
            .into());
        }
        let revision = snapshot.revision();
        drop(snapshot);
        let catalog = catalog.unwrap_or(crate::ChunkedBlobStore::empty_state_catalog()?);
        // The SQLite revision is authoritative, including after an interrupted
        // publication. Never fall back to a standalone pointer or inventory.
        let payloads = crate::ChunkedBlobStore::local_packed_with_catalog(
            payload_root,
            pack_target_size,
            pack_cache_capacity,
            pack_cache_promotion_reads,
            Some(&catalog),
        )
        .await?;
        // Schema 6 fences old publication SQL before this migration begins.
        // The exclusive repository lease prevents GC from racing the upload.
        // Reopening after interruption retries from the still-authoritative
        // inline witness, or reads the already durable external root.
        // Keep the lease with the cancellation-safe task: the SQLite write may
        // outlive an aborted open, and GC must not delete its candidate root.
        let (payloads, state) =
            crate::metadata::run_lease_task("catalog migration", |send| async move {
                let _lease = initialization_lease;
                let result = async {
                    let external = payloads.externalize_state_catalog(&catalog).await?;
                    if external != catalog {
                        #[cfg(test)]
                        crate::blob::crash_tests::checkpoint("before-catalog-migration");
                        let mut mutation = MetadataMutation::new();
                        mutation.set_payload_catalog(external.clone());
                        state.commit(&revision, mutation).await?;
                        #[cfg(test)]
                        crate::blob::crash_tests::checkpoint("after-catalog-migration");
                        payloads.synchronize_state_catalog(Some(&external)).await?;
                    }
                    Ok::<_, RepositoryError>((payloads, state))
                }
                .await;
                let _ = send.send(result);
                Ok(())
            })
            .await??;
        let mut repository = Self::new(payloads, state);
        repository.fs_coordination = Some(fs_coordination);
        // Only the standard local profile keeps one: it is the profile that
        // imports from a filesystem whose stat data means anything.
        repository.ingest_cache = Some(Arc::new(crate::ingest_cache::TursoIngestCache::new(db)));
        repository.spill_directory = Some(spill_directory);
        // This profile deliberately colocates state and payloads below one
        // filesystem root, so deleting stale payloads can fund a state retry.
        // Generic compositions make no such placement promise.
        repository.emergency_collection = true;
        // Reuse the online catalog collector when opening finds abandoned
        // metadata. An existing owner or recovery claim leaves cleanup for a
        // later collection without preventing the repository from opening.
        match repository.try_reclaim_metadata().await {
            Ok(_) | Err(RepositoryError::Busy(_)) => {}
            Err(error) => return Err(error),
        }
        let collector = repository.clone();
        repository.mutation_start = Some(Arc::new(LocalMutationStart::new(collector, root)));
        tracing::info!(profile = "local", "repository opened");
        Ok(repository)
    }
}

#[cfg(feature = "s3")]
impl Repository<crate::ChunkedBlobStore, crate::metadata::Wal3MetadataStore> {
    /// Open a repository whose payloads and revisioned state are authoritative
    /// in one S3 bucket.
    ///
    /// Every runner uses the same `bucket` and repository `prefix`, but gives
    /// itself a distinct diagnostic `writer` name. AWS credentials and region
    /// are read from standard `AWS_*` environment variables by both physical
    /// storage clients. Durable online pins protect scoped data while physical
    /// collection proceeds across runners. Drop
    /// sessions and call [`crate::flush_repository_leases`] before runtime
    /// shutdown. All runners must support this admission protocol.
    pub async fn s3(
        bucket: impl AsRef<str>,
        prefix: impl AsRef<str>,
        writer: impl Into<String>,
    ) -> Result<Self, RepositoryError> {
        Self::s3_with_pack_target(bucket, prefix, writer, crate::DEFAULT_PACK_TARGET_SIZE).await
    }

    /// Open the S3/wal3 profile with an explicit compressed pack target.
    pub async fn s3_with_pack_target(
        bucket: impl AsRef<str>,
        prefix: impl AsRef<str>,
        writer: impl Into<String>,
        pack_target_size: u64,
    ) -> Result<Self, RepositoryError> {
        Self::s3_with_pack_options(
            bucket,
            prefix,
            writer,
            pack_target_size,
            crate::DEFAULT_PACK_CACHE_CAPACITY,
            crate::DEFAULT_PACK_CACHE_PROMOTION_READS,
        )
        .await
    }

    /// Open the S3/wal3 profile with explicit immutable-pack tuning.
    ///
    /// This is intended for measured deployment tuning. Set
    /// `pack_cache_capacity` to zero to disable payload caching;
    /// `pack_cache_promotion_reads` must remain at least one.
    #[tracing::instrument(
        name = "repository.open",
        skip_all,
        fields(
            profile = "s3",
            pack_target_bytes = pack_target_size,
            pack_cache_bytes = pack_cache_capacity,
            pack_cache_promotion_reads = pack_cache_promotion_reads
        )
    )]
    pub async fn s3_with_pack_options(
        bucket: impl AsRef<str>,
        prefix: impl AsRef<str>,
        writer: impl Into<String>,
        pack_target_size: u64,
        pack_cache_capacity: u64,
        pack_cache_promotion_reads: u8,
    ) -> Result<Self, RepositoryError> {
        Self::open_s3_for_collection_recovery(
            bucket,
            prefix,
            writer,
            pack_target_size,
            pack_cache_capacity,
            pack_cache_promotion_reads,
            None,
        )
        .await
        .map(|(repository, _)| repository)
    }

    /// Reopen and resume an abandoned S3 collection, including a prune fence
    /// that prevents ordinary repository admission.
    ///
    /// Establish that all requests covered by the abandoned collector's claims
    /// have stopped, then recover its operational WAL3 token separately. Supply
    /// the exact collector token from the state pin ledger. This method owns
    /// collector admission before opening payload discovery and retains that
    /// ownership through recovery; it never admits an unprotected data reader.
    pub async fn recover_s3_collection(
        bucket: impl AsRef<str>,
        prefix: impl AsRef<str>,
        writer: impl Into<String>,
        abandoned: &crate::metadata::PinToken,
    ) -> Result<CollectionOutcome, RepositoryError> {
        let (repository, remote) = Self::open_s3_for_collection_recovery(
            bucket,
            prefix,
            writer,
            crate::DEFAULT_PACK_TARGET_SIZE,
            crate::DEFAULT_PACK_CACHE_CAPACITY,
            crate::DEFAULT_PACK_CACHE_PROMOTION_READS,
            Some(abandoned),
        )
        .await?;
        let guard = repository.coordination.clone().lock_owned().await;
        let plan = repository
            .collection_plan_with_recovery(guard, None, false, Some(abandoned), remote)
            .await?;
        repository.execute_collection(plan, true).await
    }

    async fn open_s3_for_collection_recovery(
        bucket: impl AsRef<str>,
        prefix: impl AsRef<str>,
        writer: impl Into<String>,
        pack_target_size: u64,
        pack_cache_capacity: u64,
        pack_cache_promotion_reads: u8,
        recovery: Option<&crate::metadata::PinToken>,
    ) -> Result<(Self, Option<crate::metadata::RepositoryLease>), RepositoryError> {
        let bucket = bucket.as_ref().to_owned();
        let prefix = prefix.as_ref().trim_matches('/');
        let payload_prefix = if prefix.is_empty() {
            "payloads".to_owned()
        } else {
            format!("{prefix}/payloads")
        };
        let state_prefix = if prefix.is_empty() {
            "state".to_owned()
        } else {
            format!("{prefix}/state")
        };
        let objects = crate::object_store::aws::AmazonS3Builder::from_env()
            .with_bucket_name(&bucket)
            // Keep transport integrity explicit even when an installation
            // opts into unsigned SigV4 payloads. S3 validates this checksum
            // as part of the existing PUT/multipart request, so this costs no
            // additional object-store operation.
            .with_checksum_algorithm(crate::object_store::aws::Checksum::SHA256)
            .build()
            .map_err(crate::error::Error::from)?;
        // WAL3 is authoritative for the exact payload catalog. Recover it
        // first so a normal reopen can skip the advisory pointer entirely.
        let state =
            crate::metadata::Wal3MetadataStore::open_s3(bucket, state_prefix, writer).await?;
        let (snapshot, _bootstrap_pin, remote) = if let Some(expected) = recovery {
            let remote = state.try_collection_lease().await?.ok_or_else(|| {
                RepositoryError::Busy("another collector owns S3 repository admission".into())
            })?;
            if state
                .pin_store()
                .await?
                .inventory()
                .await?
                .collector
                .as_ref()
                != Some(expected)
            {
                return Err(RepositoryError::Busy(
                    "abandoned collector token no longer matches the pin ledger".into(),
                ));
            }
            // Collector ownership excludes metadata and payload reclamation.
            // Taking a normal snapshot pin here would block on the old fence
            // and retain the very records that recovery needs to prune.
            (state.snapshot().await?, None, Some(remote))
        } else {
            let (snapshot, pin) = pin_metadata_snapshot(&state, true, None).await?;
            (snapshot, Some(pin), None)
        };
        let catalog = snapshot.payload_catalog().ok_or_else(|| {
            MetadataError::Corruption(
                "WAL3 repository state does not contain a payload catalog".to_owned(),
            )
        })?;
        let payloads = crate::ChunkedBlobStore::new_packed_with_state_catalog(
            Arc::new(objects),
            crate::object_store::path::Path::from(payload_prefix),
            crate::blob::DEFAULT_AVG_CHUNK_SIZE,
            pack_target_size,
            pack_cache_capacity,
            pack_cache_promotion_reads,
            catalog,
        )
        .await?;
        drop(snapshot);
        tracing::info!(profile = "s3", "repository opened");
        Ok((Self::new(payloads, state), remote))
    }
}

impl<SS> Repository<crate::ChunkedBlobStore, SS>
where
    SS: MetadataStore,
{
    /// Set the chunk upload window per new blob writer (default 32).
    /// Existing repository clones retain their setting; the chunk memory budget
    /// and storage coordination remain shared. One runs chunk uploads serially.
    pub fn with_chunk_upload_concurrency(mut self, concurrency: std::num::NonZeroUsize) -> Self {
        Arc::make_mut(&mut self.payloads).chunk_upload_concurrency = concurrency;
        self
    }

    /// Verify every payload named by one retained snapshot and automatically
    /// repair only safe physical state.
    ///
    /// A supplied `replica` is held for the complete operation and is read
    /// independently before it can replace a missing or corrupt local
    /// representation. The replacement manifest is published only after the
    /// complete blob has been re-verified by the local store. Existing Bao
    /// outboards are rebuilt from local verified bytes when they differ.
    ///
    /// This method never changes logical records or roots. A coordinating state
    /// backend may receive the repaired physical catalog in a metadata-only
    /// commit. Its retention pin keeps the inspected snapshot’s data alive
    /// while collection, ordinary readers and publication proceed. Concurrent fsck
    /// repairs may repeat identical work, but every physical publication is
    /// content-addressed and verified, so they cannot produce a different
    /// visible representation.
    pub async fn fsck_repair(
        &self,
        replica: Option<&Self>,
    ) -> Result<FsckRepairReport, RepositoryError> {
        self.fsck_repair_inner(replica, false).await
    }

    /// Report the safe repairs [`fsck_repair`](Self::fsck_repair) would perform without
    /// changing physical or logical state.
    pub async fn preview_fsck_repair(
        &self,
        replica: Option<&Self>,
    ) -> Result<FsckRepairReport, RepositoryError> {
        self.fsck_repair_inner(replica, true).await
    }

    #[tracing::instrument(
        name = "repository.fsck_repair",
        skip_all,
        fields(dry_run = dry_run, replica = replica.is_some())
    )]
    async fn fsck_repair_inner(
        &self,
        replica: Option<&Self>,
        dry_run: bool,
    ) -> Result<FsckRepairReport, RepositoryError> {
        // Pins retain source and target data through verification, repair,
        // and publication while collection can reclaim unrelated data.
        let target_hold = self.retention_hold().await?;
        let _replica_hold = match replica {
            Some(replica) => Some(replica.retention_hold().await?),
            None => None,
        };
        let snapshot = target_hold.snapshot();
        let revision = snapshot.revision();
        let area = self.spill_area();
        let mut seen = SpillSet::new(area.clone(), "fsck-repair-payloads");
        let mut report = FsckRepairReport {
            revision,
            payloads_checked: 0,
            bytes_checked: 0,
            outboards_checked: 0,
            actions: Vec::new(),
            findings: Vec::new(),
            spill: SpillMetrics::default(),
        };

        // Bao outboards are optional and uncommon for small-object trees.
        // Inventory the exact namespace once instead of performing one
        // guaranteed-miss filesystem/S3 lookup per payload.
        let mut physical_outboards = SpillSet::new(area.clone(), "fsck-repair-outboards");
        let mut outboards = self.payloads.list_outboards();
        while let Some(outboard) = outboards.next().await {
            physical_outboards.insert(outboard?).await?;
        }
        drop(outboards);

        let mut records = snapshot.objects_unordered();
        loop {
            let mut batch = Vec::with_capacity(FSCK_SCAN_WINDOW);
            while batch.len() < FSCK_SCAN_WINDOW {
                let Some(record) = records.next().await else {
                    break;
                };
                let record = record?;
                let payload = record.payload();
                if !seen.insert(payload).await? {
                    continue;
                }
                let order = self.payloads.physical_scan_order(&payload).await?;
                batch.push((order, payload, record.payload_size()));
            }
            if batch.is_empty() {
                break;
            }
            // State is ordered by logical object key, which is unrelated to
            // pack construction order. A scan in that order can reload the
            // same immutable packs thousands of times when the cache is
            // smaller than the repository. Sorting one bounded window keeps
            // memory independent of repository size and makes repeated reads
            // of a pack adjacent.
            batch.sort_unstable_by_key(|(pack, payload, _)| (pack.is_none(), *pack, *payload));
            for (_, payload, payload_size) in batch {
                report.payloads_checked =
                    report.payloads_checked.checked_add(1).ok_or_else(|| {
                        RepositoryError::LimitExceeded(
                            "fsck repair payload count overflowed".to_owned(),
                        )
                    })?;
                let outboard_present = physical_outboards.contains(&payload).await?;
                self.fsck_repair_payload(
                    replica,
                    dry_run,
                    payload,
                    payload_size,
                    outboard_present,
                    &mut report,
                )
                .await?;
            }
        }
        drop(records);
        if !dry_run {
            self.commit_payload_catalog(target_hold.protection.clone())
                .await?;
        }
        report.spill = area.metrics();
        tracing::info!(
            revision = %report.revision,
            payloads_checked = report.payloads_checked,
            bytes_checked = report.bytes_checked,
            outboards_checked = report.outboards_checked,
            actions = report.actions.len(),
            findings = report.findings.len(),
            "physical repair scan completed"
        );
        Ok(report)
    }

    async fn fsck_repair_payload(
        &self,
        replica: Option<&Self>,
        dry_run: bool,
        payload: BlobId,
        payload_size: u64,
        outboard_present: bool,
        report: &mut FsckRepairReport,
    ) -> Result<(), RepositoryError> {
        let local = verify_stored_blob(&self.payloads, &payload, payload_size).await;
        match local {
            StoredBlobStatus::Healthy { bytes } => {
                report.bytes_checked =
                    report.bytes_checked.checked_add(bytes).ok_or_else(|| {
                        RepositoryError::LimitExceeded(
                            "fsck repair byte count overflowed".to_owned(),
                        )
                    })?;
                if outboard_present {
                    self.fsck_repair_outboard(&payload, payload_size, dry_run, report)
                        .await;
                }
            }
            failed @ (StoredBlobStatus::Missing | StoredBlobStatus::Corrupt(_)) => {
                let Some(replica) = replica else {
                    report.findings.push(fsck_repair_payload_finding(
                        &failed,
                        payload,
                        payload_size,
                    ));
                    return Ok(());
                };

                // A replica is a repair source only after an independent
                // full read proves the exact digest and size expected by
                // this authoritative target record.
                match verify_stored_blob(replica.payloads(), &payload, payload_size).await {
                    StoredBlobStatus::Healthy { .. } => {
                        if dry_run {
                            report.actions.push(FsckRepairAction {
                                kind: FsckRepairActionKind::RepairPayloadFromReplica,
                                payload,
                                bytes: payload_size,
                                status: FsckRepairActionStatus::Planned,
                            });
                            report.findings.push(fsck_repair_payload_finding(
                                &failed,
                                payload,
                                payload_size,
                            ));
                        } else if let Err(error) = self
                            .payloads
                            .repair_from_replica(replica.payloads(), &payload)
                            .await
                        {
                            report.findings.push(FsckRepairFinding {
                                kind: FsckRepairFindingKind::UnavailablePayload,
                                payload,
                                bytes: payload_size,
                                message: format!(
                                    "verified replica could not be published locally: {error}"
                                ),
                            });
                        } else {
                            report.bytes_checked = report
                                .bytes_checked
                                .checked_add(payload_size)
                                .ok_or_else(|| {
                                RepositoryError::LimitExceeded(
                                    "fsck repair byte count overflowed".to_owned(),
                                )
                            })?;
                            report.actions.push(FsckRepairAction {
                                kind: FsckRepairActionKind::RepairPayloadFromReplica,
                                payload,
                                bytes: payload_size,
                                status: FsckRepairActionStatus::Repaired,
                            });
                            if outboard_present {
                                self.fsck_repair_outboard(&payload, payload_size, false, report)
                                    .await;
                            }
                        }
                    }
                    status => report.findings.push(FsckRepairFinding {
                        kind: fsck_repair_payload_finding_kind(&failed),
                        payload,
                        bytes: payload_size,
                        message: format!(
                            "local representation is damaged and replica is not verified: {}",
                            stored_blob_status_message(&status)
                        ),
                    }),
                }
            }
            unavailable @ StoredBlobStatus::Unavailable(_) => report.findings.push(
                fsck_repair_payload_finding(&unavailable, payload, payload_size),
            ),
        }
        Ok(())
    }

    async fn fsck_repair_outboard(
        &self,
        payload: &BlobId,
        bytes: u64,
        dry_run: bool,
        report: &mut FsckRepairReport,
    ) {
        let stored = match self.payloads.get_outboard(payload).await {
            Ok(Some(outboard)) => Some(outboard),
            Ok(None) => return,
            // A paged outboard may fail before its logical bytes can be
            // assembled. Rebuild only after independently verifying payloads.
            Err(error) if is_integrity_error(&error) => None,
            Err(error) => {
                report.findings.push(FsckRepairFinding {
                    kind: FsckRepairFindingKind::UnavailableOutboard,
                    payload: *payload,
                    bytes,
                    message: error.to_string(),
                });
                return;
            }
        };
        report.outboards_checked += 1;
        let expected = match self.payloads.compute_outboard(payload).await {
            Ok(outboard) => outboard,
            Err(error) => {
                report.findings.push(FsckRepairFinding {
                    kind: if is_integrity_error(&error) {
                        FsckRepairFindingKind::CorruptPayload
                    } else {
                        FsckRepairFindingKind::UnavailableOutboard
                    },
                    payload: *payload,
                    bytes,
                    message: error.to_string(),
                });
                return;
            }
        };
        if stored.as_ref() == Some(&expected) {
            return;
        }
        if dry_run {
            report.actions.push(FsckRepairAction {
                kind: FsckRepairActionKind::RebuildOutboard,
                payload: *payload,
                bytes,
                status: FsckRepairActionStatus::Planned,
            });
            report.findings.push(FsckRepairFinding {
                kind: FsckRepairFindingKind::CorruptOutboard,
                payload: *payload,
                bytes,
                message: "stored Bao outboard does not match the verified payload".to_owned(),
            });
        } else if let Err(error) = self.payloads.put_outboard(payload, expected).await {
            report.findings.push(FsckRepairFinding {
                kind: FsckRepairFindingKind::UnavailableOutboard,
                payload: *payload,
                bytes,
                message: format!("could not publish rebuilt Bao outboard: {error}"),
            });
        } else {
            report.actions.push(FsckRepairAction {
                kind: FsckRepairActionKind::RebuildOutboard,
                payload: *payload,
                bytes,
                status: FsckRepairActionStatus::Repaired,
            });
        }
    }
}

enum StoredBlobStatus {
    Healthy { bytes: u64 },
    Missing,
    Corrupt(String),
    Unavailable(String),
}

async fn verify_stored_blob(
    store: &crate::ChunkedBlobStore,
    expected: &BlobId,
    expected_size: u64,
) -> StoredBlobStatus {
    let mut reader = match store.open_read_strict(expected).await {
        Ok(Some(reader)) => reader,
        Ok(None) => return StoredBlobStatus::Missing,
        Err(error) if is_integrity_error(&error) => {
            return StoredBlobStatus::Corrupt(error.to_string());
        }
        Err(error) => return StoredBlobStatus::Unavailable(error.to_string()),
    };
    let mut hasher = blake3::Hasher::new();
    let mut bytes = 0u64;
    let mut buffer = [0u8; 64 * 1024];
    loop {
        match AsyncReadExt::read(&mut reader, &mut buffer).await {
            Ok(0) => break,
            Ok(read) => {
                hasher.update(&buffer[..read]);
                bytes = match bytes.checked_add(read as u64) {
                    Some(bytes) => bytes,
                    None => return StoredBlobStatus::Corrupt("payload size overflowed".to_owned()),
                };
            }
            Err(error) if is_integrity_io_error(&error) => {
                return StoredBlobStatus::Corrupt(error.to_string());
            }
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                return StoredBlobStatus::Missing;
            }
            Err(error) => return StoredBlobStatus::Unavailable(error.to_string()),
        }
    }
    if bytes != expected_size {
        return StoredBlobStatus::Corrupt(format!(
            "payload has {bytes} bytes, record requires {expected_size}"
        ));
    }
    let actual = BlobId::new(hasher.finalize().into());
    if actual != *expected {
        return StoredBlobStatus::Corrupt(format!(
            "payload hashes to {actual}, record requires {expected}"
        ));
    }
    StoredBlobStatus::Healthy { bytes }
}

fn fsck_repair_payload_finding(
    status: &StoredBlobStatus,
    payload: BlobId,
    bytes: u64,
) -> FsckRepairFinding {
    FsckRepairFinding {
        kind: fsck_repair_payload_finding_kind(status),
        payload,
        bytes,
        message: stored_blob_status_message(status),
    }
}

fn fsck_repair_payload_finding_kind(status: &StoredBlobStatus) -> FsckRepairFindingKind {
    match status {
        StoredBlobStatus::Missing => FsckRepairFindingKind::MissingPayload,
        StoredBlobStatus::Corrupt(_) => FsckRepairFindingKind::CorruptPayload,
        StoredBlobStatus::Unavailable(_) => FsckRepairFindingKind::UnavailablePayload,
        StoredBlobStatus::Healthy { .. } => {
            unreachable!("healthy payload has no fsck_repair finding")
        }
    }
}

fn stored_blob_status_message(status: &StoredBlobStatus) -> String {
    match status {
        StoredBlobStatus::Healthy { .. } => "payload is healthy".to_owned(),
        StoredBlobStatus::Missing => "payload is absent".to_owned(),
        StoredBlobStatus::Corrupt(message) | StoredBlobStatus::Unavailable(message) => {
            message.clone()
        }
    }
}

impl<PS, SS> Repository<PS, SS>
where
    PS: BlobStore,
    SS: MetadataStore,
{
    #[tracing::instrument(name = "repository.snapshot", level = "debug", skip_all)]
    pub(crate) async fn synchronized_snapshot(
        &self,
    ) -> Result<Arc<dyn MetadataSnapshot>, RepositoryError> {
        let snapshot = self.state.snapshot().await?;
        self.publication
            .synchronize(&self.payloads, snapshot.as_ref())
            .await?;
        tracing::debug!(revision = %snapshot.revision(), "repository snapshot synchronized");
        Ok(snapshot)
    }

    async fn retained_snapshot(&self) -> Result<Arc<dyn MetadataSnapshot>, RepositoryError> {
        let snapshot = self.synchronized_snapshot().await?;
        // A process can open its catalog before acquiring collector
        // ownership. Refresh its inventory after reading the logical
        // snapshot. Mutation sessions already refresh once on admission;
        // their metadata batches must not repeatedly decode the whole catalog.
        if self.fs_coordination.is_some() {
            self.publication.refresh_retained(&self.payloads).await?;
        }
        Ok(snapshot)
    }

    async fn pinned_retained_snapshot(
        &self,
        wait: bool,
        roots: Option<&BTreeSet<ObjectKey>>,
    ) -> Result<(HeldSnapshot, Arc<DataProtection>), RepositoryError> {
        self.pinned_retained_snapshot_kind(wait, roots, false).await
    }

    async fn pinned_retained_snapshot_kind(
        &self,
        wait: bool,
        roots: Option<&BTreeSet<ObjectKey>>,
        reader: bool,
    ) -> Result<(HeldSnapshot, Arc<DataProtection>), RepositoryError> {
        let (snapshot, pin) = if reader {
            pin_metadata_snapshot_kind(self.state.as_ref(), wait, true, roots).await?
        } else {
            pin_metadata_snapshot(self.state.as_ref(), wait, roots).await?
        };
        self.publication
            .synchronize(&self.payloads, snapshot.as_ref())
            .await?;
        if self.fs_coordination.is_some() {
            self.publication.refresh_retained(&self.payloads).await?;
        }
        let payload_batch = self
            .payloads
            .begin_pinned_batch(pin.clone())?
            .without_batching();
        let protection = Arc::new(DataProtection {
            _payload_batch: payload_batch,
            _pin: Some(pin),
        });
        Ok((HeldSnapshot(snapshot), protection))
    }

    async fn commit_payload_catalog(
        &self,
        protection: publication::Protection,
    ) -> Result<Option<CommitResult>, RepositoryError> {
        self.commit_payload_catalog_from(None, protection).await
    }

    #[tracing::instrument(name = "repository.commit_payload_catalog", skip_all)]
    async fn commit_payload_catalog_from(
        &self,
        mut expected: Option<crate::RepositoryRevision>,
        protection: publication::Protection,
    ) -> Result<Option<CommitResult>, RepositoryError> {
        let _phase = CollectionPhase::new("catalog_commit");
        let mut state_commit = self.publication.lock().await;
        if state_commit.is_none() {
            return Ok(None);
        }
        loop {
            let _attempt = CollectionPhase::new("catalog_commit_attempt");
            let revision = match expected.take() {
                Some(revision) => revision,
                None => self.synchronized_snapshot().await?.revision(),
            };
            let (guard, committed) = self
                .publication
                .commit(
                    state_commit.take(),
                    protection.clone(),
                    revision,
                    None,
                    #[cfg(test)]
                    self.publication_profile.clone(),
                )
                .await;
            state_commit = guard;
            match committed {
                Ok(commit) => return Ok(commit),
                Err(RepositoryError::Metadata(MetadataError::StaleRevision { .. })) => {
                    tracing::debug!("payload catalog commit raced a newer revision; retrying");
                }
                Err(error) => return Err(error),
            }
        }
    }

    /// Begin a mutation lifetime protected from collection.
    ///
    /// The standard local profile first probes disk pressure and attempts one
    /// nonblocking collection when usage reaches the configured threshold. A
    /// busy repository skips that opportunistic pass and admits the mutation;
    /// a later mutation retries it. Generic repository compositions install no
    /// automatic start policy.
    #[tracing::instrument(name = "repository.mutation_session", skip_all)]
    pub async fn mutation_session(&self) -> Result<MutationSession<'_, PS, SS>, RepositoryError> {
        let discovery_refreshed = match &self.mutation_start {
            Some(start) => start.before_mutation(self.spill_limits).await?,
            None => false,
        };
        let pin = crate::metadata::DataPinLease::acquire(
            self.state.pin_store().await?,
            crate::metadata::DataPin {
                scope: crate::metadata::PinScope::Staging,
                catalog: None,
                resources: BTreeSet::new(),
            },
        )
        .await?;
        let payload_batch = self.payloads.begin_pinned_batch(pin.clone())?;
        // One discovery refresh is sufficient for the complete mutation. A
        // racing writer may cause a redundant immutable upload, but cannot
        // change identity; refreshing every negative probe would amplify one
        // logical transfer into thousands of object-store requests.
        self.publication
            .admit_mutation(&self.payloads, &self.state, discovery_refreshed, &pin)
            .await?;
        Ok(MutationSession {
            repository: self,
            pin,
            protection: Arc::new(DataProtection {
                _payload_batch: payload_batch,
                _pin: None,
            }),
        })
    }

    /// Open one object's payload, retaining its dependency closure until the
    /// reader is dropped. Unrelated objects in the admitted snapshot are not
    /// retained. The reader owns its protection and may outlive this repository.
    pub async fn open_payload(
        &self,
        key: &ObjectKey,
    ) -> Result<Option<(ObjectRecord, Box<dyn BlobReader>)>, RepositoryError> {
        let (snapshot, protection) = self
            .pinned_retained_snapshot(true, Some(&BTreeSet::from([key.clone()])))
            .await?;
        snapshot.open_payload(&self.payloads, key, protection).await
    }

    /// Take a stable-read retention hold. Its snapshot remains logically
    /// immutable and its pin retains the snapshot’s data during collection.
    #[tracing::instrument(name = "repository.retention_hold", skip_all)]
    pub async fn retention_hold(&self) -> Result<RetentionHold<'_, PS, SS>, RepositoryError> {
        let (snapshot, protection) = self.pinned_retained_snapshot(true, None).await?;
        Ok(RetentionHold {
            repository: self,
            snapshot,
            protection,
        })
    }

    /// Protect selected immutable graphs and their snapshot catalog.
    pub(crate) async fn retention_hold_for(
        &self,
        roots: &BTreeSet<ObjectKey>,
    ) -> Result<RetentionHold<'_, PS, SS>, RepositoryError> {
        let (snapshot, protection) = self
            .pinned_retained_snapshot_kind(true, Some(roots), true)
            .await?;
        Ok(RetentionHold {
            repository: self,
            snapshot,
            protection,
        })
    }

    /// Take a stable-read hold that owns a clone of the repository facade.
    ///
    /// Long-running services use this form to bind one exact logical snapshot
    /// without a self-referential borrow. The facade shares its backend handles;
    /// the backend implementations do not need to implement `Clone`.
    pub async fn owned_retention_hold(
        &self,
    ) -> Result<OwnedRetentionHold<PS, SS>, RepositoryError> {
        self.owned_retention_hold_kind(false).await
    }

    pub(crate) async fn owned_read_hold(
        &self,
    ) -> Result<OwnedRetentionHold<PS, SS>, RepositoryError> {
        self.owned_retention_hold_kind(true).await
    }

    async fn owned_retention_hold_kind(
        &self,
        reader: bool,
    ) -> Result<OwnedRetentionHold<PS, SS>, RepositoryError> {
        let repository = self.clone();
        let (snapshot, protection) = repository
            .pinned_retained_snapshot_kind(true, None, reader)
            .await?;
        Ok(OwnedRetentionHold {
            repository,
            snapshot,
            _protection: protection,
        })
    }

    /// Open one immutable object without retaining unrelated logical objects
    /// or a historical payload catalog for the reader's lifetime. Objects with
    /// links retain their closure so collection preserves graph consistency.
    /// The requested closure and candidate catalog remain protected while
    /// resolving the physical read plan and handing it off to the read pin.
    #[tracing::instrument(name = "repository.open_object", level = "debug", skip_all)]
    pub(crate) async fn open_object(
        &self,
        key: &ObjectKey,
    ) -> Result<Option<OpenedObject>, RepositoryError>
    where
        PS: 'static,
        SS: 'static,
    {
        self.open_object_inner(
            key,
            #[cfg(test)]
            &mut ObjectReadProfile::default(),
        )
        .await
    }

    pub(crate) async fn open_object_inner(
        &self,
        key: &ObjectKey,
        #[cfg(test)] profile: &mut ObjectReadProfile,
    ) -> Result<Option<OpenedObject>, RepositoryError>
    where
        PS: 'static,
        SS: 'static,
    {
        Ok(self
            .open_object_with(
                key,
                |store, record, pin, catalog| {
                    Box::pin(async move {
                        store
                            .open_read_scoped(&record.payload(), pin, catalog)
                            .await
                    })
                },
                #[cfg(test)]
                profile,
            )
            .await?
            .map(|(record, reader)| (record, Box::new(reader) as Box<dyn BlobReader>)))
    }

    pub(crate) async fn open_object_verified(
        &self,
        key: &ObjectKey,
    ) -> Result<Option<(ObjectRecord, Box<dyn crate::blob::BlobStreamReader>)>, RepositoryError>
    where
        PS: 'static,
        SS: 'static,
    {
        Ok(self
            .open_object_with(
                key,
                |store, record, pin, catalog| {
                    Box::pin(async move {
                        store
                            .open_proof_scoped(
                                &record.payload(),
                                record.payload_size(),
                                pin,
                                catalog,
                            )
                            .await
                    })
                },
                #[cfg(test)]
                &mut ObjectReadProfile::default(),
            )
            .await?
            .map(|(record, reader)| {
                let protection = reader._protection.clone();
                let verified = crate::verified::stream::decode(
                    reader,
                    record.payload(),
                    record.payload_size(),
                );
                (
                    record,
                    Box::new(HeldReader {
                        reader: verified,
                        _protection: protection,
                    }) as Box<dyn crate::blob::BlobStreamReader>,
                )
            }))
    }

    async fn open_object_with<R, F>(
        &self,
        key: &ObjectKey,
        open: F,
        #[cfg(test)] profile: &mut ObjectReadProfile,
    ) -> Result<Option<(ObjectRecord, HeldReader<R>)>, RepositoryError>
    where
        PS: 'static,
        SS: 'static,
        R: AsyncRead + Unpin + Send + 'static,
        F: for<'a> FnOnce(
            &'a PS,
            &'a ObjectRecord,
            crate::metadata::DataPinLease,
            Option<&'a [u8]>,
        )
            -> futures::future::BoxFuture<'a, Result<Option<R>, crate::error::Error>>,
    {
        #[cfg(test)]
        let started = std::time::Instant::now();
        // Scoped backends resolve the supplied catalog themselves. Avoid
        // synchronizing a shared backend or attaching this temporary pin to
        // unrelated writes merely to admit a read.
        #[cfg(not(test))]
        let process_readers = true;
        #[cfg(test)]
        let process_readers = !profile.durable_readers;
        let (snapshot, snapshot_pin) = pin_metadata_snapshot_kind(
            self.state.as_ref(),
            true,
            process_readers,
            Some(&BTreeSet::from([key.clone()])),
        )
        .await?;
        #[cfg(test)]
        if let Some((entered, resume)) = profile.pause_after_pin.take() {
            let _ = entered.send(());
            let _ = resume.await;
        }
        let Some(record) = snapshot.object(key).await? else {
            return Ok(None);
        };
        let candidate_pin = crate::metadata::DataPin {
            scope: crate::metadata::PinScope::Closures(BTreeSet::from([key.clone()])),
            catalog: None,
            resources: BTreeSet::from([crate::metadata::PinResource::Blob(record.payload())]),
        };
        let pin = if process_readers {
            crate::metadata::DataPinLease::acquire_reader(
                self.state.pin_store().await?,
                candidate_pin,
            )
            .await?
        } else {
            crate::metadata::DataPinLease::acquire(self.state.pin_store().await?, candidate_pin)
                .await?
        };
        #[cfg(test)]
        {
            profile.admission_nanos = started.elapsed().as_nanos() as u64;
        }
        #[cfg(test)]
        let resolving = std::time::Instant::now();
        let reader = open(
            &self.payloads,
            &record,
            pin.clone(),
            snapshot.payload_catalog(),
        )
        .await?
        .ok_or(RepositoryError::MissingPayload(record.payload()))?;
        #[cfg(test)]
        {
            profile.resolve_nanos = resolving.elapsed().as_nanos() as u64;
        }
        // Neither a lazy metadata snapshot nor its catalog escapes into this
        // reader. The candidate-catalog pin can be released only after the
        // read pin and all physical dependencies have been admitted.
        drop(snapshot);
        drop(snapshot_pin);
        Ok(Some((
            record,
            HeldReader {
                reader,
                _protection: Arc::new((self.clone(), pin)),
            },
        )))
    }

    /// Verify a committed graph against one immutable state snapshot.
    #[tracing::instrument(name = "repository.verify_closure", skip_all)]
    pub async fn verify_closure(&self, root: &ObjectKey) -> Result<ClosureStatus, RepositoryError> {
        self.retention_hold_for(&BTreeSet::from([root.clone()]))
            .await?
            .verify_closure(root)
            .await
    }

    /// Check a committed graph is complete, trusting closures already verified.
    ///
    /// This is a fast precondition check rather than a fresh audit: closures
    /// already verified for the snapshot may be trusted.
    pub async fn verify_closure_incremental(
        &self,
        root: &ObjectKey,
    ) -> Result<ClosureStatus, RepositoryError> {
        self.retention_hold_for(&BTreeSet::from([root.clone()]))
            .await?
            .verify_closure_incremental(root)
            .await
    }

    /// Remove a name only if it still points at the caller's recorded key.
    pub async fn remove_root_if_matches(
        &self,
        name: &RootName,
        expected: &ObjectKey,
    ) -> Result<Option<CommitResult>, RepositoryError> {
        self.mutation_session()
            .await?
            .remove_root_if_matches(name, expected)
            .await
    }

    /// Materialize a verified canonical-directory graph while a retention hold
    /// prevents its payloads from being collected.
    #[tracing::instrument(name = "repository.checkout", skip_all)]
    pub async fn checkout(
        &self,
        root: &ObjectKey,
        target: impl AsRef<Path>,
    ) -> Result<(), RepositoryError> {
        if root.namespace().as_str() != crate::DIRECTORY_NAMESPACE {
            return Err(RepositoryError::InvalidInput(format!(
                "checkout requires `{}`, got `{}`",
                crate::DIRECTORY_NAMESPACE,
                root.namespace()
            )));
        }
        let digest = root.native_digest().ok_or_else(|| {
            RepositoryError::InvalidInput(format!("directory key {root} is not digest-width"))
        })?;
        let hold = self
            .retention_hold_for(&BTreeSet::from([root.clone()]))
            .await?;
        // Materializing asks whether the graph is complete, not whether the
        // bytes on disk have decayed since they were verified; `fsck` answers
        // the second question, and the checkout below reads and verifies every
        // payload it writes out anyway.
        let status = hold.verify_closure_incremental(root).await?;
        if !matches!(status, ClosureStatus::Complete { .. }) {
            return Err(RepositoryError::RootNotPublishable {
                root: root.clone(),
                status,
            });
        }
        let directories = RepositoryDirectoryView {
            payloads: &self.payloads,
            snapshot: hold.snapshot(),
        };
        crate::export::checkout(
            &self.payloads,
            &directories,
            &DirectoryId::new(digest),
            target,
        )
        .await?;
        Ok(())
    }
}

#[async_trait]
trait MutationStart: Send + Sync {
    /// Run local maintenance and report whether it refreshed payload discovery.
    async fn before_mutation(&self, spill_limits: SpillLimits) -> Result<bool, RepositoryError>;

    fn collection_completed(&self) {}
}

/// The standard local profile's once-per-handle, pressure-driven collector.
///
/// The cloned repository intentionally has no `mutation_start` hook of its
/// own, so entering collection here cannot recurse back into this policy.
struct LocalMutationStart<PS, SS> {
    repository: Repository<PS, SS>,
    root: PathBuf,
    completed: std::sync::atomic::AtomicBool,
    attempt: tokio::sync::Mutex<()>,
}

const PRESSURE_COLLECTION_STAMP: &str = ".casita-pressure-collection";
const PRESSURE_COLLECTION_COOLDOWN: Duration = Duration::from_secs(60 * 60);

impl<PS, SS> LocalMutationStart<PS, SS> {
    fn new(repository: Repository<PS, SS>, root: PathBuf) -> Self {
        Self {
            repository,
            root,
            completed: std::sync::atomic::AtomicBool::new(false),
            attempt: tokio::sync::Mutex::new(()),
        }
    }

    fn collection_is_recent(&self) -> bool {
        let Ok(modified) = std::fs::metadata(self.root.join(PRESSURE_COLLECTION_STAMP))
            .and_then(|metadata| metadata.modified())
        else {
            return false;
        };
        modified
            .elapsed()
            .map_or(true, |elapsed| elapsed < PRESSURE_COLLECTION_COOLDOWN)
    }

    fn record_collection(&self) {
        // This is an advisory latency guard, not repository state. A failed
        // timestamp write merely allows a later process to try collection
        // again; it cannot make committed content unreachable.
        let _ = std::fs::write(
            self.root.join(PRESSURE_COLLECTION_STAMP),
            b"pressure-triggered collection completed\n",
        );
    }
}

#[async_trait]
impl<PS, SS> MutationStart for LocalMutationStart<PS, SS>
where
    PS: BlobGc + Clone + 'static,
    SS: MetadataStore + Clone + 'static,
{
    async fn before_mutation(&self, spill_limits: SpillLimits) -> Result<bool, RepositoryError> {
        use std::sync::atomic::Ordering;

        // Rebase writes a persistent marker. Reclaim it at the next safe
        // mutation boundary, but never make a writer wait for a live reader or
        // another process.
        let mut discovery_refreshed = match self.repository.try_reclaim_metadata().await {
            Ok(refreshed) => refreshed,
            Err(RepositoryError::Busy(_)) => false,
            Err(error) => return Err(error),
        };

        if self.completed.load(Ordering::Acquire) || self.collection_is_recent() {
            self.completed.store(true, Ordering::Release);
            return Ok(discovery_refreshed);
        }

        let _attempt = self.attempt.lock().await;
        if self.completed.load(Ordering::Acquire) || self.collection_is_recent() {
            self.completed.store(true, Ordering::Release);
            return Ok(discovery_refreshed);
        }

        let repository = self.repository.clone().with_spill_limits(spill_limits);
        match crate::DiskPressurePolicy::default()
            .probe_and_collect(&repository, &self.root)
            .await
        {
            Ok(crate::DiskPressureOutcome::BelowThreshold { .. }) => {}
            Ok(crate::DiskPressureOutcome::Collected { .. }) => {
                self.record_collection();
                self.completed.store(true, Ordering::Release);
                discovery_refreshed = true;
            }
            Err(RepositoryError::Busy(_)) => {}
            Err(error) => return Err(error),
        }
        Ok(discovery_refreshed)
    }

    fn collection_completed(&self) {
        use std::sync::atomic::Ordering;

        self.record_collection();
        self.completed.store(true, Ordering::Release);
    }
}

/// Pin and validate a logical snapshot before opening any of its external
/// metadata or payload catalog files, including during S3 bootstrap.
async fn pin_metadata_snapshot(
    state: &impl MetadataStore,
    wait: bool,
    roots: Option<&BTreeSet<ObjectKey>>,
) -> Result<(Arc<dyn MetadataSnapshot>, crate::metadata::DataPinLease), RepositoryError> {
    pin_metadata_snapshot_kind(state, wait, false, roots).await
}

async fn pin_metadata_snapshot_kind(
    state: &impl MetadataStore,
    wait: bool,
    reader: bool,
    roots: Option<&BTreeSet<ObjectKey>>,
) -> Result<(Arc<dyn MetadataSnapshot>, crate::metadata::DataPinLease), RepositoryError> {
    let pins = state.pin_store().await?;
    loop {
        let candidate = state.snapshot().await?;
        let revision = candidate.revision();
        let generation = candidate.generation()?;
        let catalog = candidate.payload_catalog().map(ToOwned::to_owned);
        let resources = candidate.retention_resources();
        drop(candidate);
        let candidate_pin = crate::metadata::DataPin {
            scope: match roots {
                Some(keys) => crate::metadata::PinScope::Closures(keys.clone()),
                None => crate::metadata::PinScope::Snapshot { generation },
            },
            catalog,
            resources: resources.clone(),
        };
        let pin = if reader {
            crate::metadata::DataPinLease::try_acquire_reader(pins.clone(), candidate_pin).await?
        } else {
            crate::metadata::DataPinLease::try_acquire(pins.clone(), candidate_pin).await?
        };
        let Some(pin) = pin else {
            if !wait {
                return Err(RepositoryError::Busy(
                    "snapshot admission conflicts with collection; retry or recover the interrupted collector".into(),
                ));
            }
            // GC may have retired this candidate while admission was pending.
            // Reload its head rather than waiting on an obsolete claimed path.
            tokio::time::sleep(std::time::Duration::from_millis(25)).await;
            continue;
        };
        // Registration and the metadata commit use separate stores. Only
        // expose a candidate whose revision survived registration.
        let snapshot = state.snapshot().await?;
        if snapshot.revision() != revision || snapshot.retention_resources() != resources {
            continue;
        }
        return Ok((snapshot, pin));
    }
}

/// Read operations shared by both hold ownership forms. The surrounding hold
/// owns collection protection; this wrapper does not acquire or release leases.
struct HeldSnapshot(Arc<dyn MetadataSnapshot>);

impl HeldSnapshot {
    fn as_ref(&self) -> &dyn MetadataSnapshot {
        self.0.as_ref()
    }

    async fn object(&self, key: &ObjectKey) -> Result<Option<ObjectRecord>, RepositoryError> {
        Ok(self.0.object(key).await?)
    }

    async fn open_payload<PS: BlobStore>(
        &self,
        payloads: &PS,
        key: &ObjectKey,
        protection: Arc<DataProtection>,
    ) -> Result<Option<(ObjectRecord, Box<dyn BlobReader>)>, RepositoryError> {
        let Some(record) = self.object(key).await? else {
            return Ok(None);
        };
        let reader = payloads
            .open_read(&record.payload())
            .await?
            .ok_or(RepositoryError::MissingPayload(record.payload()))?;
        Ok(Some((
            record,
            Box::new(HeldReader {
                reader,
                _protection: protection,
            }),
        )))
    }

    async fn verify_closure<PS: BlobStore>(
        &self,
        verifier: ClosureVerifier<'_, PS>,
        root: &ObjectKey,
        audit: ClosureAudit,
    ) -> Result<ClosureStatus, RepositoryError> {
        verify_closure_with(
            verifier,
            self.as_ref(),
            &BTreeMap::new(),
            root,
            None,
            audit,
            None,
        )
        .await
    }
}

// A stream can outlive the facade hold that opened it. Carry its protection
// until the stream itself is dropped, including while a read or seek is pending.
struct HeldReader<R> {
    reader: R,
    _protection: Arc<dyn Send + Sync>,
}

impl<R: AsyncRead + Unpin> AsyncRead for HeldReader<R> {
    fn poll_read(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
        buf: &mut tokio::io::ReadBuf<'_>,
    ) -> std::task::Poll<std::io::Result<()>> {
        std::pin::Pin::new(&mut self.reader).poll_read(cx, buf)
    }
}

impl<R: tokio::io::AsyncSeek + Unpin> tokio::io::AsyncSeek for HeldReader<R> {
    fn start_seek(
        mut self: std::pin::Pin<&mut Self>,
        position: std::io::SeekFrom,
    ) -> std::io::Result<()> {
        std::pin::Pin::new(&mut self.reader).start_seek(position)
    }

    fn poll_complete(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<std::io::Result<u64>> {
        std::pin::Pin::new(&mut self.reader).poll_complete(cx)
    }
}

impl BlobReader for HeldReader<Box<dyn BlobReader>> {}

/// Stable logical snapshot protected from physical collection.
pub struct RetentionHold<'a, PS, SS> {
    repository: &'a Repository<PS, SS>,
    snapshot: HeldSnapshot,
    protection: Arc<DataProtection>,
}

/// Owned stable logical snapshot protected from physical collection.
pub struct OwnedRetentionHold<PS, SS> {
    repository: Repository<PS, SS>,
    snapshot: HeldSnapshot,
    _protection: Arc<DataProtection>,
}

impl<PS, SS> OwnedRetentionHold<PS, SS>
where
    PS: BlobStore,
    SS: MetadataStore,
{
    /// Repository whose coordination and physical payloads this hold owns.
    pub fn repository(&self) -> &Repository<PS, SS> {
        &self.repository
    }

    /// Immutable logical snapshot tied to this hold.
    pub fn snapshot(&self) -> &dyn MetadataSnapshot {
        self.snapshot.as_ref()
    }

    /// Look up one immutable record in this exact snapshot.
    pub async fn object(&self, key: &ObjectKey) -> Result<Option<ObjectRecord>, RepositoryError> {
        self.snapshot.object(key).await
    }

    /// Open one snapshot record's physical payload while collection is excluded.
    pub async fn open_payload(
        &self,
        key: &ObjectKey,
    ) -> Result<Option<(ObjectRecord, Box<dyn BlobReader>)>, RepositoryError> {
        self.snapshot
            .open_payload(&self.repository.payloads, key, self._protection.clone())
            .await
    }

    /// Verify a closure against the owned exact snapshot.
    pub async fn verify_closure(&self, root: &ObjectKey) -> Result<ClosureStatus, RepositoryError> {
        self.snapshot
            .verify_closure(
                self.repository.closure_verifier(),
                root,
                ClosureAudit::Exhaustive,
            )
            .await
    }

    /// Check a closure is complete, trusting closures already verified.
    ///
    /// This is a fast precondition check rather than a fresh audit: closures
    /// already verified for the snapshot may be trusted.
    pub async fn verify_closure_incremental(
        &self,
        root: &ObjectKey,
    ) -> Result<ClosureStatus, RepositoryError> {
        self.snapshot
            .verify_closure(
                self.repository.closure_verifier(),
                root,
                ClosureAudit::Incremental,
            )
            .await
    }
}

impl<PS, SS> RetentionHold<'_, PS, SS>
where
    PS: BlobStore,
    SS: MetadataStore,
{
    pub(crate) async fn retain_only(
        &mut self,
        roots: BTreeSet<ObjectKey>,
    ) -> Result<(), RepositoryError> {
        // Keep the old protection until the new claim covers this exact view.
        let pin = crate::metadata::DataPinLease::acquire_reader(
            self.repository.state.pin_store().await?,
            crate::metadata::DataPin {
                scope: crate::metadata::PinScope::Closures(roots),
                catalog: self
                    .snapshot
                    .as_ref()
                    .payload_catalog()
                    .map(ToOwned::to_owned),
                resources: self.snapshot.as_ref().retention_resources(),
            },
        )
        .await?;
        let batch = self
            .repository
            .payloads
            .begin_pinned_batch(pin.clone())?
            .without_batching();
        self.protection = Arc::new(DataProtection {
            _payload_batch: batch,
            _pin: Some(pin),
        });
        Ok(())
    }

    /// Immutable logical snapshot tied to this hold.
    pub fn snapshot(&self) -> &dyn MetadataSnapshot {
        self.snapshot.as_ref()
    }

    /// Look up one immutable record in this exact snapshot.
    pub async fn object(&self, key: &ObjectKey) -> Result<Option<ObjectRecord>, RepositoryError> {
        self.snapshot.object(key).await
    }

    /// Open one snapshot record's physical payload while this hold prevents
    /// collection. The caller may run [`verify_closure`](Self::verify_closure)
    /// first when it needs namespace and direct-link verification as well as
    /// the payload store's content verification.
    pub async fn open_payload(
        &self,
        key: &ObjectKey,
    ) -> Result<Option<(ObjectRecord, Box<dyn BlobReader>)>, RepositoryError> {
        self.snapshot
            .open_payload(&self.repository.payloads, key, self.protection.clone())
            .await
    }

    /// Verify a closure while its physical payloads cannot be collected.
    pub async fn verify_closure(&self, root: &ObjectKey) -> Result<ClosureStatus, RepositoryError> {
        self.snapshot
            .verify_closure(
                self.repository.closure_verifier(),
                root,
                ClosureAudit::Exhaustive,
            )
            .await
    }

    /// Check a closure is complete, trusting closures already verified.
    ///
    /// This is a fast precondition check rather than a fresh audit: closures
    /// already verified for the snapshot may be trusted.
    pub(crate) async fn verify_closure_incremental(
        &self,
        root: &ObjectKey,
    ) -> Result<ClosureStatus, RepositoryError> {
        self.snapshot
            .verify_closure(
                self.repository.closure_verifier(),
                root,
                ClosureAudit::Incremental,
            )
            .await
    }

    /// Verify a closure and add every verified object to `union`.
    ///
    /// Planning a transfer or an archive needs the union of several closures,
    /// which is the same traversal a verification already performs. Collecting
    /// into a caller-owned spillable set avoids walking twice and keeps the
    /// union out of memory once it grows.
    pub(crate) async fn verify_closure_into(
        &self,
        root: &ObjectKey,
        union: &mut SpillSet<ObjectKey>,
    ) -> Result<ClosureStatus, RepositoryError> {
        verify_closure_against(
            self.repository.closure_verifier(),
            self.snapshot.as_ref(),
            &BTreeMap::new(),
            root,
            Some(union),
        )
        .await
    }

    /// Where this hold's repository spills traversal state.
    pub(crate) fn spill_area(&self) -> SpillArea {
        self.repository.spill_area()
    }
}

impl<PS, SS> Repository<PS, SS>
where
    SS: MetadataStore,
{
    /// Preview logical collection without inspecting or reclaiming physical
    /// payload storage.
    ///
    /// This is for a repository whose payload backend is shared with other
    /// repositories. It reports only unreachable records; a shared backend
    /// must establish global payload liveness independently.
    #[tracing::instrument(
        name = "repository.collection.preview",
        skip_all,
        fields(mode = "logical")
    )]
    pub async fn preview_logical_collection(
        &self,
    ) -> Result<LogicalCollectionPreview, RepositoryError> {
        let guard = self.coordination.clone().lock_owned().await;
        let fs_guard = self.exclusive_fs().await?;
        let plan = self.logical_collection_plan(guard, fs_guard, true).await?;
        plan.protection.collector.finish().await?;
        Ok(plan.preview.clone())
    }

    /// Atomically prune unreachable records without reclaiming physical
    /// payloads or chunks.
    ///
    /// Unlike [`collect`](Self::collect), this method requires no
    /// [`BlobGc`] implementation. A remote payload service can
    /// use its own aggregate ownership ledger to reclaim bytes after every
    /// repository that references them has pruned its records.
    #[tracing::instrument(
        name = "repository.collection",
        skip_all,
        fields(mode = "logical", blocking = true)
    )]
    pub async fn collect_logical(&self) -> Result<LogicalCollectionOutcome, RepositoryError> {
        let guard = self.coordination.clone().lock_owned().await;
        let fs_guard = self.exclusive_fs().await?;
        let plan = self.logical_collection_plan(guard, fs_guard, true).await?;
        self.execute_logical_collection(plan).await
    }

    /// Logically collect only if exclusive ownership is immediately available.
    ///
    /// Like [`try_collect`](Self::try_collect), this never waits for a
    /// mutation, stable read, transfer, or another collection operation.
    #[tracing::instrument(
        name = "repository.collection",
        skip_all,
        fields(mode = "logical", blocking = false)
    )]
    pub async fn try_collect_logical(&self) -> Result<LogicalCollectionOutcome, RepositoryError> {
        let guard = self.coordination.clone().try_lock_owned().map_err(|_| {
            RepositoryError::Busy(
                "another collection or maintenance operation is active".to_owned(),
            )
        })?;
        let fs_guard = match &self.fs_coordination {
            Some(coordination) => Some(coordination.try_exclusive().await?.ok_or_else(|| {
                RepositoryError::Busy(
                    "another process holds collection or maintenance ownership".to_owned(),
                )
            })?),
            None => None,
        };
        let plan = self.logical_collection_plan(guard, fs_guard, false).await?;
        self.execute_logical_collection(plan).await
    }

    async fn execute_logical_collection(
        &self,
        mut plan: LogicalCollectionPlan,
    ) -> Result<LogicalCollectionOutcome, RepositoryError> {
        // Marking is complete. Retain the frozen sets and revision, not the
        // read transaction, across pruning and checkpointing.
        drop(plan.snapshot.take());
        if !plan.pins.deletions.is_empty() {
            return Err(RepositoryError::Busy(
                "physical collection must finish deletion recovery".into(),
            ));
        }
        if plan.preview.logical_objects == 0 && plan.pins.logical_prune.is_none() {
            plan.protection.collector.finish().await?;
            return Ok(LogicalCollectionOutcome {
                revision: None,
                removed: plan.preview,
                spill: plan.area.metrics(),
            });
        }

        let retained = MetadataMutation::install_retained_source(plan.live_objects);
        let commit = self
            .publication
            .prune(
                plan.protection.clone(),
                plan.snapshot_revision,
                plan.pins.clone(),
                BTreeSet::new(),
                plan.pins
                    .logical_prune
                    .clone()
                    .map(|prune| (plan.protection.collector.token().clone(), prune)),
                retained,
            )
            .await?;
        plan.protection.collector.finish().await?;
        Ok(LogicalCollectionOutcome {
            revision: Some(commit.revision),
            removed: plan.preview,
            spill: plan.area.metrics(),
        })
    }

    #[tracing::instrument(
        name = "repository.collection.mark",
        skip_all,
        fields(mode = "logical")
    )]
    async fn logical_collection_plan(
        &self,
        guard: OwnedMutexGuard<()>,
        fs_guard: Option<ExclusiveLease>,
        wait: bool,
    ) -> Result<LogicalCollectionPlan, RepositoryError> {
        self.logical_collection_plan_with_recovery(guard, fs_guard, wait, None, None)
            .await
    }

    async fn logical_collection_plan_with_recovery(
        &self,
        guard: OwnedMutexGuard<()>,
        fs_guard: Option<ExclusiveLease>,
        wait: bool,
        recovery: Option<&crate::metadata::PinToken>,
        remote: Option<crate::metadata::RepositoryLease>,
    ) -> Result<LogicalCollectionPlan, RepositoryError> {
        let _phase = CollectionPhase::new("logical_plan");
        let admission_phase = CollectionPhase::new("collector_admission");
        let lease_phase = CollectionPhase::new("collector_backend_lease");
        let remote_guard = match remote {
            Some(remote) => remote,
            None => self.collector_state_lease(wait).await?,
        };
        drop(lease_phase);
        let area = self.spill_area();
        let releases = CollectionPhase::new("collector_release_barrier");
        crate::metadata::flush_pin_releases().await;
        drop(releases);
        let inventory_phase = CollectionPhase::new("collector_inventory");
        let ledger = self.state.pin_store().await?;
        let mut pins = ledger.inventory().await?;
        drop(inventory_phase);
        // Preserve an interrupted emergency fence throughout takeover and
        // marking. Only a successful recovery commit may reopen admission.
        if let Some(expected) = recovery {
            if pins.collector.as_ref() != Some(expected) {
                return Err(RepositoryError::Busy(
                    "abandoned collector token no longer matches the pin ledger".into(),
                ));
            }
        } else if pins.collector.is_some() && !self.emergency_collection {
            return Err(RepositoryError::Busy(
                "another collector owns the pin ledger; exact-token recovery may be required"
                    .into(),
            ));
        }
        let acquire_phase = CollectionPhase::new("collector_ledger_acquire");
        let collector =
            crate::metadata::CollectorLease::try_acquire(ledger.clone(), pins.collector.clone())
                .await?
                .ok_or_else(|| {
                    RepositoryError::Busy("collector admission raced a pin update".into())
                })?;
        drop(acquire_phase);
        // Begin history retention before reading the metadata head. A writer
        // that finishes during marking can no longer disappear from liveness.
        drop(admission_phase);
        let _mark_phase = CollectionPhase::new("logical_mark");
        let snapshot = self.state.snapshot().await?;
        pins = ledger.inventory().await?;
        let mut live_objects =
            mark_named_roots(snapshot.as_ref(), self.limits.max_traversal_objects, &area).await?;
        mark_pin_scopes(
            snapshot.as_ref(),
            &pins,
            &mut live_objects,
            self.limits.max_traversal_objects,
            &area,
        )
        .await?;
        let live_objects = live_objects.freeze().await?;

        let mut logical_objects = 0usize;
        let mut records = snapshot.objects_unordered();
        while let Some(record) = records.next().await {
            let record = record?;
            if !live_objects.contains(record.key()).await? {
                logical_objects += 1;
            }
        }

        Ok(LogicalCollectionPlan {
            protection: Arc::new(ExclusiveProtection {
                collector,
                _guard: guard,
                _fs_guard: fs_guard,
                remote: std::sync::Mutex::new(remote_guard),
            }),
            area,
            snapshot_revision: snapshot.revision(),
            pins: Arc::new(pins),
            snapshot: Some(snapshot),
            live_objects: Arc::new(live_objects),
            preview: LogicalCollectionPreview { logical_objects },
        })
    }

    async fn collector_state_lease(
        &self,
        wait: bool,
    ) -> Result<crate::RepositoryLease, RepositoryError> {
        loop {
            if let Some(lease) = self.state.try_collection_lease().await? {
                return Ok(lease);
            }
            if !wait {
                return Err(RepositoryError::Busy(
                    "another runner holds repository ownership".to_owned(),
                ));
            }
            tokio::time::sleep(std::time::Duration::from_millis(25)).await;
        }
    }

    async fn exclusive_fs(&self) -> Result<Option<ExclusiveLease>, RepositoryError> {
        match &self.fs_coordination {
            Some(coordination) => Ok(Some(coordination.exclusive().await?)),
            None => Ok(None),
        }
    }
}

impl<PS, SS> Repository<PS, SS>
where
    PS: BlobGc + 'static,
    SS: MetadataStore + 'static,
{
    async fn try_reclaim_metadata(&self) -> Result<bool, RepositoryError> {
        if !self.payloads.metadata_reclaim_due().await? {
            return Ok(false);
        }
        let _guard = self.coordination.clone().try_lock_owned().map_err(|_| {
            RepositoryError::Busy(
                "another collection or maintenance operation is active".to_owned(),
            )
        })?;
        let Some(coordination) = &self.fs_coordination else {
            return Ok(false);
        };
        let _fs_guard = coordination.try_exclusive().await?.ok_or_else(|| {
            RepositoryError::Busy(
                "another process holds collection or maintenance ownership".to_owned(),
            )
        })?;
        let repository = self.clone();
        crate::metadata::run_lease_task("metadata collection", |send| async move {
            // Keep collector history and ownership through every catalog
            // deletion, including when the caller cancels during admission.
            let _guard = _guard;
            let _fs_guard = _fs_guard;
            let scope = repository.payloads.write_scope();
            let result = scope
                .run(async {
                    if !repository.payloads.metadata_reclaim_due().await? {
                        return Ok(false);
                    }
                    crate::metadata::flush_pin_releases().await;
                    let pins = repository.state.pin_store().await?;
                    let collector =
                        crate::metadata::CollectorLease::try_acquire(pins.clone(), None)
                            .await?
                            .ok_or_else(|| {
                                RepositoryError::Busy(
                                    "another collector owns the pin ledger".into(),
                                )
                            })?;
                    repository.retained_snapshot().await?;
                    repository
                        .payloads
                        .reclaim_metadata_pinned(pins, BTreeSet::new())
                        .await?;
                    collector.finish().await?;
                    Ok(true)
                })
                .await;
            drop(send.send(result));
            Ok(())
        })
        .await?
    }

    /// Preview collection under exclusive ownership without changing logical
    /// or physical state.
    #[tracing::instrument(
        name = "repository.collection.preview",
        skip_all,
        fields(mode = "physical")
    )]
    pub async fn preview_collection(&self) -> Result<CollectionPreview, RepositoryError> {
        let guard = self.coordination.clone().lock_owned().await;
        let fs_guard = self.exclusive_fs().await?;
        let plan = self.collection_plan(guard, fs_guard, true).await?;
        tracing::info!(
            logical_objects = plan.preview.logical_objects,
            payload_blobs = plan.preview.payload_blobs,
            chunks = plan.preview.chunks,
            "collection preview completed"
        );
        plan.logical.protection.collector.finish().await?;
        Ok(plan.preview.clone())
    }

    /// Atomically prune unreachable logical records, then conservatively sweep
    /// physical payloads and chunks. Packing backends may durably defer a
    /// sparse pack rewrite; use [`Repository::vacuum`] when immediate physical
    /// reclamation matters. A physical deletion error leaves a valid logical
    /// state and merely leaks storage for a later retry.
    #[tracing::instrument(
        name = "repository.collection",
        skip_all,
        fields(mode = "physical", blocking = true, force_reclaim = false)
    )]
    pub async fn collect(&self) -> Result<CollectionOutcome, RepositoryError> {
        let outcome = self.run_collection(true, false).await?;
        tracing::info!(
            revision = ?outcome.revision,
            logical_objects = outcome.removed.logical_objects,
            payload_blobs = outcome.removed.payload_blobs,
            chunks = outcome.removed.chunks,
            spill_files = outcome.spill.files_opened,
            spill_peak_bytes = outcome.spill.peak_bytes,
            "collection completed"
        );
        Ok(outcome)
    }

    /// Resume an abandoned physical collection using its exact pin-ledger token.
    ///
    /// The caller MUST establish that the previous collector has stopped and
    /// all backend requests covered by its inherited deletion claims have
    /// settled. Cancellation, elapsed time,
    /// or a missing heartbeat does not establish this. For S3, recover its
    /// separate operational collector token first. Live reader and writer pins
    /// remain protected; this operation never clears their ownership.
    ///
    /// Recovery keeps every interrupted deletion claim and logical-prune fence
    /// through a fresh mark and successful metadata commit, then retries the
    /// sweep and catalog publication. Replaying an old token cannot take over a
    /// newer collector. Admission fails immediately if another collector is
    /// active. Once executing, recovery continues if its caller is cancelled.
    pub async fn recover_collection(
        &self,
        abandoned: &crate::metadata::PinToken,
    ) -> Result<CollectionOutcome, RepositoryError> {
        let guard = self
            .coordination
            .clone()
            .try_lock_owned()
            .map_err(|_| RepositoryError::Busy("another collector is active".into()))?;
        let fs_guard = match &self.fs_coordination {
            Some(coordination) => {
                Some(coordination.try_exclusive().await?.ok_or_else(|| {
                    RepositoryError::Busy("another process owns collection".into())
                })?)
            }
            None => None,
        };
        let plan = self
            .collection_plan_with_recovery(guard, fs_guard, false, Some(abandoned), None)
            .await?;
        let outcome = self.execute_collection(plan, true).await?;
        if let Some(start) = &self.mutation_start {
            start.collection_completed();
        }
        Ok(outcome)
    }

    /// Collect only if exclusive ownership is immediately available.
    ///
    /// This is intended for opportunistic housekeeping. It never waits for a
    /// mutation, stable reader, transfer, or another collector.
    #[tracing::instrument(
        name = "repository.collection",
        skip_all,
        fields(mode = "physical", blocking = false, force_reclaim = false)
    )]
    pub async fn try_collect(&self) -> Result<CollectionOutcome, RepositoryError> {
        self.run_collection(false, false).await
    }

    /// Collect unreachable state and force all durable packed garbage to be
    /// physically reclaimed, including sparse pack tombstones left by prior
    /// ordinary collections.
    #[tracing::instrument(
        name = "repository.collection",
        skip_all,
        fields(mode = "physical", blocking = true, force_reclaim = true)
    )]
    pub async fn vacuum(&self) -> Result<CollectionOutcome, RepositoryError> {
        let outcome = self.run_collection(true, true).await?;
        tracing::info!(
            revision = ?outcome.revision,
            logical_objects = outcome.removed.logical_objects,
            payload_blobs = outcome.removed.payload_blobs,
            chunks = outcome.removed.chunks,
            "vacuum completed"
        );
        Ok(outcome)
    }

    /// Vacuum only if exclusive ownership is immediately available.
    #[tracing::instrument(
        name = "repository.collection",
        skip_all,
        fields(mode = "physical", blocking = false, force_reclaim = true)
    )]
    pub async fn try_vacuum(&self) -> Result<CollectionOutcome, RepositoryError> {
        self.run_collection(false, true).await
    }

    async fn run_collection(
        &self,
        wait: bool,
        force_reclaim: bool,
    ) -> Result<CollectionOutcome, RepositoryError> {
        let guard = if wait {
            self.coordination.clone().lock_owned().await
        } else {
            self.coordination.clone().try_lock_owned().map_err(|_| {
                RepositoryError::Busy(
                    "another collection or maintenance operation is active".to_owned(),
                )
            })?
        };
        let fs_guard = if wait {
            self.exclusive_fs().await?
        } else {
            match &self.fs_coordination {
                Some(coordination) => {
                    Some(coordination.try_exclusive().await?.ok_or_else(|| {
                        RepositoryError::Busy(
                            "another process holds collection or maintenance ownership".to_owned(),
                        )
                    })?)
                }
                None => None,
            }
        };
        let plan = self.collection_plan(guard, fs_guard, wait).await?;
        let outcome = self.execute_collection(plan, force_reclaim).await?;
        if let Some(start) = &self.mutation_start {
            start.collection_completed();
        }
        Ok(outcome)
    }

    #[tracing::instrument(
        name = "repository.collection.execute",
        skip_all,
        fields(force_reclaim = force_reclaim)
    )]
    async fn execute_collection(
        &self,
        plan: CollectionPlan,
        force_reclaim: bool,
    ) -> Result<CollectionOutcome, RepositoryError> {
        let repository = self.clone();
        crate::metadata::run_lease_task("collection", |send| async move {
            let scope = repository.payloads.write_scope();
            let result = scope
                .run(repository.execute_collection_inner(plan, force_reclaim))
                .await;
            drop(send.send(result));
            Ok(())
        })
        .await?
    }

    async fn execute_collection_inner(
        &self,
        mut plan: CollectionPlan,
        force_reclaim: bool,
    ) -> Result<CollectionOutcome, RepositoryError> {
        // No sweep operation reads the mark snapshot. Release it before
        // publication can checkpoint the WAL; pins, the expected revision,
        // and the frozen retained sets protect the collection protocol.
        drop(plan.logical.snapshot.take());
        if plan.preview.logical_objects == 0 && plan.logical.pins.logical_prune.is_none() {
            let revision = plan.logical.snapshot_revision;
            let (catalog_commit, removed) = self
                .sweep_and_publish_catalog(&mut plan, force_reclaim, revision, None)
                .await?;
            self.finish_payload_collection(&plan, force_reclaim).await?;
            self.reclaim_payload_metadata(&plan, force_reclaim).await?;
            self.finish_sweep_claims(&plan).await?;
            plan.logical.protection.collector.finish().await?;
            plan.logical.protection.release();
            return Ok(CollectionOutcome {
                revision: catalog_commit.map(|commit| commit.revision),
                removed,
                spill: plan.logical.area.metrics(),
            });
        }

        let retained = MetadataMutation::install_retained_source(plan.logical.live_objects.clone());
        let prune = || {
            self.publication.prune(
                plan.logical.protection.clone(),
                plan.logical.snapshot_revision,
                plan.logical.pins.clone(),
                plan.claims.lock().unwrap().clone(),
                plan.logical
                    .pins
                    .logical_prune
                    .clone()
                    .map(|prune| (plan.logical.protection.collector.token().clone(), prune)),
                retained.clone(),
            )
        };
        #[cfg(test)]
        let first_commit = if storage_full_once_for_test("CASITA_TEST_STORAGE_FULL_ONCE") {
            Err(RepositoryError::Metadata(MetadataError::StorageFull))
        } else {
            prune().await
        };
        #[cfg(not(test))]
        let first_commit = prune().await;

        let (commit, swept) = match first_commit {
            Ok(commit) => (commit, None),
            Err(RepositoryError::Metadata(MetadataError::StorageFull))
                if self.emergency_collection =>
            {
                let pins = self.state.pin_store().await?;
                let inventory = pins.inventory().await?;
                if !inventory.same_payload_pins(&plan.logical.pins) {
                    return Err(RepositoryError::Busy(
                        "pin scopes changed before emergency collection".into(),
                    ));
                }
                let claims = plan.claims.lock().unwrap().clone();
                let fence = match &inventory.logical_prune {
                    Some(fence)
                        if plan.logical.pins.logical_prune.as_ref() == Some(fence)
                            && inventory.collector.as_ref()
                                == Some(plan.logical.protection.collector.token()) =>
                    {
                        fence.clone()
                    }
                    Some(_) => {
                        return Err(RepositoryError::Busy(
                            "emergency recovery lost its logical fence".into(),
                        ));
                    }
                    None => pins
                        .begin_prune_recovering(inventory.revision, claims)
                        .await?
                        .ok_or_else(|| {
                            RepositoryError::Busy(
                                "emergency prune admission conflicted with a pin".into(),
                            )
                        })?,
                };
                plan.logical.protection.retain();
                plan.sweep_pins = Arc::new(crate::metadata::PruningPinStore {
                    inner: pins.clone(),
                    collector: plan.logical.protection.collector.token().clone(),
                    prune: fence.clone(),
                });
                // Keep the same logical fence across physical deletion and
                // metadata retry. Only its exact collector can claim paths;
                // newly rooted inputs cannot enter the pre-prune stale set.
                let removed = self.sweep_collection_payloads(&plan, true, false).await?;
                #[cfg(test)]
                abort_after_emergency_sweep_for_test();
                let inventory = pins.inventory().await?;
                if !inventory.same_payload_pins(&plan.logical.pins) {
                    return Err(RepositoryError::Busy(
                        "pin scopes changed during emergency collection".into(),
                    ));
                }
                if !plan.sweep_pins.allows_deletion(&inventory) {
                    return Err(RepositoryError::Busy(
                        "emergency collector lost its logical fence".into(),
                    ));
                }
                // The enclosing tracked operation owns this commit through
                // cancellation. A failed retry leaves the fence for recovery.
                let commit = self
                    .state
                    .commit(&plan.logical.snapshot_revision, retained)
                    .await?;
                pins.finish_prune(&fence).await?;
                plan.sweep_pins = pins;
                (commit, Some(removed))
            }
            Err(error) => return Err(error),
        };

        let (catalog_commit, removed) = self
            .sweep_and_publish_catalog(&mut plan, force_reclaim, commit.revision, swept)
            .await?;
        self.finish_payload_collection(&plan, force_reclaim).await?;
        self.reclaim_payload_metadata(&plan, force_reclaim).await?;
        self.finish_sweep_claims(&plan).await?;
        plan.logical.protection.collector.finish().await?;
        plan.logical.protection.release();

        Ok(CollectionOutcome {
            revision: Some(catalog_commit.map_or(commit.revision, |catalog| catalog.revision)),
            removed,
            spill: plan.logical.area.metrics(),
        })
    }

    /// A small SQLite prune can succeed by reusing WAL space while the payload
    /// filesystem is full. Recover allocation failures in the subsequent sweep
    /// or external-root upload under the same durable emergency fencing used
    /// before a logical prune. Generic, non-colocated stores never take this path.
    async fn sweep_and_publish_catalog(
        &self,
        plan: &mut CollectionPlan,
        force_reclaim: bool,
        revision: crate::RepositoryRevision,
        mut removed: Option<CollectionPreview>,
    ) -> Result<(Option<CommitResult>, CollectionPreview), RepositoryError> {
        let result = async {
            #[cfg(test)]
            if storage_full_once_for_test("CASITA_TEST_POST_PRUNE_STORAGE_FULL_ONCE") {
                return Err(RepositoryError::Io(std::io::ErrorKind::StorageFull.into()));
            }
            if removed.is_none() {
                removed = Some(
                    self.sweep_collection_payloads(plan, force_reclaim, true)
                        .await?,
                );
            }
            self.commit_payload_catalog_from(Some(revision), plan.logical.protection.clone())
                .await
        }
        .await;
        match result {
            Ok(commit) => Ok((commit, removed.expect("successful sweep"))),
            Err(error) if self.emergency_collection && is_storage_full(&error) => {
                let pins = self.state.pin_store().await?;
                let inventory = pins.inventory().await?;
                if !inventory.same_payload_pins(&plan.logical.pins)
                    || inventory.logical_prune.is_some()
                    || inventory.collector.as_ref()
                        != Some(plan.logical.protection.collector.token())
                {
                    return Err(RepositoryError::Busy(
                        "pin scopes changed before post-prune emergency collection".into(),
                    ));
                }
                let claims = plan.claims.lock().unwrap().clone();
                let fence = pins
                    .begin_prune_recovering(inventory.revision, claims)
                    .await?
                    .ok_or_else(|| {
                        RepositoryError::Busy(
                            "post-prune emergency admission conflicted with a pin".into(),
                        )
                    })?;
                plan.logical.protection.retain();
                plan.sweep_pins = Arc::new(crate::metadata::PruningPinStore {
                    inner: pins.clone(),
                    collector: plan.logical.protection.collector.token().clone(),
                    prune: fence.clone(),
                });
                let swept = self.sweep_collection_payloads(plan, true, false).await?;
                #[cfg(test)]
                abort_after_emergency_sweep_for_test();
                let inventory = pins.inventory().await?;
                if !inventory.same_payload_pins(&plan.logical.pins)
                    || !plan.sweep_pins.allows_deletion(&inventory)
                {
                    return Err(RepositoryError::Busy(
                        "post-prune emergency collection lost its fence or pin scopes".into(),
                    ));
                }
                let commit = self
                    .commit_payload_catalog_from(Some(revision), plan.logical.protection.clone())
                    .await?;
                pins.finish_prune(&fence).await?;
                plan.sweep_pins = pins;
                Ok((commit, removed.unwrap_or(swept)))
            }
            Err(error) => Err(error),
        }
    }

    async fn finish_payload_collection(
        &self,
        plan: &CollectionPlan,
        force_reclaim: bool,
    ) -> Result<(), RepositoryError> {
        let _phase = CollectionPhase::new("finish_payload_collection");
        let owned_claims = plan.claims.lock().unwrap().clone();
        self.payloads
            .finish_collection_pinned(force_reclaim, self.state.pin_store().await?, owned_claims)
            .await?;
        Ok(())
    }

    async fn reclaim_payload_metadata(
        &self,
        plan: &CollectionPlan,
        force_reclaim: bool,
    ) -> Result<(), RepositoryError> {
        let _phase = CollectionPhase::new("reclaim_payload_metadata");
        // Maintenance keeps its admission hold through catalog publication or
        // discard. Exclusive collection therefore fences its inputs and output.
        if force_reclaim {
            let owned_claims = plan.claims.lock().unwrap().clone();
            self.payloads
                .reclaim_metadata_pinned(self.state.pin_store().await?, owned_claims)
                .await?;
        }
        Ok(())
    }

    async fn finish_sweep_claims(&self, plan: &CollectionPlan) -> Result<(), RepositoryError> {
        let _phase = CollectionPhase::new("finish_sweep_claims");
        let pins = self.state.pin_store().await?;
        let tokens = plan
            .claims
            .lock()
            .unwrap()
            .iter()
            .cloned()
            .collect::<Vec<_>>();
        for token in tokens {
            pins.finish_deletions(&token).await?;
            plan.claims.lock().unwrap().remove(&token);
        }
        Ok(())
    }

    async fn sweep_page(
        &self,
        plan: &CollectionPlan,
        mut page: SweepPage,
        logical_pruned: bool,
    ) -> Result<usize, RepositoryError> {
        use crate::metadata::PinResource;
        let pins = plan.sweep_pins.clone();
        // A page only shrinks. Once an immutable manifest's descendants have
        // been excluded, later retries need not read that manifest again.
        let mut expanded_blobs: BTreeSet<_> = plan
            .logical
            .pins
            .pins
            .values()
            .flat_map(|pin| &pin.resources)
            .filter_map(|resource| match resource {
                PinResource::Blob(blob) => Some(*blob),
                _ => None,
            })
            .collect();
        let claim_phase = CollectionPhase::new(match &page {
            SweepPage::Blobs(_) => "sweep_blob_claims",
            SweepPage::Chunks(_) => "sweep_chunk_claims",
        });
        loop {
            let _attempt = CollectionPhase::new(match &page {
                SweepPage::Blobs(_) => "sweep_blob_claim_attempt",
                SweepPage::Chunks(_) => "sweep_chunk_claim_attempt",
            });
            let inventory = pins.inventory().await?;
            if inventory.collector.as_ref() != plan.logical.pins.collector.as_ref() {
                return Err(RepositoryError::Busy("collection ownership changed".into()));
            }
            if !logical_pruned && !inventory.same_payload_pins(&plan.logical.pins) {
                return Err(RepositoryError::Busy(
                    "pin scopes changed during emergency collection sweep".into(),
                ));
            }
            // After logical pruning, later publications must protect every
            // physical identity before reuse. Collector history keeps those
            // resources visible even when the publishing session has ended.
            // Emergency sweep still needs the original logical mark unchanged.
            let protected: BTreeSet<_> = inventory
                .pins
                .values()
                .flat_map(|pin| pin.resources.iter())
                .collect();
            let mut checked_blobs = expanded_blobs.clone();
            let resources: BTreeSet<_> = match &mut page {
                SweepPage::Blobs(blobs) => {
                    blobs.retain(|blob| !protected.contains(&PinResource::Blob(*blob)));
                    blobs.iter().copied().map(PinResource::Blob).collect()
                }
                SweepPage::Chunks(chunks) => {
                    chunks.retain(|chunk| !protected.contains(&PinResource::Chunk(*chunk)));
                    // Existing-payload imports may pin a manifest without
                    // uploading its chunks. Expand new manifest pins before
                    // claiming remaining chunks; admission rejects any further
                    // manifest that has not been checked against this page.
                    for resource in &protected {
                        let PinResource::Blob(blob) = resource else {
                            continue;
                        };
                        if expanded_blobs.contains(blob) {
                            continue;
                        }
                        if chunks.is_empty() {
                            break;
                        }
                        let present = self.payloads.has(blob).await?;
                        if let Some(manifest) = self.payloads.chunks_for_gc(blob, present).await? {
                            let descendants: BTreeSet<_> =
                                manifest.into_iter().map(|chunk| chunk.digest).collect();
                            chunks.retain(|chunk| !descendants.contains(chunk));
                            expanded_blobs.insert(*blob);
                        }
                        // An absent manifest is checked for this attempt,
                        // but must be re-read on retry if it has since appeared.
                        checked_blobs.insert(*blob);
                    }
                    chunks.iter().copied().map(PinResource::Chunk).collect()
                }
            };
            if resources.is_empty() {
                return Ok(0);
            }
            let owned = plan.claims.lock().unwrap().clone();
            let covered: BTreeSet<_> = inventory
                .deletions
                .iter()
                .filter(|(token, _)| owned.contains(token))
                .flat_map(|(_, resources)| resources.iter().cloned())
                .collect();
            let resources: BTreeSet<_> = resources.difference(&covered).cloned().collect();
            if !pins.allows_deletion(&inventory)
                || inventory
                    .deletions
                    .iter()
                    .any(|(token, claim)| !owned.contains(token) && !claim.is_disjoint(&resources))
            {
                return Err(RepositoryError::Busy(
                    "collection deletion is fenced by another operation".into(),
                ));
            }
            if !resources.is_empty() {
                let claimed = if logical_pruned {
                    pins.claim_deletions_validated(
                        plan.logical.protection.collector.token(),
                        resources,
                        checked_blobs,
                    )
                    .await?
                } else {
                    pins.claim_deletions(inventory.revision, resources).await?
                };
                let Some(token) = claimed else {
                    // A concurrent pin won admission. Refresh this bounded page
                    // and skip its resources instead of restarting the mark.
                    continue;
                };
                plan.claims.lock().unwrap().insert(token);
            }
            break;
        }
        drop(claim_phase);
        let _delete_phase = CollectionPhase::new(match &page {
            SweepPage::Blobs(_) => "sweep_delete_blobs",
            SweepPage::Chunks(_) => "sweep_delete_chunks",
        });
        plan.logical.protection.retain();
        // The enclosing tracked collection owns this I/O through cancellation.
        // Claims remain until deferred physical cleanup has also settled.
        let removed = match page {
            SweepPage::Blobs(blobs) => {
                let owned_claims = plan.claims.lock().unwrap().clone();
                self.payloads
                    .delete_blobs_pinned(&blobs, pins, owned_claims, !logical_pruned)
                    .await?
            }
            SweepPage::Chunks(chunks) => {
                let owned_claims = plan.claims.lock().unwrap().clone();
                self.payloads
                    .delete_chunks_pinned(&chunks, pins, owned_claims)
                    .await?
            }
        };
        Ok(removed)
    }

    /// Delete the physical data the plan classified as stale, one bounded page
    /// at a time so a sweep never materializes the whole stale inventory.
    #[tracing::instrument(
        name = "repository.collection.sweep",
        skip_all,
        fields(force_reclaim = force_reclaim)
    )]
    async fn sweep_collection_payloads(
        &self,
        plan: &CollectionPlan,
        force_reclaim: bool,
        logical_pruned: bool,
    ) -> Result<CollectionPreview, RepositoryError> {
        let _phase = CollectionPhase::new("sweep_payloads");
        let mut removed = CollectionPreview {
            logical_objects: plan.preview.logical_objects,
            payload_blobs: 0,
            chunks: 0,
        };
        let mut after = None;
        loop {
            let page = plan.stale_blobs.page(after, SWEEP_PAGE).await?;
            let Some(last) = page.last().copied() else {
                break;
            };
            removed.payload_blobs += self
                .sweep_page(plan, SweepPage::Blobs(page), logical_pruned)
                .await?;
            after = Some(last);
        }
        let mut after = None;
        loop {
            let page = plan.stale_chunks.page(after, SWEEP_PAGE).await?;
            let Some(last) = page.last().copied() else {
                break;
            };
            removed.chunks += self
                .sweep_page(plan, SweepPage::Chunks(page), logical_pruned)
                .await?;
            after = Some(last);
        }
        plan.logical.protection.retain();
        let owned_claims = plan.claims.lock().unwrap().clone();
        let _finish_phase = CollectionPhase::new("finish_deletions");
        self.payloads
            .finish_deletions_pinned(
                force_reclaim,
                plan.sweep_pins.clone(),
                owned_claims,
                !logical_pruned,
            )
            .await?;
        Ok(removed)
    }

    /// Verify logical state, payload identity, format relations, root closure,
    /// and physical coverage without reconstructing primary records from
    /// payload scans. The scan pins its snapshot while allowing collection of
    /// unrelated data. Returns `Busy` if collection prevents safe admission;
    /// retry after collection, or recover an interrupted collector first.
    #[tracing::instrument(name = "repository.fsck", skip_all)]
    pub async fn fsck(&self) -> Result<FsckReport, RepositoryError> {
        let (snapshot, _protection) = self.pinned_retained_snapshot(false, None).await?;
        let snapshot = snapshot.0;
        let revision = snapshot.revision();
        let mut issues = Vec::new();

        // Stream roots straight into the spillable queue. Retaining all root
        // records here would make fsck's memory depend on the number of names
        // rather than its traversal limits.
        let area = self.spill_area();
        let mut reachable = SpillSet::new(area.clone(), "fsck-reachable");
        let mut reported_missing = SpillSet::new(area.clone(), "fsck-missing");
        let mut queue = TraversalQueue::new(area.clone());
        let mut roots_checked = 0usize;
        let mut root_stream = snapshot.roots();
        while let Some(root) = root_stream.next().await {
            match root {
                Ok(root) => queue.push((None, root.target().clone())).await?,
                Err(error) => {
                    issues.push(FsckIssue {
                        disposition: FsckDisposition::Corrupt,
                        kind: FsckIssueKind::StateEncoding,
                        object: None,
                        message: error.to_string(),
                    });
                    break;
                }
            }
            roots_checked += 1;
            if roots_checked > self.limits.max_traversal_objects {
                return Err(RepositoryError::LimitExceeded(format!(
                    "fsck root enumeration exceeded {} roots",
                    self.limits.max_traversal_objects
                )));
            }
        }
        drop(root_stream);

        // Small and medium snapshots fit under the traversal's existing
        // in-memory object limit. Preloading their immutable records through
        // the sequential stream avoids a random SQLite lookup (and its page
        // reads) for every graph edge. If one more record crosses the bound,
        // discard the cache and retain the fully streaming path used for very
        // large repositories.
        let mut cached_records = HashMap::with_capacity(
            self.spill_limits
                .max_memory_objects
                .min(self.limits.max_traversal_objects),
        );
        let mut cache_complete = true;
        let mut cache_stream = snapshot.objects_unordered();
        while let Some(record) = cache_stream.next().await {
            let record = record?;
            if cached_records.len() >= self.spill_limits.max_memory_objects {
                cache_complete = false;
                break;
            }
            cached_records.insert(record.key().clone(), record);
        }
        drop(cache_stream);
        let cached_records = cache_complete.then_some(cached_records);
        let cached_order = cached_records.as_ref().map(|records| {
            let mut keys = records.keys().cloned().collect::<Vec<_>>();
            keys.sort_unstable();
            keys
        });

        // Graph discovery itself does not open payloads, so it stays in
        // canonical breadth-first order. Payload verification below uses a
        // bounded physical-order window to avoid cycling the pack cache.
        loop {
            // Batched insertion may admit every key in the frontier. Keep its
            // worst-case overrun to the single key that proves the limit.
            let frontier_limit = CLOSURE_FRONTIER.min(
                self.limits
                    .max_traversal_objects
                    .saturating_sub(reachable.len())
                    .saturating_add(1),
            );
            let mut frontier = Vec::with_capacity(frontier_limit);
            while frontier.len() < frontier_limit {
                let Some(step) = queue.pop().await? else {
                    break;
                };
                frontier.push(step);
            }
            if frontier.is_empty() {
                break;
            }
            let keys = frontier
                .iter()
                .map(|(_, key)| key.clone())
                .collect::<Vec<_>>();
            let records = match &cached_records {
                Some(cached) => keys.iter().map(|key| cached.get(key).cloned()).collect(),
                None => snapshot.object_batch(&keys).await?,
            };
            let inserted = reachable.insert_batch(&keys).await?;
            for (((from, key), record), inserted) in frontier.into_iter().zip(records).zip(inserted)
            {
                if !inserted {
                    continue;
                }
                if reachable.len() > self.limits.max_traversal_objects {
                    return Err(RepositoryError::LimitExceeded(format!(
                        "fsck root traversal exceeded {} objects",
                        self.limits.max_traversal_objects
                    )));
                }
                let Some(record) = record else {
                    reported_missing.insert(key.clone()).await?;
                    issues.push(FsckIssue {
                        disposition: FsckDisposition::Corrupt,
                        kind: FsckIssueKind::MissingRecord,
                        object: Some(key.clone()),
                        message: match from {
                            Some(from) => {
                                format!("reachable object {from} links to missing {key}")
                            }
                            None => format!("named root targets missing object {key}"),
                        },
                    });
                    continue;
                };
                for target in record.links() {
                    queue.push((Some(key.clone()), target.clone())).await?;
                }
            }
        }

        // Capture physical manifests before validating payloads. The same
        // inventory selects both the bytes fsck reads and the chunks it marks,
        // so an ordinary-read accelerator cannot hide a present manifest.
        let mut physical_blobs = SpillSet::new(area.clone(), "fsck-physical-blobs");
        let insertion_batch = self
            .spill_limits
            .max_memory_objects
            .clamp(1, FSCK_MEMBERSHIP_BATCH);
        let mut pending_blobs = Vec::with_capacity(insertion_batch);
        let mut blobs = self.payloads.list_blobs();
        while let Some(blob) = blobs.next().await {
            pending_blobs.push(blob?);
            if pending_blobs.len() == insertion_batch {
                physical_blobs.insert_batch(&pending_blobs).await?;
                pending_blobs.clear();
            }
        }
        drop(blobs);
        physical_blobs.insert_batch(&pending_blobs).await?;
        drop(pending_blobs);

        let mut record_payloads = SpillSet::new(area.clone(), "fsck-payloads");
        let mut pending_payloads = Vec::with_capacity(insertion_batch);
        let mut referenced_chunks = SpillSet::new(area.clone(), "fsck-chunks");
        let mut objects_checked = 0usize;
        let mut object_stream = snapshot.objects();
        let mut cached_at = 0usize;
        loop {
            let mut batch = Vec::with_capacity(FSCK_SCAN_WINDOW);
            let mut exhausted = false;
            while batch.len() < FSCK_SCAN_WINDOW {
                let next = match &cached_order {
                    Some(order) => match order.get(cached_at) {
                        Some(key) => {
                            cached_at += 1;
                            Some(Ok(cached_records
                                .as_ref()
                                .expect("cached order requires records")
                                .get(key)
                                .expect("cached order names an existing record")
                                .clone()))
                        }
                        None => None,
                    },
                    None => object_stream.next().await,
                };
                let Some(record) = next else {
                    exhausted = true;
                    break;
                };
                match record {
                    Ok(record) => {
                        let order = self.payloads.physical_scan_order(&record.payload()).await?;
                        batch.push((order, record));
                    }
                    Err(error) => {
                        issues.push(FsckIssue {
                            disposition: FsckDisposition::Corrupt,
                            kind: FsckIssueKind::StateEncoding,
                            object: None,
                            message: error.to_string(),
                        });
                        exhausted = true;
                        break;
                    }
                }
            }
            batch.sort_unstable_by_key(|(pack, record)| {
                (
                    pack.is_none(),
                    *pack,
                    record.payload(),
                    record.key().clone(),
                )
            });
            let mut manifests_present = Vec::with_capacity(batch.len());
            let mut rooted = Vec::with_capacity(batch.len());
            for records in batch.chunks(FSCK_MEMBERSHIP_BATCH) {
                let payloads: Vec<_> = records.iter().map(|(_, record)| record.payload()).collect();
                let keys: Vec<_> = records.iter().map(|(_, record)| record.key()).collect();
                manifests_present.extend(physical_blobs.contains_batch(&payloads).await?);
                rooted.extend(reachable.contains_batch(&keys).await?);
            }
            for (((_, record), manifest_present), rooted) in
                batch.into_iter().zip(manifests_present).zip(rooted)
            {
                objects_checked += 1;
                if objects_checked > self.limits.max_traversal_objects {
                    return Err(RepositoryError::LimitExceeded(format!(
                        "fsck object enumeration exceeded {} records",
                        self.limits.max_traversal_objects
                    )));
                }
                let record = &record;
                let key = record.key();
                let disposition = if rooted {
                    FsckDisposition::Corrupt
                } else {
                    FsckDisposition::Collectible
                };
                if !rooted {
                    issues.push(FsckIssue {
                        disposition: FsckDisposition::Collectible,
                        kind: FsckIssueKind::UnrootedObject,
                        object: Some(key.clone()),
                        message: format!("object {key} is unreachable from every named root"),
                    });
                }
                pending_payloads.push(record.payload());
                if pending_payloads.len() == insertion_batch {
                    record_payloads.insert_batch(&pending_payloads).await?;
                    pending_payloads.clear();
                }
                let mut missing_links = Vec::new();
                // The rooted traversal above already proved every direct
                // target exists. Only collectible records outside that graph
                // need a separate link-existence check.
                if !rooted {
                    let targets = record.links();
                    let linked = match &cached_records {
                        Some(cached) => targets
                            .iter()
                            .map(|target| cached.get(target).cloned())
                            .collect(),
                        None => snapshot.object_batch(targets).await?,
                    };
                    for (target, found) in targets.iter().zip(linked) {
                        if found.is_none() {
                            missing_links.push(target.clone());
                        }
                    }
                }
                for missing in &missing_links {
                    if reported_missing.insert(missing.clone()).await? {
                        issues.push(FsckIssue {
                            disposition,
                            kind: FsckIssueKind::MissingRecord,
                            object: Some(missing.clone()),
                            message: format!("object {key} links to missing {missing}"),
                        });
                    }
                }

                let Some(format) = self.formats.get(key.namespace()) else {
                    issues.push(FsckIssue {
                        disposition: FsckDisposition::Unchecked,
                        kind: FsckIssueKind::UnsupportedNamespace,
                        object: Some(key.clone()),
                        message: format!(
                            "no verifier is registered for namespace `{}`",
                            key.namespace()
                        ),
                    });
                    continue;
                };
                let Some(mut payload) = self
                    .payloads
                    .open_read_for_fsck(&record.payload(), manifest_present)
                    .await?
                else {
                    issues.push(FsckIssue {
                        disposition,
                        kind: FsckIssueKind::MissingPayload,
                        object: Some(key.clone()),
                        message: format!("record payload {} is absent", record.payload()),
                    });
                    continue;
                };
                let mut payload = BlobPayloadReader::new(payload.as_mut(), record.payload_size());
                let verification = if missing_links.is_empty() {
                    let allowed: BTreeSet<_> = record.links().iter().cloned().collect();
                    let view = RepositoryDirectLinkView {
                        payloads: &self.payloads,
                        snapshot: snapshot.as_ref(),
                        overlay: &BTreeMap::new(),
                        cached: cached_records.as_ref(),
                        allowed: &allowed,
                    };
                    format
                        .verify_links(
                            VerificationContext::new(key, &mut payload),
                            record,
                            &view,
                            &self.limits,
                        )
                        .await
                } else {
                    format
                        .verify(VerificationContext::new(key, &mut payload), &self.limits)
                        .await
                        .and_then(|verified| {
                            if verified.record() == record {
                                Ok(())
                            } else {
                                Err(FormatError::RecordMismatch(key.clone()))
                            }
                        })
                };
                if let Err(error) = verification {
                    issues.push(FsckIssue {
                        disposition,
                        kind: FsckIssueKind::InvalidObject,
                        object: Some(key.clone()),
                        message: error.to_string(),
                    });
                    continue;
                }

                let chunks = self
                    .payloads
                    .chunks_for_gc(&record.payload(), manifest_present)
                    .await?
                    .ok_or_else(|| {
                        MetadataError::Corruption(format!(
                            "verified payload {} disappeared during fsck",
                            record.payload()
                        ))
                    })?;
                for chunks in chunks.chunks(insertion_batch) {
                    let keys: Vec<_> = chunks.iter().map(|chunk| chunk.digest).collect();
                    referenced_chunks.insert_batch(&keys).await?;
                }
            }
            if exhausted {
                break;
            }
        }
        drop(object_stream);
        record_payloads.insert_batch(&pending_payloads).await?;
        drop(pending_payloads);

        // The physical inventories are sorted through the same spillable sets,
        // so issue order stays canonical without holding either listing whole.
        let payloads_checked = record_payloads.len();
        let mut listed = std::pin::pin!(physical_blobs.into_difference(record_payloads));
        while let Some(payload) = listed.next().await {
            let payload = payload?;
            issues.push(FsckIssue {
                disposition: FsckDisposition::Collectible,
                kind: FsckIssueKind::UnreferencedPayload,
                object: None,
                message: format!("physical payload {payload} has no logical record"),
            });
        }

        let mut physical_chunks = SpillSet::new(area.clone(), "fsck-physical-chunks");
        let mut pending_chunks = Vec::with_capacity(insertion_batch);
        let mut chunks = self.payloads.list_chunks();
        while let Some(chunk) = chunks.next().await {
            pending_chunks.push(chunk?);
            if pending_chunks.len() == insertion_batch {
                physical_chunks.insert_batch(&pending_chunks).await?;
                pending_chunks.clear();
            }
        }
        drop(chunks);
        physical_chunks.insert_batch(&pending_chunks).await?;
        let mut listed = std::pin::pin!(physical_chunks.into_difference(referenced_chunks));
        while let Some(chunk) = listed.next().await {
            let chunk = chunk?;
            issues.push(FsckIssue {
                disposition: FsckDisposition::Collectible,
                kind: FsckIssueKind::UnreferencedChunk,
                object: None,
                message: format!("physical chunk {chunk} has no logical payload"),
            });
        }
        let report = FsckReport {
            revision,
            objects_checked,
            roots_checked,
            payloads_checked,
            spill: area.metrics(),
            issues,
        };
        tracing::info!(
            revision = %report.revision,
            objects_checked = report.objects_checked,
            roots_checked = report.roots_checked,
            payloads_checked = report.payloads_checked,
            findings = report.issues.len(),
            spill_files = report.spill.files_opened,
            spill_peak_bytes = report.spill.peak_bytes,
            "integrity scan completed"
        );
        Ok(report)
    }

    #[tracing::instrument(
        name = "repository.collection.mark",
        skip_all,
        fields(mode = "physical")
    )]
    async fn collection_plan(
        &self,
        guard: OwnedMutexGuard<()>,
        fs_guard: Option<ExclusiveLease>,
        wait: bool,
    ) -> Result<CollectionPlan, RepositoryError> {
        self.collection_plan_with_recovery(guard, fs_guard, wait, None, None)
            .await
    }

    async fn collection_plan_with_recovery(
        &self,
        guard: OwnedMutexGuard<()>,
        fs_guard: Option<ExclusiveLease>,
        wait: bool,
        recovery: Option<&crate::metadata::PinToken>,
        remote: Option<crate::metadata::RepositoryLease>,
    ) -> Result<CollectionPlan, RepositoryError> {
        let _phase = CollectionPhase::new("physical_plan");
        let logical = self
            .logical_collection_plan_with_recovery(guard, fs_guard, wait, recovery, remote)
            .await?;
        let _physical_mark_phase = CollectionPhase::new("physical_mark");
        if !logical.pins.deletions.is_empty() && !self.emergency_collection && recovery.is_none() {
            return Err(RepositoryError::Busy(
                "interrupted deletion claims require exact-token recovery".into(),
            ));
        }
        // The standard local profile owns the filesystem collector fence.
        // Its previous owner has either finished its tracked task or exited,
        // so local filesystem I/O cannot still arrive from that operation.
        // Preserve its claims throughout retry; never reopen admission first.
        let claims = Arc::new(std::sync::Mutex::new(
            logical.pins.deletions.keys().cloned().collect(),
        ));
        self.publication
            .synchronize(
                &self.payloads,
                logical.snapshot.as_ref().expect("mark snapshot").as_ref(),
            )
            .await?;
        let area = logical.area.clone();

        // Every inventory below is read in fixed-size pages, and every set
        // spills onto this operation's shared temporary-storage budget. A
        // repository larger than memory can therefore be collected without
        // re-materializing its live graph.
        let mut live_payloads = SpillSet::new(area.clone(), "live-payloads");
        let mut after = None;
        loop {
            let keys = logical
                .live_objects
                .page(after.clone(), CLOSURE_FRONTIER)
                .await?;
            let Some(last) = keys.last().cloned() else {
                break;
            };
            let found = logical
                .snapshot
                .as_ref()
                .expect("mark snapshot")
                .object_batch(&keys)
                .await?;
            for (key, record) in keys.into_iter().zip(found) {
                let record = record.ok_or_else(|| {
                    MetadataError::Corruption(format!(
                        "marked object {key} is absent from its snapshot"
                    ))
                })?;
                live_payloads.insert(record.payload()).await?;
            }
            after = Some(last);
        }

        let mut live_chunks = SpillSet::new(area.clone(), "live-chunks");
        let live_payloads = live_payloads.freeze().await?;

        // Build the manifest inventory once. Besides classifying stale
        // manifests below, it lets packed stores identify manifest-elided
        // one-chunk payloads without one guaranteed-miss object-store GET per
        // payload during the chunk mark pass.
        let mut physical_blobs = SpillSet::new(area.clone(), "physical-blobs");
        let mut blobs = self.payloads.list_blobs();
        while let Some(blob) = blobs.next().await {
            physical_blobs.insert(blob?).await?;
        }
        drop(blobs);
        let physical_blobs = physical_blobs.freeze().await?;
        let physical_blobs = &physical_blobs;

        let mut after = None;
        loop {
            let payloads = live_payloads.page(after, CLOSURE_FRONTIER).await?;
            let Some(last) = payloads.last().copied() else {
                break;
            };
            let reads = payloads.into_iter().map(|payload| async move {
                let manifest_present = physical_blobs.contains(&payload).await?;
                let chunks = self
                    .payloads
                    .chunks_for_gc(&payload, manifest_present)
                    .await?
                    .ok_or_else(|| {
                        MetadataError::Corruption(format!(
                            "reachable object payload {payload} is physically absent"
                        ))
                    })?;
                Ok::<_, RepositoryError>(chunks)
            });
            let reads = futures::stream::iter(reads).buffered(COLLECTION_PAYLOAD_READS);
            futures::pin_mut!(reads);
            while let Some(chunks) = reads.next().await {
                let chunks = chunks?;
                for chunk in chunks {
                    live_chunks.insert(chunk.digest).await?;
                }
            }
            after = Some(last);
        }

        // A writer may own bytes before publishing any logical record. Its
        // manifest may still be in flight; retain existing representations and
        // tolerate the absent ones until the write completes.
        let mut pinned_payloads = SpillSet::new(area.clone(), "pinned-payloads");
        for pin in logical.pins.pins.values() {
            for resource in &pin.resources {
                match resource {
                    crate::metadata::PinResource::Blob(blob) => {
                        pinned_payloads.insert(*blob).await?;
                    }
                    crate::metadata::PinResource::Chunk(chunk) => {
                        live_chunks.insert(*chunk).await?;
                    }
                    _ => {}
                }
            }
        }
        let pinned_payloads = pinned_payloads.freeze().await?;
        let mut after = None;
        loop {
            let page = pinned_payloads.page(after, CLOSURE_FRONTIER).await?;
            let Some(last) = page.last().copied() else {
                break;
            };
            for payload in page {
                if live_payloads.contains(&payload).await? {
                    continue;
                }
                let present = physical_blobs.contains(&payload).await?;
                if let Some(chunks) = self.payloads.chunks_for_gc(&payload, present).await? {
                    for chunk in chunks {
                        live_chunks.insert(chunk.digest).await?;
                    }
                }
            }
            after = Some(last);
        }

        let mut stale_blobs = SpillSet::new(area.clone(), "stale-blobs");
        let mut after = None;
        loop {
            let blobs = physical_blobs.page(after, CLOSURE_FRONTIER).await?;
            let Some(last) = blobs.last().copied() else {
                break;
            };
            for blob in blobs {
                if !live_payloads.contains(&blob).await? && !pinned_payloads.contains(&blob).await?
                {
                    stale_blobs.insert(blob).await?;
                }
            }
            after = Some(last);
        }

        drop(live_payloads);
        let live_chunks = live_chunks.freeze().await?;
        let mut stale_chunks = SpillSet::new(area.clone(), "stale-chunks");
        let mut chunks = self.payloads.list_chunks();
        while let Some(chunk) = chunks.next().await {
            let chunk = chunk?;
            if !live_chunks.contains(&chunk).await? {
                stale_chunks.insert(chunk).await?;
            }
        }
        drop(chunks);

        let preview = CollectionPreview {
            logical_objects: logical.preview.logical_objects,
            payload_blobs: stale_blobs.len(),
            chunks: stale_chunks.len(),
        };
        // Frozen from here on: the plan only reads these sets, in pages, and
        // the retained set may be read twice if the commit is retried.
        let stale_blobs = stale_blobs.freeze().await?;
        let stale_chunks = stale_chunks.freeze().await?;

        // Carry collector ownership and exact claims through mark, prune, and
        // sweep. Readers and writers continue through disjoint online pins.
        Ok(CollectionPlan {
            logical,
            sweep_pins: self.state.pin_store().await?,
            claims,
            stale_blobs,
            stale_chunks,
            preview,
        })
    }
}

/// Stale physical entries deleted per bounded sweep page.
const SWEEP_PAGE: usize = 1024;

/// Concurrent payload inventories during collection's chunk mark pass.
const COLLECTION_PAYLOAD_READS: usize = 8;

/// Records reordered together for sequential immutable-pack integrity reads.
///
/// The tuple stored for each record is small, and this bound remains constant
/// even when the repository is much larger than memory.
const FSCK_SCAN_WINDOW: usize = 65_536;

/// Bound temporary key buffers used to check each physical scan window.
const FSCK_MEMBERSHIP_BATCH: usize = 1024;

/// Objects a closure traversal resolves per state call.
///
/// Wide enough that the per-call cost stops mattering, small enough that the
/// resolved records stay a bounded working set beside the spilling queue.
const CLOSURE_FRONTIER: usize = 256;

#[cfg(test)]
#[path = "repository/fsck_benchmark.rs"]
mod fsck_benchmark;

#[cfg(test)]
fn abort_after_emergency_sweep_for_test() {
    if std::env::var_os("CASITA_TEST_ABORT_AFTER_EMERGENCY_SWEEP").is_some() {
        std::process::abort();
    }
}

/// Whether this collection should behave as though the state engine had no
/// room left to commit in.
///
/// Reaching the emergency path for real needs a filesystem at zero free space,
/// and creating one without disturbing the host needs a mount namespace that
/// not every machine grants an unprivileged process. Standing in for it here
/// keeps the crash and the recovery after it testable anywhere; the
/// filesystem-level proof that a real ENOSPC arrives as `StorageFull` lives in
/// `tests/full_disk_gc.rs`, which runs wherever namespaces are permitted.
#[cfg(test)]
fn storage_full_once_for_test(variable: &str) -> bool {
    use std::sync::atomic::{AtomicBool, Ordering};
    static SPENT: AtomicBool = AtomicBool::new(false);
    std::env::var_os(variable).is_some() && !SPENT.swap(true, Ordering::SeqCst)
}

struct DataProtection {
    _payload_batch: crate::blob::BlobBatchGuard,
    _pin: Option<crate::metadata::DataPinLease>,
}

struct ExclusiveProtection {
    collector: crate::metadata::CollectorLease,
    _guard: OwnedMutexGuard<()>,
    _fs_guard: Option<ExclusiveLease>,
    remote: std::sync::Mutex<crate::RepositoryLease>,
}

impl ExclusiveProtection {
    fn retain(&self) {
        self.remote.lock().unwrap().retain_on_drop();
    }
    fn release(&self) {
        self.remote.lock().unwrap().release_on_drop();
    }
}

struct LogicalCollectionPlan {
    protection: Arc<ExclusiveProtection>,
    area: SpillArea,
    snapshot_revision: crate::RepositoryRevision,
    pins: Arc<crate::metadata::PinInventory>,
    snapshot: Option<Arc<dyn MetadataSnapshot>>,
    live_objects: Arc<FrozenSpillSet<ObjectKey>>,
    preview: LogicalCollectionPreview,
}

enum SweepPage {
    Blobs(Vec<BlobId>),
    Chunks(Vec<ChunkId>),
}

struct CollectionPlan {
    logical: LogicalCollectionPlan,
    sweep_pins: Arc<dyn crate::metadata::PinStore>,
    claims: Arc<std::sync::Mutex<BTreeSet<crate::metadata::PinToken>>>,
    stale_blobs: FrozenSpillSet<BlobId>,
    stale_chunks: FrozenSpillSet<ChunkId>,
    preview: CollectionPreview,
}

/// One coordinated staging and mutation lifetime.
pub struct MutationSession<'a, PS, SS> {
    repository: &'a Repository<PS, SS>,
    protection: Arc<DataProtection>,
    pin: crate::metadata::DataPinLease,
}

impl<PS, SS> MutationSession<'_, PS, SS> {
    /// Repository protected by this mutation/collection hold.
    pub fn repository(&self) -> &Repository<PS, SS> {
        self.repository
    }
}

impl<PS, SS> MutationSession<'_, PS, SS>
where
    PS: BlobStore,
    SS: MetadataStore,
{
    pub(crate) fn write_scope(&self) -> crate::metadata::BackendWriteScope {
        self.repository
            .payloads
            .write_scope()
            .with_pin(self.pin.clone())
    }

    /// Retain selected objects and their closures before reading reusable state.
    pub(crate) async fn retain_objects(
        &self,
        keys: impl IntoIterator<Item = ObjectKey>,
    ) -> Result<(), RepositoryError> {
        self.pin
            .protect(
                keys.into_iter()
                    .map(crate::metadata::PinResource::Object)
                    .collect(),
            )
            .await?;
        Ok(())
    }

    // Catalog protection belongs to the operation using this snapshot, not to
    // the entire mutation. Otherwise every publication retains another full
    // catalog and a long import eventually fills the pin inventory.
    async fn pinned_snapshot(
        &self,
    ) -> Result<(Arc<dyn MetadataSnapshot>, crate::metadata::DataPinLease), RepositoryError> {
        self.write_scope()
            .run(async {
                let (snapshot, pin) =
                    pin_metadata_snapshot_kind(self.repository.state.as_ref(), true, true, None)
                        .await?;
                self.repository
                    .publication
                    .synchronize(&self.repository.payloads, snapshot.as_ref())
                    .await?;
                Ok((snapshot, pin))
            })
            .await
    }

    /// Store and verify raw bytes as `casita.blob.v1`.
    ///
    /// Same-length edits can use [`Self::stage_blob_overwrite`] to reuse
    /// authenticated BLAKE3 subtrees and unchanged physical chunks.
    #[tracing::instrument(
        name = "repository.stage_blob",
        level = "debug",
        skip_all,
        fields(bytes = bytes.len())
    )]
    pub async fn stage_blob<'hold>(
        &'hold self,
        bytes: &[u8],
    ) -> Result<StagedObject<'hold>, RepositoryError> {
        self.write_scope()
            .run(async {
                let payload_size = bytes.len() as u64;
                if payload_size > self.repository.limits.max_payload_bytes {
                    return Err(FormatError::PayloadLimit {
                        limit: self.repository.limits.max_payload_bytes,
                    }
                    .into());
                }
                let expected = BlobId::new(blake3::hash(bytes).into());
                let payload = self.repository.payloads.put_slice(bytes).await?;
                if payload != expected {
                    return Err(RepositoryError::PayloadIdentityMismatch {
                        expected,
                        actual: payload,
                    });
                }
                let verified =
                    BlobFormat::seal_written(payload, payload_size, &self.repository.limits)?;
                Ok(StagedObject {
                    verified,
                    repository: self.repository.staging_identity.clone(),
                    _hold: std::marker::PhantomData,
                })
            })
            .await
    }

    /// Stage a same-length edit to an existing raw blob. The backend supplies
    /// a proof of the old bytes; the repository independently authenticates
    /// that proof and derives the new content ID before sealing publication.
    pub async fn stage_blob_overwrite<'hold>(
        &'hold self,
        key: &ObjectKey,
        offset: u64,
        replacement: &[u8],
    ) -> Result<StagedObject<'hold>, RepositoryError> {
        self.write_scope()
            .run(async {
                self.retain_objects([key.clone()]).await?;
                let (snapshot, _snapshot_pin) = self.pinned_snapshot().await?;
                let record = snapshot
                    .object(key)
                    .await?
                    .ok_or_else(|| RepositoryError::Absent(key.to_string()))?;
                if record.key() != &ObjectKey::blob(record.payload()) || !record.links().is_empty()
                {
                    return Err(crate::error::Error::Msg(
                        "overwrite requires a raw blob object".into(),
                    )
                    .into());
                }
                crate::verified::patch::aligned(
                    record.payload_size(),
                    offset,
                    replacement.len() as u64,
                )
                .map_err(crate::error::Error::from)?;
                let (actual, proof) = self
                    .repository
                    .payloads
                    .overwrite(
                        &record.payload(),
                        record.payload_size(),
                        offset,
                        replacement,
                    )
                    .await?;
                let expected = crate::verified::patch::verify(
                    &proof,
                    record.payload(),
                    record.payload_size(),
                    offset,
                    replacement,
                )
                .await?
                .digest;
                if actual != expected {
                    return Err(RepositoryError::PayloadIdentityMismatch { expected, actual });
                }
                let verified = BlobFormat::seal_written(
                    actual,
                    record.payload_size(),
                    &self.repository.limits,
                )?;
                Ok(StagedObject {
                    verified,
                    repository: self.repository.staging_identity.clone(),
                    _hold: std::marker::PhantomData,
                })
            })
            .await
    }

    /// Store bytes and verify them under an exact caller-supplied logical key.
    /// The selected namespace still reproduces and checks the native identity,
    /// canonical payload, and forward links before returning a staged seal.
    pub async fn stage_object<'hold>(
        &'hold self,
        key: ObjectKey,
        bytes: &[u8],
    ) -> Result<StagedObject<'hold>, RepositoryError> {
        self.write_scope()
            .run(async {
                let mut reader =
                    BlobPayloadReader::new(std::io::Cursor::new(bytes), bytes.len() as u64);
                #[cfg(all(test, feature = "git"))]
                let timer = crate::git_repository::import_profile::time(5);
                let verified = self
                    .repository
                    .formats
                    .verify(&key, &mut reader, &self.repository.limits)
                    .await?;
                #[cfg(all(test, feature = "git"))]
                drop(timer);
                #[cfg(all(test, feature = "git"))]
                let timer = crate::git_repository::import_profile::time(6);
                let payload = self.repository.payloads.put_slice(bytes).await?;
                #[cfg(all(test, feature = "git"))]
                drop(timer);
                if verified.record().payload() != payload {
                    return Err(RepositoryError::PayloadIdentityMismatch {
                        expected: verified.record().payload(),
                        actual: payload,
                    });
                }
                Ok(StagedObject {
                    verified,
                    repository: self.repository.staging_identity.clone(),
                    _hold: std::marker::PhantomData,
                })
            })
            .await
    }

    /// Stream bytes and verify them under an exact caller-supplied logical key.
    ///
    /// This is the streaming counterpart to [`stage_object`](Self::stage_object):
    /// the payload store computes its physical identity while consuming the
    /// reader, then the selected logical format independently reproduces the
    /// caller-supplied identity and extracts canonical links.
    #[tracing::instrument(name = "repository.stage_object", level = "debug", skip_all)]
    pub async fn stage_object_reader<'hold>(
        &'hold self,
        key: ObjectKey,
        reader: &mut (impl AsyncRead + Unpin),
    ) -> Result<StagedObject<'hold>, RepositoryError> {
        self.write_scope()
            .run(async {
                let mut writer = self.repository.payloads.open_write().await;
                tokio::io::copy(reader, &mut writer).await?;
                let (payload, _) = writer.close().await?;
                self.stage_existing(key, payload).await
            })
            .await
    }

    /// Stream and verify raw bytes as `casita.blob.v1`.
    #[tracing::instrument(name = "repository.stage_blob", level = "debug", skip_all)]
    pub async fn stage_blob_reader<'hold>(
        &'hold self,
        reader: &mut (impl AsyncRead + Unpin),
    ) -> Result<StagedObject<'hold>, RepositoryError> {
        self.write_scope()
            .run(async {
                let mut writer = self.repository.payloads.open_write().await;
                let mut hasher = blake3::Hasher::new();
                let mut observed_size = 0u64;
                let mut buffer = vec![0u8; self.repository.limits.read_buffer_bytes.max(1)];
                loop {
                    let read = reader.read(&mut buffer).await?;
                    if read == 0 {
                        break;
                    }
                    observed_size = observed_size
                        .checked_add(read as u64)
                        .ok_or(FormatError::PayloadSizeOverflow)?;
                    if observed_size > self.repository.limits.max_payload_bytes {
                        return Err(FormatError::PayloadLimit {
                            limit: self.repository.limits.max_payload_bytes,
                        }
                        .into());
                    }
                    hasher.update(&buffer[..read]);
                    writer.write_all(&buffer[..read]).await?;
                }
                let (payload, payload_size) = writer.close().await?;
                let expected = BlobId::new(hasher.finalize().into());
                if payload != expected {
                    return Err(RepositoryError::PayloadIdentityMismatch {
                        expected,
                        actual: payload,
                    });
                }
                if payload_size != observed_size {
                    return Err(RepositoryError::PayloadSizeMismatch {
                        expected: observed_size,
                        actual: payload_size,
                    });
                }
                let verified =
                    BlobFormat::seal_written(payload, payload_size, &self.repository.limits)?;
                Ok(StagedObject {
                    verified,
                    repository: self.repository.staging_identity.clone(),
                    _hold: std::marker::PhantomData,
                })
            })
            .await
    }

    /// Store and verify a canonical filesystem directory as
    /// `casita.directory.v1`.
    #[tracing::instrument(
        name = "repository.stage_directory",
        level = "debug",
        skip_all,
        fields(entries = directory.len())
    )]
    pub async fn stage_directory<'hold>(
        &'hold self,
        directory: &Directory,
    ) -> Result<StagedObject<'hold>, RepositoryError> {
        self.write_scope()
            .run(async {
                let encoded = directory.encode();
                let payload = self.repository.payloads.put_slice(&encoded).await?;
                let verified = DirectoryFormat::seal_written(
                    directory,
                    payload,
                    encoded.len() as u64,
                    &self.repository.limits,
                )?;
                Ok(StagedObject {
                    verified,
                    repository: self.repository.staging_identity.clone(),
                    _hold: std::marker::PhantomData,
                })
            })
            .await
    }

    /// Verify an already durable payload under an exact logical key.
    #[tracing::instrument(name = "repository.stage_existing", level = "debug", skip_all)]
    pub async fn stage_existing<'hold>(
        &'hold self,
        key: ObjectKey,
        payload: BlobId,
    ) -> Result<StagedObject<'hold>, RepositoryError> {
        self.write_scope()
            .run(async {
                self.pin
                    .protect(BTreeSet::from([
                        crate::metadata::PinResource::Object(key.clone()),
                        crate::metadata::PinResource::Blob(payload),
                    ]))
                    .await?;
                let mut reader = self
                    .repository
                    .payloads
                    .open_read(&payload)
                    .await?
                    .ok_or(RepositoryError::MissingPayload(payload))?;
                let exact_len =
                    tokio::io::AsyncSeekExt::seek(&mut reader, std::io::SeekFrom::End(0)).await?;
                tokio::io::AsyncSeekExt::seek(&mut reader, std::io::SeekFrom::Start(0)).await?;
                let mut reader = BlobPayloadReader::new(reader.as_mut(), exact_len);
                let verified = self
                    .repository
                    .formats
                    .verify(&key, &mut reader, &self.repository.limits)
                    .await?;
                if verified.record().payload() != payload {
                    return Err(RepositoryError::PayloadIdentityMismatch {
                        expected: payload,
                        actual: verified.record().payload(),
                    });
                }
                Ok(StagedObject {
                    verified,
                    repository: self.repository.staging_identity.clone(),
                    _hold: std::marker::PhantomData,
                })
            })
            .await
    }

    /// Import an input within this existing mutation lifetime.
    #[cfg(feature = "experimental")]
    pub async fn import<I: crate::Importer<Self>>(&self, input: I) -> Result<I::Report, I::Error> {
        self.write_scope()
            .run(async { input.import(self).await })
            .await
    }

    #[cfg(not(feature = "experimental"))]
    pub(crate) async fn import<I: crate::importer::BackendImporter<Self>>(
        &self,
        input: I,
    ) -> Result<I::Report, I::Error> {
        self.write_scope()
            .run(async { input.import_into(self).await })
            .await
    }

    #[tracing::instrument(
        name = "repository.import_path.walk",
        skip_all,
        fields(recognize = recognize, excluded = excluded.is_some())
    )]
    pub(crate) async fn import_path_inner(
        &self,
        path: impl AsRef<Path>,
        name: Option<RootName>,
        recognize: bool,
        excluded: Option<&Path>,
        file_concurrency: std::num::NonZeroUsize,
    ) -> Result<ObjectKey, RepositoryError> {
        self.write_scope().run(async {

        if self.repository.limits.max_batch_objects == 0 {
            return Err(RepositoryError::LimitExceeded(
                "filesystem import requires a nonzero mutation batch limit".to_owned(),
            ));
        }
        let batch_size = self.repository.limits.max_batch_objects;

        // One handle on the imported tree: discovery and every file read below
        // resolve against it, so a component swapped mid-import cannot redirect
        // a read outside the selected root.
        let root = crate::fs_root::FsRoot::open_read(path.as_ref()).await?;
        let excluded = excluded.map(Path::to_path_buf);
        let file_objects = Arc::new(tokio::sync::Mutex::new(Vec::new()));
        let mut pages = crate::filesystem::walk_bounded_pages_excluding(
            &root,
            |identities: Vec<Option<crate::fs_root::FileIdentity>>| async move {
                if !recognize {
                    return Ok(vec![None; identities.len()]);
                }
                self.recognize_files(identities)
                    .await
                    .map_err(|error| crate::error::Error::Backend(Box::new(error)))
            },
            |path, identity| {
                let file_objects = file_objects.clone();
                let root = &root;
                async move {
                    let (size, executable, object) = stage_filesystem_file(self, root, &path)
                        .await
                        .map_err(|error| crate::error::Error::Backend(Box::new(error)))?;
                    let digest = BlobId::new(
                        object
                            .record()
                            .key()
                            .native_digest()
                            .expect("the blob verifier requires a digest native id"),
                    );
                    file_objects
                        .lock()
                        .await
                        .push((object, identity.map(|identity| (identity, digest))));
                    Ok((size, executable, digest))
                }
            },
            self.repository.limits.max_traversal_objects,
            excluded,
            file_concurrency,
        );

        let mut directories: HashMap<PathBuf, Directory> = HashMap::new();
        // Files and directories share one post-order publication queue. A
        // parent can therefore only be committed in the same or a later batch
        // than every newly staged child it names.
        let mut pending = Vec::new();
        let mut root_key = None;
        while let Some(entries) = pages.try_next().await? {
            pending.extend(std::mem::take(&mut *file_objects.lock().await));
            for entry in entries {
                let (path, node, staged_directory) = match entry {
                    FilesystemEntry::Regular {
                        path,
                        size,
                        executable,
                        digest,
                    } => (
                        path,
                        Node::File {
                            digest,
                            size,
                            executable,
                        },
                        None,
                    ),
                    FilesystemEntry::Symlink { path, target } => (
                        path,
                        Node::Symlink {
                            target: SymlinkTarget::try_from(Bytes::from(target))
                                .map_err(|error| RepositoryError::Payload(error.into()))?,
                        },
                        None,
                    ),
                    FilesystemEntry::Directory { path } => {
                        let directory = directories.remove(&path).unwrap_or_default();
                        let size = directory.size();
                        let digest = directory.digest();
                        let object = self.stage_directory(&directory).await?;
                        (path, Node::Directory { digest, size }, Some(object))
                    }
                };

                let is_root = path.as_os_str().is_empty();
                if let Some(object) = staged_directory {
                    pending.push((object, None));
                }
                if is_root {
                    root_key = match node {
                        Node::Directory { digest, .. } => Some(ObjectKey::directory(digest)),
                        Node::File { .. } => {
                            return Err(RepositoryError::InvalidInput(
                                "filesystem-graph import requires a directory root; ingest a raw file as casita.blob.v1"
                                    .to_owned(),
                            ));
                        }
                        Node::Symlink { .. } => {
                            return Err(RepositoryError::InvalidInput(
                                "a top-level symlink has no standalone v0.1 object identity"
                                    .to_owned(),
                            ));
                        }
                    };
                    continue;
                }

                let parent = path.parent().unwrap_or_else(|| Path::new("")).to_path_buf();
                let name = path.file_name().ok_or_else(|| {
                    RepositoryError::InvalidInput("import entry has no file name".to_owned())
                })?;
                let name = PathComponent::try_from(Bytes::copy_from_slice(
                    crate::fs_names::os_str_bytes(name)?,
                ))
                .map_err(|error| RepositoryError::Payload(error.into()))?;
                directories
                    .entry(parent)
                    .or_default()
                    .add(name, node)
                    .map_err(|error| RepositoryError::Payload(error.into()))?;
            }

            while pending.len() >= batch_size {
                let remainder = pending.split_off(batch_size);
                self.publish_filesystem_checkpoint(pending, Vec::new(), recognize)
                    .await?;
                pending = remainder;
            }
        }

        if let Some(orphan) = directories.keys().next() {
            return Err(RepositoryError::InvalidInput(format!(
                "import entry under {} has no directory entry",
                orphan.display()
            )));
        }
        let root_key = root_key.ok_or_else(|| {
            RepositoryError::InvalidInput("filesystem walk produced no root entry".to_owned())
        })?;
        self.publish_filesystem_checkpoint(
            pending,
            name.map(|name| RootChange::Set { name, target: root_key.clone() }).into_iter().collect(),
            recognize,
        )
        .await?;
        // A filesystem tree is deliberately published in bounded commits so
        // an interrupted import leaves reusable progress. Once the final root
        // is durable, let the state backend fold the resulting transient log
        // back into its compact representation. This is best-effort physical
        // maintenance: the named tree is already committed and remains the
        // successful outcome if another process temporarily prevents it.
        let _ = self.repository.state.compact_transient_state().await;
        tracing::info!(root = %root_key, "filesystem import completed");
        Ok(root_key)

        }).await
    }

    /// Atomically publish staged records and root changes at the current
    /// revision. Expensive closure verification happens against the snapshot
    /// before the short optimistic commit.
    #[tracing::instrument(
        name = "repository.publish",
        skip_all,
        fields(objects = staged.len(), root_changes = root_changes.len())
    )]
    pub async fn publish(
        &self,
        staged: Vec<StagedObject<'_>>,
        root_changes: Vec<RootChange>,
    ) -> Result<CommitResult, RepositoryError> {
        match self
            .publish_inner(staged, Vec::new(), root_changes, None, BTreeSet::new())
            .await?
        {
            ConditionalPublishResult::Committed(result) => Ok(result),
            ConditionalPublishResult::RootMismatch { .. } => {
                unreachable!("an unconditional mutation has no root expectations")
            }
        }
    }

    /// Publish only against one exact repository revision, without automatic
    /// retry. This is the commit boundary for evidence that cites the state it
    /// read: a concurrent writer returns `StaleRevision` so the caller can
    /// rebuild the derived result from a matching snapshot.
    #[tracing::instrument(
        name = "repository.publish",
        skip_all,
        fields(objects = staged.len(), root_changes = root_changes.len(), exact_revision = true)
    )]
    pub async fn publish_at_revision(
        &self,
        expected: crate::RepositoryRevision,
        staged: Vec<StagedObject<'_>>,
        root_changes: Vec<RootChange>,
    ) -> Result<CommitResult, RepositoryError> {
        match self
            .publish_inner(
                staged,
                Vec::new(),
                root_changes,
                Some(expected),
                BTreeSet::new(),
            )
            .await?
        {
            ConditionalPublishResult::Committed(result) => Ok(result),
            ConditionalPublishResult::RootMismatch { .. } => {
                unreachable!("an exact-revision mutation has no root expectations")
            }
        }
    }

    /// Atomically publish only while each named root still has its expected
    /// value.
    ///
    /// A stale repository revision caused by an unrelated mutation retries
    /// against a fresh snapshot. If an expected root differs, nothing is
    /// committed and [`ConditionalPublishResult::RootMismatch`] reports the
    /// first mismatch in canonical root-name order. Payloads already written
    /// while staging remain safe collectible residue.
    #[tracing::instrument(
        name = "repository.publish",
        skip_all,
        fields(
            objects = staged.len(),
            root_expectations = expectations.len(),
            root_changes = root_changes.len(),
            conditional = true
        )
    )]
    pub async fn publish_if_roots_match(
        &self,
        staged: Vec<StagedObject<'_>>,
        expectations: Vec<RootExpectation>,
        root_changes: Vec<RootChange>,
    ) -> Result<ConditionalPublishResult, RepositoryError> {
        self.publish_inner(staged, expectations, root_changes, None, BTreeSet::new())
            .await
    }

    /// Publish one batch whose complete filesystem closures were established
    /// while the importer constructed them bottom-up.
    ///
    /// This is deliberately private and namespace-restricted. A generic
    /// [`StagedObject`] proves its own payload and links, but arbitrary formats
    /// may still have relational rules in `verify_links`; only the filesystem
    /// importer has the file sizes, child-directory sizes, and post-order
    /// construction evidence needed to prove those rules without rereading.
    async fn publish_filesystem_constructed(
        &self,
        staged: Vec<StagedObject<'_>>,
        root_changes: Vec<RootChange>,
    ) -> Result<CommitResult, RepositoryError> {
        let mut constructed = BTreeSet::new();
        for object in &staged {
            let key = object.record().key();
            if !matches!(
                key.namespace().as_str(),
                crate::BLOB_NAMESPACE | crate::DIRECTORY_NAMESPACE
            ) {
                return Err(RepositoryError::InvalidInput(format!(
                    "filesystem construction proof cannot cover {key}"
                )));
            }
            constructed.insert(key.clone());
        }
        match self
            .publish_inner(staged, Vec::new(), root_changes, None, constructed)
            .await?
        {
            ConditionalPublishResult::Committed(result) => Ok(result),
            ConditionalPublishResult::RootMismatch { .. } => {
                unreachable!("a filesystem import has no root expectations")
            }
        }
    }

    /// Publish a native Git view whose complete closure the importer just
    /// traversed, verified, and durably checkpointed in bounded batches.
    ///
    /// This is crate-private and namespace-restricted because an arbitrary
    /// staged object proves only itself, not its whole closure. The native Git
    /// importer supplies the stronger construction proof: it starts from the
    /// exact selected refs and follows every verified canonical link until the
    /// queue is empty before calling this method.
    #[cfg(feature = "git")]
    pub(crate) async fn publish_git_constructed(
        &self,
        view: StagedObject<'_>,
        name: RootName,
        target: ObjectKey,
    ) -> Result<CommitResult, RepositoryError> {
        if target.namespace().as_str() != crate::GIT_VIEW_NAMESPACE
            || view.record().key() != &target
            || !name.as_str().starts_with("git/")
        {
            return Err(RepositoryError::InvalidInput(
                "constructed Git publication requires one matching git.view.v1 object and git/* root"
                    .to_owned(),
            ));
        }
        match self
            .publish_inner(
                vec![view],
                Vec::new(),
                vec![RootChange::Set {
                    name,
                    target: target.clone(),
                }],
                None,
                BTreeSet::from([target]),
            )
            .await?
        {
            ConditionalPublishResult::Committed(result) => Ok(result),
            ConditionalPublishResult::RootMismatch { .. } => {
                unreachable!("a constructed Git publication has no root expectations")
            }
        }
    }

    /// Commit one bounded post-order import checkpoint, then make its file
    /// identities reusable. Remembering happens after the logical commit: a
    /// crash can lose an accelerator entry, but can never make a later import
    /// trust payload bytes whose object record was not made durable.
    async fn publish_filesystem_checkpoint(
        &self,
        staged: Vec<(
            StagedObject<'_>,
            Option<(crate::fs_root::FileIdentity, BlobId)>,
        )>,
        root_changes: Vec<RootChange>,
        remember: bool,
    ) -> Result<CommitResult, RepositoryError> {
        let mut objects = Vec::with_capacity(staged.len());
        let mut learned = Vec::new();
        for (object, identity) in staged {
            objects.push(object);
            learned.extend(identity);
        }
        let result = self
            .publish_filesystem_constructed(objects, root_changes)
            .await?;
        if let Some(cache) = self.repository.ingest_cache.as_ref().filter(|_| remember)
            && !learned.is_empty()
        {
            cache.remember(&learned).await?;
        }
        Ok(result)
    }

    /// Atomically publish verified content, application records, and roots.
    /// Opaque record bytes never imply object links or GC protection.
    pub async fn publish_with_metadata(
        &self,
        staged: Vec<StagedObject<'_>>,
        checks: Vec<crate::MetadataCheck>,
        changes: Vec<crate::MetadataChange>,
    ) -> Result<CommitResult, RepositoryError> {
        if !self.repository.state.supports_metadata_records() {
            return Err(MetadataError::UnsupportedMetadata.into());
        }
        let mut mutation = MetadataMutation::with_metadata(checks, changes)?;
        let roots = mutation.take_root_changes();
        match self
            .publish_inner_with_metadata(
                staged,
                Vec::new(),
                roots,
                None,
                BTreeSet::new(),
                Some(mutation),
            )
            .await?
        {
            ConditionalPublishResult::Committed(result) => Ok(result),
            ConditionalPublishResult::RootMismatch { .. } => {
                unreachable!("checks are evaluated by the metadata transaction")
            }
        }
    }

    async fn publish_inner(
        &self,
        staged: Vec<StagedObject<'_>>,
        expectations: Vec<RootExpectation>,
        root_changes: Vec<RootChange>,
        exact_revision: Option<crate::RepositoryRevision>,
        constructed_closures: BTreeSet<ObjectKey>,
    ) -> Result<ConditionalPublishResult, RepositoryError> {
        self.publish_inner_with_metadata(
            staged,
            expectations,
            root_changes,
            exact_revision,
            constructed_closures,
            None,
        )
        .await
    }

    #[tracing::instrument(
        name = "repository.publish.commit",
        skip_all,
        fields(
            objects = staged.len(),
            root_expectations = expectations.len(),
            root_changes = root_changes.len(),
            exact_revision = exact_revision.is_some(),
            constructed_closures = constructed_closures.len()
        )
    )]
    async fn publish_inner_with_metadata(
        &self,
        staged: Vec<StagedObject<'_>>,
        expectations: Vec<RootExpectation>,
        root_changes: Vec<RootChange>,
        exact_revision: Option<crate::RepositoryRevision>,
        constructed_closures: BTreeSet<ObjectKey>,
        metadata: Option<MetadataMutation>,
    ) -> Result<ConditionalPublishResult, RepositoryError> {
        self.write_scope()
            .run(async {
                if staged.len() > self.repository.limits.max_batch_objects {
                    return Err(RepositoryError::LimitExceeded(format!(
                        "mutation has {} objects, limit is {}",
                        staged.len(),
                        self.repository.limits.max_batch_objects
                    )));
                }
                if root_changes.len() > self.repository.limits.max_root_changes {
                    return Err(RepositoryError::LimitExceeded(format!(
                        "mutation has {} root changes, limit is {}",
                        root_changes.len(),
                        self.repository.limits.max_root_changes
                    )));
                }
                if expectations.len() > self.repository.limits.max_root_changes {
                    return Err(RepositoryError::LimitExceeded(format!(
                        "mutation has {} root expectations, limit is {}",
                        expectations.len(),
                        self.repository.limits.max_root_changes
                    )));
                }
                let mut expectations_by_name = BTreeMap::new();
                for expectation in expectations {
                    let name = expectation.name.clone();
                    if expectations_by_name
                        .insert(name.clone(), expectation)
                        .is_some()
                    {
                        return Err(RepositoryError::InvalidInput(format!(
                            "mutation has duplicate root expectation for {name}"
                        )));
                    }
                }
                let mut overlay = BTreeMap::new();
                for object in &staged {
                    let record = object.record();
                    if !Arc::ptr_eq(&object.repository, &self.repository.staging_identity) {
                        return Err(RepositoryError::ForeignStagedObject(record.key().clone()));
                    }
                    match overlay.get(record.key()) {
                        Some(existing) if existing == record => {}
                        Some(_) => {
                            return Err(RepositoryError::StagedConflict(record.key().clone()));
                        }
                        None => {
                            overlay.insert(record.key().clone(), record.clone());
                        }
                    }
                }
                let verified: Vec<_> = staged
                    .iter()
                    .map(|object| object.verified.clone())
                    .collect();
                let mut inputs = BTreeSet::new();
                for record in overlay.values() {
                    inputs.insert(crate::metadata::PinResource::Object(record.key().clone()));
                    inputs.extend(
                        record
                            .links()
                            .iter()
                            .cloned()
                            .map(crate::metadata::PinResource::Object),
                    );
                }
                for change in &root_changes {
                    if let RootChange::Set { target, .. } = change {
                        inputs.insert(crate::metadata::PinResource::Object(target.clone()));
                    }
                }
                self.pin.protect(inputs).await?;
                #[cfg(test)]
                let phase = self.repository.time_publication_phase(0);
                let mut state_commit = self.repository.publication.lock().await;
                #[cfg(test)]
                drop(phase);

                loop {
                    #[cfg(test)]
                    let phase = self.repository.time_publication_phase(1);
                    let (snapshot, _snapshot_pin) = self.pinned_snapshot().await?;
                    #[cfg(test)]
                    drop(phase);
                    #[cfg(test)]
                    let phase = self.repository.time_publication_phase(2);
                    if let Some(expected) = exact_revision
                        && snapshot.revision() != expected
                    {
                        return Err(MetadataError::StaleRevision {
                            expected,
                            actual: snapshot.revision(),
                        }
                        .into());
                    }
                    for expectation in expectations_by_name.values() {
                        let actual = snapshot.root(&expectation.name).await?;
                        if actual != expectation.target {
                            return Ok(ConditionalPublishResult::RootMismatch {
                                name: expectation.name.clone(),
                                expected: expectation.target.clone(),
                                actual,
                            });
                        }
                    }
                    let mut newly_verified: Vec<_> = constructed_closures.iter().cloned().collect();
                    for change in &root_changes {
                        if let RootChange::Set { target, .. } = change {
                            if constructed_closures.contains(target) {
                                // The target record is part of this exact overlay, and
                                // the private caller established its complete closure
                                // while constructing the filesystem graph bottom-up.
                                debug_assert!(overlay.contains_key(target));
                                continue;
                            }
                            let status = verify_closure_with(
                                self.repository.closure_verifier(),
                                snapshot.as_ref(),
                                &overlay,
                                target,
                                None,
                                ClosureAudit::Incremental,
                                Some(&mut newly_verified),
                            )
                            .await?;
                            if !matches!(status, ClosureStatus::Complete { .. }) {
                                return Err(RepositoryError::RootNotPublishable {
                                    root: target.clone(),
                                    status,
                                });
                            }
                        }
                    }

                    let mut mutation = metadata.clone().unwrap_or_default();
                    mutation.add_objects(verified.iter().cloned());
                    // Recorded in the same transaction that publishes them, so a
                    // shortcut can never outlive the objects it vouches for.
                    mutation.mark_validated_closures(newly_verified);
                    for change in &root_changes {
                        match change {
                            RootChange::Set { name, target } => {
                                mutation.set_root(name.clone(), target.clone());
                            }
                            RootChange::Remove { name } => {
                                mutation.remove_root(name.clone());
                            }
                        }
                    }
                    // Release the metadata connection before committing, but move
                    // its catalog pin into the cancellation-safe publication task.
                    // The task keeps it until its storage work has settled.
                    let expected_revision = snapshot.revision();
                    drop(snapshot);
                    let protection = Arc::new((self.protection.clone(), _snapshot_pin));
                    #[cfg(test)]
                    drop(phase);
                    let (guard, committed) = if staged.is_empty() && metadata.is_some() {
                        self.repository
                            .publication
                            .commit_existing(
                                state_commit.take(),
                                protection,
                                expected_revision,
                                mutation,
                            )
                            .await
                    } else {
                        self.repository
                            .publication
                            .commit(
                                state_commit.take(),
                                protection,
                                expected_revision,
                                Some(mutation),
                                #[cfg(test)]
                                self.repository.publication_profile.clone(),
                            )
                            .await
                    };
                    state_commit = guard;
                    let committed = committed
                        .map(|commit| commit.expect("logical publication always commits metadata"));
                    match committed {
                        Ok(result) => {
                            tracing::info!(
                                revision = %result.revision,
                                objects_inserted = result.objects_inserted,
                                roots_changed = result.roots_changed,
                                "repository publication committed"
                            );
                            return Ok(ConditionalPublishResult::Committed(result));
                        }
                        Err(
                            error @ RepositoryError::Metadata(MetadataError::StaleRevision {
                                ..
                            }),
                        ) if exact_revision.is_some() => {
                            return Err(error);
                        }
                        Err(RepositoryError::Metadata(MetadataError::StaleRevision { .. })) => {
                            tracing::debug!(
                                "repository publication raced a newer revision; retrying"
                            );
                            continue;
                        }
                        Err(error) => return Err(error),
                    }
                }
            })
            .await
    }

    /// Publish staged records without naming them. They remain collectible and
    /// can complete a graph published in later bounded batches.
    pub async fn publish_unrooted(
        &self,
        staged: Vec<StagedObject<'_>>,
    ) -> Result<CommitResult, RepositoryError> {
        self.publish(staged, Vec::new()).await
    }

    /// Atomically publish records and set one exact named root.
    pub async fn publish_rooted(
        &self,
        staged: Vec<StagedObject<'_>>,
        name: RootName,
        target: ObjectKey,
    ) -> Result<CommitResult, RepositoryError> {
        self.publish(staged, vec![RootChange::Set { name, target }])
            .await
    }

    /// Remove a named root only while it still resolves to the exact target
    /// recorded by the caller.
    ///
    /// A concurrent state change retries the comparison against a fresh
    /// snapshot. `None` means the name was absent or had been repointed.
    pub async fn remove_root_if_matches(
        &self,
        name: &RootName,
        expected: &ObjectKey,
    ) -> Result<Option<CommitResult>, RepositoryError> {
        loop {
            let (snapshot, _snapshot_pin) = self.pinned_snapshot().await?;
            if snapshot.root(name).await?.as_ref() != Some(expected) {
                return Ok(None);
            }
            let mut mutation = MetadataMutation::new();
            mutation.remove_root(name.clone());
            match self
                .repository
                .state
                .commit(&snapshot.revision(), mutation)
                .await
            {
                Ok(result) => return Ok(Some(result)),
                Err(MetadataError::StaleRevision { .. }) => continue,
                Err(error) => return Err(error.into()),
            }
        }
    }
}

impl<PS, SS> MutationSession<'_, PS, SS>
where
    PS: BlobStore,
    SS: MetadataStore,
{
    /// Which of these files the repository already holds the content of.
    ///
    /// A file is recognized only when an earlier import recorded its exact
    /// device, inode, size and timestamps, and the object recorded for it is
    /// still committed. Collection can have removed that object since, so the
    /// recorded digests are confirmed against state before any of them is
    /// trusted; this session's retention hold then keeps them alive.
    async fn recognize_files(
        &self,
        identities: Vec<Option<crate::fs_root::FileIdentity>>,
    ) -> Result<Vec<Option<(u64, BlobId)>>, RepositoryError> {
        let mut answers = vec![None; identities.len()];
        let Some(cache) = &self.repository.ingest_cache else {
            return Ok(answers);
        };

        let known: Vec<_> = identities
            .iter()
            .enumerate()
            .filter_map(|(at, identity)| identity.map(|identity| (at, identity)))
            .collect();
        let recalled = cache
            .recall(&known.iter().map(|(_, id)| *id).collect::<Vec<_>>())
            .await?;

        let candidates: Vec<_> = known
            .iter()
            .zip(recalled)
            .filter_map(|((at, _), digest)| digest.map(|digest| (*at, digest)))
            .collect();
        let keys: Vec<_> = candidates
            .iter()
            .map(|(_, digest)| ObjectKey::blob(*digest))
            .collect();
        self.pin
            .protect(
                keys.iter()
                    .cloned()
                    .map(crate::metadata::PinResource::Object)
                    .collect(),
            )
            .await?;
        let (snapshot, _snapshot_pin) = self.pinned_snapshot().await?;
        for ((at, digest), payload) in candidates
            .into_iter()
            .zip(snapshot.validated_payload_batch(&keys).await?)
        {
            if let Some((payload, size)) = payload
                && payload == digest
            {
                answers[at] = Some((size, digest));
            }
        }
        Ok(answers)
    }
}

async fn stage_filesystem_file<'hold, PS, SS>(
    mutation: &'hold MutationSession<'_, PS, SS>,
    root: &crate::fs_root::FsRoot,
    path: &Path,
) -> Result<(u64, bool, StagedObject<'hold>), RepositoryError>
where
    PS: BlobStore,
    SS: MetadataStore,
{
    let (file, metadata) = root.open_file(path).await?;
    let executable = crate::filesystem::is_executable(&metadata);
    // Most trees are mostly small files, and a fixed read buffer would allocate
    // orders of magnitude more than each one needs. The cap still applies; only
    // the floor moves.
    let capacity = usize::try_from(metadata.len())
        .unwrap_or(crate::filesystem::FILE_READ_BUFFER_SIZE)
        .clamp(1, crate::filesystem::FILE_READ_BUFFER_SIZE);
    let mut file = tokio::io::BufReader::with_capacity(capacity, file);
    let object = mutation.stage_blob_reader(&mut file).await?;
    Ok((object.record().payload_size(), executable, object))
}

/// What one closure verification needs from its repository.
struct ClosureVerifier<'a, PS> {
    payloads: &'a PS,
    formats: &'a FormatRegistry,
    limits: &'a FormatLimits,
    area: SpillArea,
}

/// Verify one closure, optionally recording every verified key in `union`.
///
/// The visited set and work queue spill to local storage past their memory
/// budget, so the largest verifiable graph is bounded by the traversal limits
/// rather than by process memory. Visit order, and therefore the exact
/// [`ClosureStatus`] reported for a broken graph, is the same either way.
async fn verify_closure_against<PS: BlobStore>(
    verifier: ClosureVerifier<'_, PS>,
    snapshot: &dyn MetadataSnapshot,
    overlay: &BTreeMap<ObjectKey, ObjectRecord>,
    root: &ObjectKey,
    union: Option<&mut SpillSet<ObjectKey>>,
) -> Result<ClosureStatus, RepositoryError> {
    verify_closure_with(
        verifier,
        snapshot,
        overlay,
        root,
        union,
        ClosureAudit::Exhaustive,
        None,
    )
    .await
}

/// How much of a closure a verification re-reads.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ClosureAudit {
    /// Read and re-verify every reachable object.
    ///
    /// This is what `fsck` owes its caller: only reading the bytes back can
    /// find storage that decayed under a graph that is still well formed.
    Exhaustive,
    /// Stop at objects whose closure the repository already verified.
    ///
    /// Records are immutable and only collection removes them, so a verified
    /// closure stays verified and re-reading it proves nothing new. This is
    /// what a precondition check wants: mutation, checkout and transfer ask
    /// "is this graph complete", not "has storage decayed".
    Incremental,
}

/// Verify one closure, cutting the walk short where the audit allows.
///
/// `newly_verified` collects the keys this walk proved, which is what a caller
/// records so a later incremental walk can stop at them.
async fn verify_closure_with<PS: BlobStore>(
    verifier: ClosureVerifier<'_, PS>,
    snapshot: &dyn MetadataSnapshot,
    overlay: &BTreeMap<ObjectKey, ObjectRecord>,
    root: &ObjectKey,
    mut union: Option<&mut SpillSet<ObjectKey>>,
    audit: ClosureAudit,
    mut newly_verified: Option<&mut Vec<ObjectKey>>,
) -> Result<ClosureStatus, RepositoryError> {
    let ClosureVerifier {
        payloads,
        formats,
        limits,
        area,
    } = verifier;
    // An incremental walk stops at verified objects, so it cannot also produce
    // the complete union a transfer or archive plan needs.
    debug_assert!(
        !(matches!(audit, ClosureAudit::Incremental) && union.is_some()),
        "an incremental closure walk cannot collect a complete union"
    );
    let mut reachable = SpillSet::new(area.clone(), "closure");
    let mut queue = TraversalQueue::new(area.clone());
    queue.push((None, root.clone())).await?;
    loop {
        // Resolve a whole frontier per state call. Asking for one record at a
        // time cost a blocking-task handoff and a connection lock per object,
        // which dominated the walk; the queue is breadth-first, so draining a
        // prefix of it visits exactly the same objects in exactly the same
        // order as popping one at a time.
        let mut frontier = Vec::new();
        while frontier.len() < CLOSURE_FRONTIER {
            let Some(step) = queue.pop().await? else {
                break;
            };
            frontier.push(step);
        }
        if frontier.is_empty() {
            break;
        }
        let keys: Vec<_> = frontier.iter().map(|(_, key)| key.clone()).collect();
        // An already-verified object stands in for everything beneath it, so
        // the walk neither reads it nor descends into it.
        let settled = match audit {
            ClosureAudit::Exhaustive => vec![false; keys.len()],
            ClosureAudit::Incremental => snapshot.validated_closures(&keys).await?,
        };
        let found = overlay_records(snapshot, overlay, &keys).await?;

        for (((from, key), record), settled) in frontier.into_iter().zip(found).zip(settled) {
            if !reachable.insert(key.clone()).await? {
                continue;
            }
            if reachable.len() > limits.max_traversal_objects {
                return Err(RepositoryError::LimitExceeded(format!(
                    "closure traversal exceeded {} objects",
                    limits.max_traversal_objects
                )));
            }
            if let Some(union) = union.as_deref_mut() {
                union.insert(key.clone()).await?;
            }
            let Some(record) = record else {
                return Ok(ClosureStatus::Missing { from, missing: key });
            };
            // Only after the record is known to be present: collection prunes
            // these marks with the objects they vouch for, and a walk that
            // trusted a mark without looking would be unable to notice if one
            // ever outlived its object.
            if settled {
                continue;
            }
            let Some(format) = formats.get(key.namespace()) else {
                return Ok(ClosureStatus::Unsupported { object: key });
            };
            let Some(mut payload) = payloads.open_read(&record.payload()).await? else {
                return Ok(ClosureStatus::Invalid {
                    object: key,
                    reason: format!("physical payload {} is absent", record.payload()),
                });
            };
            let mut payload = BlobPayloadReader::new(payload.as_mut(), record.payload_size());

            let targets: Vec<_> = record.links().to_vec();
            for (target, found) in targets
                .iter()
                .zip(overlay_records(snapshot, overlay, &targets).await?)
            {
                if found.is_none() {
                    return Ok(ClosureStatus::Missing {
                        from: Some(key.clone()),
                        missing: target.clone(),
                    });
                }
            }

            let direct_links: BTreeSet<_> = record.links().iter().cloned().collect();
            let view = RepositoryDirectLinkView {
                payloads,
                snapshot,
                overlay,
                cached: None,
                allowed: &direct_links,
            };
            if let Err(error) = format
                .verify_links(
                    VerificationContext::new(&key, &mut payload),
                    &record,
                    &view,
                    limits,
                )
                .await
            {
                return Ok(ClosureStatus::Invalid {
                    object: key,
                    reason: error.to_string(),
                });
            }
            for target in record.links() {
                queue
                    .push((Some(record.key().clone()), target.clone()))
                    .await?;
            }
            if let Some(newly_verified) = newly_verified.as_deref_mut() {
                newly_verified.push(key);
            }
        }
    }
    Ok(ClosureStatus::Complete {
        objects: reachable.len(),
    })
}

/// Mark everything reachable from every named root.
///
/// The marked set spills like any other traversal, so collection on a
/// repository larger than memory is bounded by the traversal limits rather
/// than by the size of the live graph.
async fn mark_named_roots(
    snapshot: &dyn MetadataSnapshot,
    max_objects: usize,
    area: &SpillArea,
) -> Result<SpillSet<ObjectKey>, RepositoryError> {
    let mut marked = SpillSet::new(area.clone(), "marked");
    let mut queue = TraversalQueue::new(area.clone());
    let mut roots = snapshot.roots();
    while let Some(root) = roots.next().await {
        let root = root?;
        queue.push((None, root.target().clone())).await?;
    }
    drop(roots);
    loop {
        // Resolved a frontier at a time for the same reason the closure walk
        // is: the mark pass reads every live record, and a per-record state
        // call costs far more than the record.
        let mut frontier = Vec::new();
        while frontier.len() < CLOSURE_FRONTIER {
            let Some(step) = queue.pop().await? else {
                break;
            };
            frontier.push(step);
        }
        if frontier.is_empty() {
            break;
        }
        let keys: Vec<_> = frontier.iter().map(|(_, key)| key.clone()).collect();
        let found = snapshot.object_batch(&keys).await?;

        for ((from, key), record) in frontier.into_iter().zip(found) {
            if !marked.insert(key.clone()).await? {
                continue;
            }
            if marked.len() > max_objects {
                return Err(RepositoryError::LimitExceeded(format!(
                    "collection mark exceeded {max_objects} objects"
                )));
            }
            let record = record.ok_or_else(|| {
                MetadataError::Corruption(match from {
                    Some(from) => format!("rooted object {from} links to missing {key}"),
                    None => format!("named root targets missing object {key}"),
                })
            })?;
            for target in record.links() {
                queue.push((Some(key.clone()), target.clone())).await?;
            }
        }
    }
    Ok(marked)
}

/// Extend the strict named-root mark with live operation scopes. A writer can
/// pin an input before its record exists, and an unrestricted snapshot can
/// contain incomplete unrooted records, so these scopes tolerate absent links.
async fn mark_pin_scopes(
    snapshot: &dyn MetadataSnapshot,
    pins: &crate::metadata::PinInventory,
    marked: &mut SpillSet<ObjectKey>,
    max_objects: usize,
    area: &SpillArea,
) -> Result<(), RepositoryError> {
    use crate::metadata::{PinResource, PinScope};

    let mut queue = TraversalQueue::new(area.clone());
    if let Some(generation) = pins
        .pins
        .values()
        .filter_map(|pin| match pin.scope {
            PinScope::Snapshot { generation } => Some(generation),
            _ => None,
        })
        .max()
    {
        let mut records = snapshot.objects_created_through(generation);
        while let Some(record) = records.next().await {
            let record = record?;
            if marked.insert(record.key().clone()).await? {
                // An old incomplete object can gain a committed dependency
                // later. Retain that dependency to keep the current graph valid.
                for target in record.links() {
                    queue.push((None, target.clone())).await?;
                }
            }
            if marked.len() > max_objects {
                return Err(RepositoryError::LimitExceeded(format!(
                    "collection mark exceeded {max_objects} objects"
                )));
            }
        }
    }

    for pin in pins.pins.values() {
        if let PinScope::Closures(roots) = &pin.scope {
            for root in roots {
                queue.push((None, root.clone())).await?;
            }
        }
        for resource in &pin.resources {
            if let PinResource::Object(key) = resource {
                queue.push((None, key.clone())).await?;
            }
        }
    }
    loop {
        let mut keys = Vec::new();
        while keys.len() < CLOSURE_FRONTIER {
            let Some((_, key)) = queue.pop().await? else {
                break;
            };
            keys.push(key);
        }
        if keys.is_empty() {
            return Ok(());
        }
        let records = snapshot.object_batch(&keys).await?;
        for (key, record) in keys.into_iter().zip(records) {
            let Some(record) = record else { continue };
            if !marked.insert(key).await? {
                continue;
            }
            if marked.len() > max_objects {
                return Err(RepositoryError::LimitExceeded(format!(
                    "collection mark exceeded {max_objects} objects"
                )));
            }
            for target in record.links() {
                queue.push((None, target.clone())).await?;
            }
        }
    }
}

async fn overlay_record(
    snapshot: &dyn MetadataSnapshot,
    overlay: &BTreeMap<ObjectKey, ObjectRecord>,
    key: &ObjectKey,
) -> Result<Option<ObjectRecord>, MetadataError> {
    match overlay.get(key) {
        Some(record) => Ok(Some(record.clone())),
        None => snapshot.object(key).await,
    }
}

/// Resolve many keys at once, answered in input order.
///
/// Staged records still win over committed ones; only the keys the overlay
/// cannot answer reach the state backend, and they reach it in one call.
async fn overlay_records(
    snapshot: &dyn MetadataSnapshot,
    overlay: &BTreeMap<ObjectKey, ObjectRecord>,
    keys: &[ObjectKey],
) -> Result<Vec<Option<ObjectRecord>>, MetadataError> {
    let mut wanted = Vec::new();
    for key in keys {
        if !overlay.contains_key(key) {
            wanted.push(key.clone());
        }
    }
    let mut committed = snapshot.object_batch(&wanted).await?.into_iter();
    let mut resolved = Vec::with_capacity(keys.len());
    for key in keys {
        resolved.push(match overlay.get(key) {
            Some(record) => Some(record.clone()),
            None => committed.next().flatten(),
        });
    }
    Ok(resolved)
}

struct RepositoryDirectLinkView<'a, PS> {
    payloads: &'a PS,
    snapshot: &'a dyn MetadataSnapshot,
    overlay: &'a BTreeMap<ObjectKey, ObjectRecord>,
    cached: Option<&'a HashMap<ObjectKey, ObjectRecord>>,
    allowed: &'a BTreeSet<ObjectKey>,
}

#[async_trait]
impl<PS: BlobStore> DirectLinkView for RepositoryDirectLinkView<'_, PS> {
    async fn record(&self, key: &ObjectKey) -> Result<Option<ObjectRecord>, FormatError> {
        if !self.allowed.contains(key) {
            return Ok(None);
        }
        if let Some(record) = self.overlay.get(key) {
            return Ok(Some(record.clone()));
        }
        if let Some(cached) = self.cached {
            return Ok(cached.get(key).cloned());
        }
        overlay_record(self.snapshot, self.overlay, key)
            .await
            .map_err(|error| FormatError::InvalidDirectLink {
                object: key.clone(),
                target: key.clone(),
                message: error.to_string(),
            })
    }

    async fn open_payload(
        &self,
        key: &ObjectKey,
    ) -> Result<Option<Box<dyn PayloadReader>>, FormatError> {
        let Some(record) = self.record(key).await? else {
            return Ok(None);
        };
        let reader = self
            .payloads
            .open_read(&record.payload())
            .await
            .map_err(|error| FormatError::InvalidDirectLink {
                object: key.clone(),
                target: key.clone(),
                message: error.to_string(),
            })?;
        Ok(reader.map(|reader| {
            Box::new(BlobPayloadReader::new(reader, record.payload_size()))
                as Box<dyn PayloadReader>
        }))
    }
}

struct BlobPayloadReader<R> {
    inner: R,
    exact_len: u64,
}

impl<R> BlobPayloadReader<R> {
    fn new(inner: R, exact_len: u64) -> Self {
        Self { inner, exact_len }
    }
}

#[async_trait]
impl<R> PayloadReader for BlobPayloadReader<R>
where
    R: AsyncRead + Unpin + Send,
{
    fn exact_len(&self) -> Option<u64> {
        Some(self.exact_len)
    }

    async fn read(&mut self, buffer: &mut [u8]) -> std::io::Result<usize> {
        tokio::io::AsyncReadExt::read(&mut self.inner, buffer).await
    }
}

struct RepositoryDirectoryView<'a, PS> {
    payloads: &'a PS,
    snapshot: &'a dyn MetadataSnapshot,
}

#[async_trait]
impl<PS: BlobStore> DirectorySource for RepositoryDirectoryView<'_, PS> {
    async fn get(&self, digest: &DirectoryId) -> Result<Option<Directory>, crate::error::Error> {
        let key = ObjectKey::directory(*digest);
        let Some(record) = self
            .snapshot
            .object(&key)
            .await
            .map_err(|error| crate::error::Error::Backend(Box::new(error)))?
        else {
            return Ok(None);
        };
        let mut reader = self
            .payloads
            .open_read(&record.payload())
            .await?
            .ok_or_else(|| {
                crate::error::Error::Backend(Box::new(MetadataError::Corruption(format!(
                    "directory {key} has no physical payload {}",
                    record.payload()
                ))))
            })?;
        let mut encoded = Vec::new();
        tokio::io::AsyncReadExt::read_to_end(&mut reader, &mut encoded).await?;
        let directory = Directory::decode(&encoded)?;
        if directory.digest() != *digest || record.payload() != BlobId::new(Digest::hash(&encoded))
        {
            return Err(crate::error::Error::Backend(Box::new(
                MetadataError::Corruption(format!(
                    "directory payload for {key} does not match its record"
                )),
            )));
        }
        Ok(Some(directory))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn remote_vacuum_preserves_ready_unpublished_catalog_rebase() {
        use crate::object_store::{ObjectStore, ObjectStoreExt, memory::InMemory, path::Path};

        async fn open_payloads(objects: Arc<dyn ObjectStore>, catalog: &[u8]) -> ChunkedBlobStore {
            ChunkedBlobStore::new_packed_with_state_catalog(
                objects,
                Path::from("ready-rebase"),
                1024,
                u64::MAX,
                0,
                2,
                catalog,
            )
            .await
            .unwrap()
        }

        let directory = tempfile::tempdir().unwrap();
        let state = crate::TursoMetadataStore::open(directory.path().join("state.db"))
            .await
            .unwrap();
        let objects: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
        let empty = ChunkedBlobStore::empty_state_catalog().unwrap();
        // Use the remote packed profile, with no filesystem coordination or
        // local durability. SQLite only supplies the atomic metadata commits.
        let writer = Repository::new(open_payloads(objects.clone(), &empty).await, state.clone());
        let pause = writer.pause_catalog_maintenance_for_test();
        let mut keys = Vec::new();
        for name in ["first", "second"] {
            let session = writer.mutation_session().await.unwrap();
            let object = session.stage_blob(name.as_bytes()).await.unwrap();
            let key = object.record().key().clone();
            session
                .publish_rooted(vec![object], RootName::try_from(name).unwrap(), key.clone())
                .await
                .unwrap();
            keys.push(key);
            drop(session);
            writer
                .payloads()
                .set_pack_catalog_rebase_run_bytes_for_test(1);
        }
        pause.reached.notified().await;
        let catalog = state
            .snapshot()
            .await
            .unwrap()
            .payload_catalog()
            .unwrap()
            .to_vec();
        let collector = Repository::new(
            open_payloads(objects.clone(), &catalog).await,
            state.clone(),
        );
        // The completed candidate is absent from this handle's committed root.
        // Its writer pin must preserve it while unrelated metadata is vacuumed.
        collector.try_vacuum().await.unwrap();
        let drain = crate::flush_repository_leases();
        tokio::pin!(drain);
        assert!(futures::poll!(&mut drain).is_pending());
        pause.resume.notify_one();
        drain.await.unwrap();
        assert_ne!(
            state.snapshot().await.unwrap().payload_catalog().unwrap(),
            catalog
        );
        let orphan = crate::object_store::path::Path::from(format!(
            "ready-rebase/pack-indexes/b3/{}",
            blake3::hash(b"orphan catalog").to_hex()
        ));
        objects
            .put(&orphan, Bytes::from_static(b"orphan catalog").into())
            .await
            .unwrap();
        collector.vacuum().await.unwrap();
        assert!(matches!(
            objects.head(&orphan).await,
            Err(crate::object_store::Error::NotFound { .. })
        ));

        let session = writer.mutation_session().await.unwrap();
        let object = session.stage_blob(b"third").await.unwrap();
        let key = object.record().key().clone();
        session
            .publish_rooted(
                vec![object],
                RootName::try_from("third").unwrap(),
                key.clone(),
            )
            .await
            .unwrap();
        keys.push(key);
        drop(session);
        let catalog = state
            .snapshot()
            .await
            .unwrap()
            .payload_catalog()
            .unwrap()
            .to_vec();
        let reopened = Repository::new(open_payloads(objects, &catalog).await, state);
        let hold = reopened.retention_hold().await.unwrap();
        for (key, expected) in keys.into_iter().zip(["first", "second", "third"]) {
            let (_, mut reader) = hold.open_payload(&key).await.unwrap().unwrap();
            let mut bytes = Vec::new();
            reader.read_to_end(&mut bytes).await.unwrap();
            assert_eq!(bytes, expected.as_bytes());
        }
    }

    #[test]
    fn local_pressure_collection_stamp_survives_a_new_handle() {
        let directory = tempfile::tempdir().unwrap();
        let repository = Repository::new(
            crate::MemoryBlobStore::new(),
            crate::MemoryMetadataStore::new().unwrap(),
        );
        let first = LocalMutationStart::new(repository.clone(), directory.path().to_path_buf());
        assert!(!first.collection_is_recent());
        first.record_collection();
        let reopened = LocalMutationStart::new(repository, directory.path().to_path_buf());
        assert!(reopened.collection_is_recent());
    }
    use std::sync::RwLock as StdRwLock;
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

    use futures::stream::BoxStream;
    use proptest::prelude::*;

    use crate::node::Node;
    use crate::path::PathComponent;
    use crate::{
        BlobReader, BlobWriter, ChunkMeta, ChunkedBlobStore, Digest, MemoryBlobStore,
        MemoryMetadataStore, ObjectFormat,
    };

    #[test]
    fn transient_state_backend_failure_has_typed_retry_guidance() {
        let error = RepositoryError::Metadata(MetadataError::Transient("try later".to_owned()));
        assert_eq!(error.category(), RepositoryErrorCategory::Backend);
        assert_eq!(error.retry_disposition(), crate::RetryDisposition::Retry);
    }

    struct SyntheticFormat {
        namespace: crate::NamespaceId,
    }

    impl Default for SyntheticFormat {
        fn default() -> Self {
            Self {
                namespace: "test.graph.v1".parse().unwrap(),
            }
        }
    }

    #[async_trait]
    impl ObjectFormat for SyntheticFormat {
        fn namespace(&self) -> &crate::NamespaceId {
            &self.namespace
        }

        async fn verify(
            &self,
            mut context: VerificationContext<'_>,
            limits: &FormatLimits,
        ) -> Result<VerifiedObject, FormatError> {
            if context.key().native_id().len() != 1 {
                return Err(FormatError::InvalidPayload {
                    namespace: self.namespace.clone(),
                    message: "synthetic keys are exactly one byte".to_owned(),
                });
            }
            let bytes = context
                .read_to_end_bounded(limits.max_metadata_bytes)
                .await?;
            if bytes.windows(2).any(|pair| pair[0] >= pair[1]) {
                return Err(FormatError::InvalidPayload {
                    namespace: self.namespace.clone(),
                    message: "synthetic links are not strictly ordered".to_owned(),
                });
            }
            if bytes.len() > limits.max_links_per_object {
                return Err(FormatError::LinkLimit {
                    actual: bytes.len(),
                    limit: limits.max_links_per_object,
                });
            }
            let links = bytes
                .into_iter()
                .map(|native| {
                    ObjectKey::new(self.namespace.clone(), Bytes::from(vec![native])).unwrap()
                })
                .collect();
            context.finish(links)
        }
    }

    fn pc(value: &str) -> PathComponent {
        value.try_into().unwrap()
    }

    fn repository() -> Repository<MemoryBlobStore, MemoryMetadataStore> {
        Repository::new(MemoryBlobStore::new(), MemoryMetadataStore::new().unwrap())
    }

    #[test]
    fn storage_full_detection_preserves_typed_nested_errors() {
        assert!(is_storage_full(&RepositoryError::Metadata(
            MetadataError::StorageFull
        )));
        assert!(is_storage_full(&RepositoryError::Io(
            std::io::ErrorKind::StorageFull.into()
        )));
        let nested = object_store::Error::Generic {
            store: "test",
            source: Box::new(std::io::Error::from(std::io::ErrorKind::StorageFull)),
        };
        assert!(is_storage_full(&RepositoryError::Payload(
            crate::error::Error::Io(std::io::Error::other(nested))
        )));
        assert!(!is_storage_full(&RepositoryError::Io(
            std::io::Error::other("No space left on device")
        )));
    }

    #[tokio::test]
    async fn object_reader_handoff_preserves_requested_roots_without_blocking_unrelated_gc() {
        for local in [false, true] {
            for marked in [false, true] {
                for cancel in [false, true] {
                    let directory = tempfile::tempdir().unwrap();
                    let reader = if local {
                        crate::Repository::local(directory.path()).await.unwrap()
                    } else {
                        crate::Repository::memory().unwrap()
                    };
                    let collector = if local {
                        crate::Repository::local(directory.path()).await.unwrap()
                    } else {
                        reader.clone()
                    };
                    let held_name = "held".parse().unwrap();
                    let garbage_name = "garbage".parse().unwrap();
                    let expected = b"read through the catalog held before collection";
                    let held = reader.put_blob(&expected[..], held_name).await.unwrap();
                    let garbage = reader
                        .put_blob(&b"unrelated garbage"[..], garbage_name)
                        .await
                        .unwrap();
                    reader
                        .remove_root(&"garbage".parse().unwrap(), &garbage)
                        .await
                        .unwrap();
                    if !marked {
                        reader
                            .remove_root(&"held".parse().unwrap(), &held)
                            .await
                            .unwrap();
                    }
                    reader.flush().await.unwrap();
                    let core = &collector.inner;
                    let plan = core
                        .collection_plan(
                            core.coordination.clone().lock_owned().await,
                            core.exclusive_fs().await.unwrap(),
                            true,
                        )
                        .await
                        .unwrap();
                    let (entered, admitted) = tokio::sync::oneshot::channel();
                    let (resume, resumed) = tokio::sync::oneshot::channel();
                    let opening = tokio::spawn({
                        let reader = reader.clone();
                        let held = held.clone();
                        async move {
                            let mut profile = ObjectReadProfile {
                                pause_after_pin: Some((entered, resumed)),
                                ..Default::default()
                            };
                            reader.inner.open_object_inner(&held, &mut profile).await
                        }
                    });
                    tokio::time::timeout(std::time::Duration::from_secs(5), admitted)
                        .await
                        .unwrap()
                        .unwrap();
                    let ledger = core.metadata().pin_store().await.unwrap();
                    let inventory = ledger.inventory().await.unwrap();
                    assert!(inventory.pins.values().all(|pin| !matches!(
                        pin.scope,
                        crate::metadata::PinScope::Snapshot { .. }
                    )));
                    let temporary = inventory
                        .pins
                        .values()
                        .find(|pin| {
                            pin.scope
                                == crate::metadata::PinScope::Closures(BTreeSet::from([
                                    held.clone()
                                ]))
                        })
                        .unwrap();
                    if local {
                        assert!(
                            temporary.catalog.is_some(),
                            "catalog remains protected through handoff"
                        );
                    }
                    let outcome = tokio::time::timeout(
                        std::time::Duration::from_secs(10),
                        core.execute_collection(plan, false),
                    )
                    .await
                    .unwrap();
                    if marked {
                        assert_eq!(outcome.unwrap().removed.logical_objects, 1);
                        assert!(collector.object(&garbage).await.unwrap().is_none());
                    } else {
                        assert!(
                            matches!(outcome, Err(RepositoryError::Busy(reason)) if reason == "logical pin protects existing unmarked object")
                        );
                        assert!(collector.object(&held).await.unwrap().is_some());
                    }
                    if cancel {
                        opening.abort();
                        assert!(matches!(opening.await, Err(error) if error.is_cancelled()));
                        drop(resume);
                    } else {
                        resume.send(()).unwrap();
                        let (_, mut stream) = opening.await.unwrap().unwrap().unwrap();
                        let mut actual = Vec::new();
                        tokio::io::AsyncReadExt::read_to_end(&mut stream, &mut actual)
                            .await
                            .unwrap();
                        assert_eq!(actual, expected);
                        drop(stream);
                    }
                    reader.flush().await.unwrap();
                    if marked {
                        collector
                            .remove_root(&"held".parse().unwrap(), &held)
                            .await
                            .unwrap();
                    }
                    collector.flush().await.unwrap();
                    let removed = collector.collect().await.unwrap().logical_objects;
                    assert_eq!(removed, if marked { 1 } else { 2 });
                    collector.flush().await.unwrap();
                    let inventory = ledger.inventory().await.unwrap();
                    assert!(inventory.pins.is_empty() && inventory.deletions.is_empty());
                    assert!(inventory.collector.is_none() && inventory.logical_prune.is_none());
                    assert!(collector.open(&held).await.unwrap().is_none());
                }
            }
        }
    }

    fn graph_repository() -> Repository<MemoryBlobStore, MemoryMetadataStore> {
        Repository::with_formats(
            MemoryBlobStore::new(),
            MemoryMetadataStore::new().unwrap(),
            FormatRegistry::new([Arc::new(SyntheticFormat::default()) as Arc<dyn ObjectFormat>])
                .unwrap(),
            FormatLimits::default(),
        )
    }

    struct CollectOnMutationStart {
        repository: Repository<MemoryBlobStore, MemoryMetadataStore>,
        calls: Arc<AtomicUsize>,
    }

    #[async_trait]
    impl MutationStart for CollectOnMutationStart {
        async fn before_mutation(
            &self,
            _spill_limits: SpillLimits,
        ) -> Result<bool, RepositoryError> {
            self.repository.try_collect().await?;
            self.calls.fetch_add(1, Ordering::SeqCst);
            Ok(false)
        }
    }

    #[derive(Clone)]
    struct StaleOnceMetadataStore {
        inner: MemoryMetadataStore,
        stale_once: Arc<AtomicBool>,
    }

    #[derive(Clone)]
    struct FailingCommitMetadataStore<SS> {
        inner: SS,
        fail_once: Arc<AtomicBool>,
    }

    #[derive(Clone)]
    struct StorageFullOnceMetadataStore {
        inner: MemoryMetadataStore,
        fail_once: Arc<AtomicBool>,
    }

    #[derive(Clone)]
    struct InterruptedEmergencyMetadataStore {
        inner: MemoryMetadataStore,
        failures: Arc<AtomicUsize>,
    }

    #[derive(Clone)]
    struct FailingDeleteStore<BS> {
        inner: BS,
    }

    /// A physically shared backend that deliberately does not implement
    /// `BlobGc`, as a remote shared backend should not let one repository
    /// choose physical deletion.
    #[derive(Clone)]
    struct SharedBlobStore {
        inner: MemoryBlobStore,
    }

    #[derive(Clone)]
    struct HiddenObjectMetadataStore {
        inner: MemoryMetadataStore,
        hidden: Arc<StdRwLock<Option<ObjectKey>>>,
    }

    #[derive(Clone)]
    struct CountingBlobStore {
        inner: MemoryBlobStore,
        reads: Arc<AtomicUsize>,
    }

    #[derive(Clone, Copy)]
    enum WriterLie {
        Digest,
        Size,
    }

    #[derive(Clone)]
    struct LyingWriterStore {
        inner: MemoryBlobStore,
        lie: WriterLie,
    }

    struct LyingWriter {
        inner: Box<dyn BlobWriter>,
        lie: WriterLie,
    }

    impl tokio::io::AsyncWrite for LyingWriter {
        fn poll_write(
            mut self: std::pin::Pin<&mut Self>,
            cx: &mut std::task::Context<'_>,
            buffer: &[u8],
        ) -> std::task::Poll<std::io::Result<usize>> {
            std::pin::Pin::new(&mut *self.inner).poll_write(cx, buffer)
        }

        fn poll_flush(
            mut self: std::pin::Pin<&mut Self>,
            cx: &mut std::task::Context<'_>,
        ) -> std::task::Poll<std::io::Result<()>> {
            std::pin::Pin::new(&mut *self.inner).poll_flush(cx)
        }

        fn poll_shutdown(
            mut self: std::pin::Pin<&mut Self>,
            cx: &mut std::task::Context<'_>,
        ) -> std::task::Poll<std::io::Result<()>> {
            std::pin::Pin::new(&mut *self.inner).poll_shutdown(cx)
        }
    }

    #[async_trait]
    impl BlobWriter for LyingWriter {
        async fn close(&mut self) -> Result<(BlobId, u64), crate::error::Error> {
            let (digest, size) = self.inner.close().await?;
            Ok(match self.lie {
                WriterLie::Digest => (BlobId::new(Digest::hash(b"writer-lie")), size),
                WriterLie::Size => (digest, size.saturating_add(1)),
            })
        }
    }

    struct HiddenObjectSnapshot {
        inner: Arc<dyn MetadataSnapshot>,
        hidden: Option<ObjectKey>,
    }

    #[async_trait]
    impl MetadataSnapshot for HiddenObjectSnapshot {
        fn generation(&self) -> Result<u64, MetadataError> {
            self.inner.generation()
        }
        fn objects_created_through(
            &self,
            generation: u64,
        ) -> futures::stream::BoxStream<'static, Result<ObjectRecord, MetadataError>> {
            let hidden = self.hidden.clone();
            Box::pin(
                self.inner
                    .objects_created_through(generation)
                    .filter_map(move |record| {
                        let hidden = hidden.clone();
                        async move {
                            match record {
                                Ok(record) if Some(record.key()) == hidden.as_ref() => None,
                                other => Some(other),
                            }
                        }
                    }),
            )
        }

        fn revision(&self) -> crate::RepositoryRevision {
            self.inner.revision()
        }

        fn retention_resources(&self) -> std::collections::BTreeSet<crate::metadata::PinResource> {
            self.inner.retention_resources()
        }

        async fn object(&self, key: &ObjectKey) -> Result<Option<ObjectRecord>, MetadataError> {
            if self.hidden.as_ref() == Some(key) {
                Ok(None)
            } else {
                self.inner.object(key).await
            }
        }

        async fn root(&self, name: &RootName) -> Result<Option<ObjectKey>, MetadataError> {
            self.inner.root(name).await
        }

        fn objects(&self) -> BoxStream<'static, Result<ObjectRecord, MetadataError>> {
            let hidden = self.hidden.clone();
            Box::pin(self.inner.objects().filter_map(move |record| {
                let hidden = hidden.clone();
                async move {
                    match record {
                        Ok(record) if Some(record.key()) == hidden.as_ref() => None,
                        other => Some(other),
                    }
                }
            }))
        }

        fn roots(&self) -> BoxStream<'static, Result<crate::RootRecord, MetadataError>> {
            self.inner.roots()
        }
    }

    #[async_trait]
    impl MetadataStore for HiddenObjectMetadataStore {
        async fn pin_store(
            &self,
        ) -> Result<std::sync::Arc<dyn crate::metadata::PinStore>, crate::metadata::MetadataError>
        {
            self.inner.pin_store().await
        }

        async fn snapshot(&self) -> Result<Arc<dyn MetadataSnapshot>, MetadataError> {
            let hidden = self
                .hidden
                .read()
                .map_err(|_| MetadataError::Poisoned)?
                .clone();
            Ok(Arc::new(HiddenObjectSnapshot {
                inner: self.inner.snapshot().await?,
                hidden,
            }))
        }

        async fn commit(
            &self,
            expected: &crate::RepositoryRevision,
            mutation: MetadataMutation,
        ) -> Result<CommitResult, MetadataError> {
            self.inner.commit(expected, mutation).await
        }
    }

    #[async_trait]
    impl<BS: BlobStore> BlobStore for FailingDeleteStore<BS> {
        fn write_scope(&self) -> crate::metadata::BackendWriteScope {
            self.inner.write_scope()
        }

        fn begin_pinned_batch(
            &self,
            pin: crate::metadata::DataPinLease,
        ) -> Result<crate::blob::BlobBatchGuard, crate::error::Error> {
            self.inner.begin_pinned_batch(pin)
        }

        async fn has(&self, digest: &BlobId) -> Result<bool, crate::error::Error> {
            self.inner.has(digest).await
        }

        async fn open_read(
            &self,
            digest: &BlobId,
        ) -> Result<Option<Box<dyn BlobReader>>, crate::error::Error> {
            self.inner.open_read(digest).await
        }

        async fn open_write(&self) -> Box<dyn BlobWriter> {
            self.inner.open_write().await
        }

        async fn chunks(
            &self,
            digest: &BlobId,
        ) -> Result<Option<Vec<ChunkMeta>>, crate::error::Error> {
            self.inner.chunks(digest).await
        }
    }

    #[async_trait]
    impl BlobStore for SharedBlobStore {
        fn write_scope(&self) -> crate::metadata::BackendWriteScope {
            self.inner.write_scope()
        }

        fn begin_pinned_batch(
            &self,
            pin: crate::metadata::DataPinLease,
        ) -> Result<crate::blob::BlobBatchGuard, crate::error::Error> {
            self.inner.begin_pinned_batch(pin)
        }

        async fn has(&self, digest: &BlobId) -> Result<bool, crate::error::Error> {
            self.inner.has(digest).await
        }

        async fn open_read(
            &self,
            digest: &BlobId,
        ) -> Result<Option<Box<dyn BlobReader>>, crate::error::Error> {
            self.inner.open_read(digest).await
        }

        async fn open_write(&self) -> Box<dyn BlobWriter> {
            self.inner.open_write().await
        }

        async fn chunks(
            &self,
            digest: &BlobId,
        ) -> Result<Option<Vec<ChunkMeta>>, crate::error::Error> {
            self.inner.chunks(digest).await
        }
    }

    #[async_trait]
    impl BlobStore for CountingBlobStore {
        fn write_scope(&self) -> crate::metadata::BackendWriteScope {
            self.inner.write_scope()
        }

        fn begin_pinned_batch(
            &self,
            pin: crate::metadata::DataPinLease,
        ) -> Result<crate::blob::BlobBatchGuard, crate::error::Error> {
            self.inner.begin_pinned_batch(pin)
        }

        async fn has(&self, digest: &BlobId) -> Result<bool, crate::error::Error> {
            self.inner.has(digest).await
        }

        async fn open_read(
            &self,
            digest: &BlobId,
        ) -> Result<Option<Box<dyn BlobReader>>, crate::error::Error> {
            self.reads.fetch_add(1, Ordering::SeqCst);
            self.inner.open_read(digest).await
        }

        async fn open_write(&self) -> Box<dyn BlobWriter> {
            self.inner.open_write().await
        }

        async fn chunks(
            &self,
            digest: &BlobId,
        ) -> Result<Option<Vec<ChunkMeta>>, crate::error::Error> {
            self.inner.chunks(digest).await
        }
    }

    #[async_trait]
    impl BlobStore for LyingWriterStore {
        fn write_scope(&self) -> crate::metadata::BackendWriteScope {
            self.inner.write_scope()
        }

        fn begin_pinned_batch(
            &self,
            pin: crate::metadata::DataPinLease,
        ) -> Result<crate::blob::BlobBatchGuard, crate::error::Error> {
            self.inner.begin_pinned_batch(pin)
        }

        async fn has(&self, digest: &BlobId) -> Result<bool, crate::error::Error> {
            self.inner.has(digest).await
        }

        async fn open_read(
            &self,
            digest: &BlobId,
        ) -> Result<Option<Box<dyn BlobReader>>, crate::error::Error> {
            self.inner.open_read(digest).await
        }

        async fn overwrite(
            &self,
            digest: &BlobId,
            size: u64,
            offset: u64,
            replacement: &[u8],
        ) -> Result<(BlobId, bytes::Bytes), crate::error::Error> {
            let (actual, proof) = self
                .inner
                .overwrite(digest, size, offset, replacement)
                .await?;
            Ok(match self.lie {
                WriterLie::Digest => (BlobId::new(Digest::hash(b"lying overwrite")), proof),
                WriterLie::Size => (
                    actual,
                    bytes::Bytes::from_static(b"invalid old-content proof"),
                ),
            })
        }

        async fn open_write(&self) -> Box<dyn BlobWriter> {
            Box::new(LyingWriter {
                inner: self.inner.open_write().await,
                lie: self.lie,
            })
        }
    }

    #[async_trait]
    impl<BS: BlobStore + BlobGc> BlobGc for FailingDeleteStore<BS> {
        async fn reclaim_metadata_pinned(
            &self,
            pins: Arc<dyn crate::metadata::PinStore>,
            owned_claims: std::collections::BTreeSet<crate::metadata::PinToken>,
        ) -> Result<(), crate::error::Error> {
            self.inner.reclaim_metadata_pinned(pins, owned_claims).await
        }

        fn list_blobs(&self) -> BoxStream<'_, Result<BlobId, crate::error::Error>> {
            self.inner.list_blobs()
        }

        fn list_chunks(&self) -> BoxStream<'_, Result<ChunkId, crate::error::Error>> {
            self.inner.list_chunks()
        }

        async fn delete_blob(&self, _digest: &BlobId) -> Result<(), crate::error::Error> {
            Err(crate::error::Error::Msg(
                "injected physical deletion failure".to_owned(),
            ))
        }

        async fn delete_chunk(&self, _digest: &ChunkId) -> Result<(), crate::error::Error> {
            Err(crate::error::Error::Msg(
                "injected physical deletion failure".to_owned(),
            ))
        }
    }

    #[async_trait]
    impl<SS: MetadataStore> MetadataStore for FailingCommitMetadataStore<SS> {
        async fn pin_store(
            &self,
        ) -> Result<std::sync::Arc<dyn crate::metadata::PinStore>, crate::metadata::MetadataError>
        {
            self.inner.pin_store().await
        }

        fn coordinates_payload_catalog(&self) -> bool {
            self.inner.coordinates_payload_catalog()
        }

        async fn snapshot(&self) -> Result<Arc<dyn MetadataSnapshot>, MetadataError> {
            self.inner.snapshot().await
        }

        async fn commit(
            &self,
            expected: &crate::RepositoryRevision,
            mutation: MetadataMutation,
        ) -> Result<CommitResult, MetadataError> {
            if self.fail_once.swap(false, Ordering::SeqCst) {
                return Err(MetadataError::Backend(
                    "injected failure before logical commit".to_owned(),
                ));
            }
            self.inner.commit(expected, mutation).await
        }
    }

    #[async_trait]
    impl MetadataStore for StorageFullOnceMetadataStore {
        async fn pin_store(
            &self,
        ) -> Result<std::sync::Arc<dyn crate::metadata::PinStore>, crate::metadata::MetadataError>
        {
            self.inner.pin_store().await
        }

        fn coordinates_payload_catalog(&self) -> bool {
            self.inner.coordinates_payload_catalog()
        }

        async fn snapshot(&self) -> Result<Arc<dyn MetadataSnapshot>, MetadataError> {
            self.inner.snapshot().await
        }

        async fn commit(
            &self,
            expected: &crate::RepositoryRevision,
            mutation: MetadataMutation,
        ) -> Result<CommitResult, MetadataError> {
            if self.fail_once.swap(false, Ordering::SeqCst) {
                return Err(MetadataError::StorageFull);
            }
            self.inner.commit(expected, mutation).await
        }
    }

    #[async_trait]
    impl MetadataStore for InterruptedEmergencyMetadataStore {
        async fn pin_store(
            &self,
        ) -> Result<std::sync::Arc<dyn crate::metadata::PinStore>, crate::metadata::MetadataError>
        {
            self.inner.pin_store().await
        }

        fn coordinates_payload_catalog(&self) -> bool {
            self.inner.coordinates_payload_catalog()
        }

        async fn snapshot(&self) -> Result<Arc<dyn MetadataSnapshot>, MetadataError> {
            self.inner.snapshot().await
        }

        async fn commit(
            &self,
            expected: &crate::RepositoryRevision,
            mutation: MetadataMutation,
        ) -> Result<CommitResult, MetadataError> {
            match self
                .failures
                .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |value| {
                    value.checked_sub(1)
                }) {
                Ok(2) => Err(MetadataError::StorageFull),
                Ok(1) => Err(MetadataError::Backend(
                    "injected failure after emergency sweep".to_owned(),
                )),
                _ => self.inner.commit(expected, mutation).await,
            }
        }
    }

    #[async_trait]
    impl MetadataStore for StaleOnceMetadataStore {
        async fn pin_store(
            &self,
        ) -> Result<std::sync::Arc<dyn crate::metadata::PinStore>, crate::metadata::MetadataError>
        {
            self.inner.pin_store().await
        }

        async fn snapshot(&self) -> Result<Arc<dyn MetadataSnapshot>, MetadataError> {
            self.inner.snapshot().await
        }

        async fn commit(
            &self,
            expected: &crate::RepositoryRevision,
            mutation: MetadataMutation,
        ) -> Result<CommitResult, MetadataError> {
            if self.stale_once.swap(false, Ordering::SeqCst) {
                let competing = self.inner.commit(expected, MetadataMutation::new()).await?;
                return Err(MetadataError::StaleRevision {
                    expected: *expected,
                    actual: competing.revision,
                });
            }
            self.inner.commit(expected, mutation).await
        }
    }

    async fn stage_graph<'hold, SS: MetadataStore>(
        mutation: &'hold MutationSession<'_, MemoryBlobStore, SS>,
        native: u8,
        links: &[u8],
    ) -> StagedObject<'hold> {
        let payload = mutation.repository.payloads.put_slice(links).await.unwrap();
        let key =
            ObjectKey::new("test.graph.v1".parse().unwrap(), Bytes::from(vec![native])).unwrap();
        mutation.stage_existing(key, payload).await.unwrap()
    }

    fn chunked_repository(
        average_chunk_size: u32,
    ) -> Repository<ChunkedBlobStore, MemoryMetadataStore> {
        Repository::new(
            ChunkedBlobStore::new(
                Arc::new(object_store::memory::InMemory::new()),
                object_store::path::Path::default(),
                average_chunk_size,
            ),
            MemoryMetadataStore::new().unwrap(),
        )
    }

    #[derive(Clone, Debug)]
    enum GcModelOperation {
        Set { name: u8, graph: u8 },
        Remove { name: u8 },
        Collect,
    }

    fn gc_model_strategy() -> impl Strategy<Value = GcModelOperation> {
        prop_oneof![
            3 => (0u8..3, 0u8..4)
                .prop_map(|(name, graph)| GcModelOperation::Set { name, graph }),
            1 => (0u8..3).prop_map(|name| GcModelOperation::Remove { name }),
            2 => Just(GcModelOperation::Collect),
        ]
    }

    fn gc_model_nodes(graph: u8) -> Vec<(u8, Vec<u8>)> {
        match graph {
            0 => vec![(1, vec![3]), (2, vec![]), (3, vec![]), (10, vec![1, 2])],
            1 => vec![(1, vec![3]), (3, vec![]), (4, vec![]), (11, vec![1, 4])],
            2 => vec![(2, vec![]), (5, vec![]), (12, vec![2, 5])],
            3 => vec![(6, vec![]), (7, vec![]), (13, vec![6, 7])],
            _ => unreachable!("the strategy emits four graphs"),
        }
    }

    fn gc_model_key(native: u8) -> ObjectKey {
        ObjectKey::new("test.graph.v1".parse().unwrap(), Bytes::from(vec![native])).unwrap()
    }

    fn gc_model_root(graph: u8) -> ObjectKey {
        let native = match graph {
            0 => 10,
            1 => 11,
            2 => 12,
            3 => 13,
            _ => unreachable!("the strategy emits four graphs"),
        };
        gc_model_key(native)
    }

    fn gc_model_closure(graph: u8) -> BTreeSet<ObjectKey> {
        gc_model_nodes(graph)
            .into_iter()
            .map(|(native, _)| gc_model_key(native))
            .collect()
    }

    async fn run_gc_model(operations: &[GcModelOperation]) -> Result<(), String> {
        let repository = graph_repository();
        let mut roots = BTreeMap::<u8, u8>::new();

        for (index, operation) in operations.iter().enumerate() {
            match *operation {
                GcModelOperation::Set { name, graph } => {
                    let mutation = repository
                        .mutation_session()
                        .await
                        .map_err(|error| format!("operation {index} mutation: {error}"))?;
                    let mut staged = Vec::new();
                    for (native, links) in gc_model_nodes(graph) {
                        staged.push(stage_graph(&mutation, native, &links).await);
                    }
                    mutation
                        .publish_rooted(
                            staged,
                            RootName::try_from(format!("model/{name}")).unwrap(),
                            gc_model_root(graph),
                        )
                        .await
                        .map_err(|error| format!("operation {index} set: {error}"))?;
                    roots.insert(name, graph);
                }
                GcModelOperation::Remove { name } => {
                    repository
                        .mutation_session()
                        .await
                        .map_err(|error| format!("operation {index} mutation: {error}"))?
                        .publish(
                            Vec::new(),
                            vec![RootChange::Remove {
                                name: RootName::try_from(format!("model/{name}")).unwrap(),
                            }],
                        )
                        .await
                        .map_err(|error| format!("operation {index} remove: {error}"))?;
                    roots.remove(&name);
                }
                GcModelOperation::Collect => {
                    repository
                        .collect()
                        .await
                        .map_err(|error| format!("operation {index} collection: {error}"))?;
                    let expected_keys: BTreeSet<_> = roots
                        .values()
                        .flat_map(|graph| gc_model_closure(*graph))
                        .collect();
                    let snapshot = repository
                        .metadata()
                        .snapshot()
                        .await
                        .map_err(|error| format!("operation {index} snapshot: {error}"))?;
                    let records = snapshot
                        .objects()
                        .try_collect::<Vec<_>>()
                        .await
                        .map_err(|error| format!("operation {index} records: {error}"))?;
                    let actual_keys: BTreeSet<_> =
                        records.iter().map(|record| record.key().clone()).collect();
                    if actual_keys != expected_keys {
                        return Err(format!(
                            "operation {index} ({operation:?}) retained {actual_keys:?}, expected {expected_keys:?}"
                        ));
                    }

                    let expected_payloads: BTreeSet<_> =
                        records.iter().map(ObjectRecord::payload).collect();
                    let actual_payloads: BTreeSet<_> = repository
                        .payloads()
                        .list_blobs()
                        .try_collect()
                        .await
                        .map_err(|error| format!("operation {index} payloads: {error}"))?;
                    if actual_payloads != expected_payloads {
                        return Err(format!(
                            "operation {index} ({operation:?}) retained payloads {actual_payloads:?}, expected {expected_payloads:?}"
                        ));
                    }
                }
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn logical_collection_retains_a_pin_and_collects_unrelated_records() {
        use crate::metadata::{DataPin, DataPinLease, PinScope};

        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let held = mutation.stage_blob(b"held").await.unwrap();
        let key = held.record().key().clone();
        let stale = mutation.stage_blob(b"stale").await.unwrap();
        let stale_key = stale.record().key().clone();
        mutation.publish_unrooted(vec![held, stale]).await.unwrap();
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        let pin = DataPinLease::acquire(
            repository.metadata().pin_store().await.unwrap(),
            DataPin {
                scope: PinScope::Closures(BTreeSet::from([key.clone()])),
                catalog: None,
                resources: BTreeSet::new(),
            },
        )
        .await
        .unwrap();
        let collected = repository.collect_logical().await.unwrap();
        assert_eq!(collected.removed.logical_objects, 1);
        let snapshot = repository.metadata().snapshot().await.unwrap();
        assert!(snapshot.object(&key).await.unwrap().is_some());
        assert!(snapshot.object(&stale_key).await.unwrap().is_none());
        drop(snapshot);
        drop(pin);
        crate::flush_repository_leases().await.unwrap();
        assert_eq!(
            repository
                .collect_logical()
                .await
                .unwrap()
                .removed
                .logical_objects,
            1
        );
    }

    #[tokio::test]
    async fn collection_progress_distinguishes_snapshot_protection_from_idle_writers() {
        let repository = repository();
        let seed = repository.mutation_session().await.unwrap();
        let sentinel = seed.stage_blob(b"sentinel").await.unwrap();
        let key = sentinel.record().key().clone();
        seed.publish_rooted(vec![sentinel], "sentinel".parse().unwrap(), key.clone())
            .await
            .unwrap();
        drop(seed);
        crate::flush_repository_leases().await.unwrap();
        // Keep a reader and writer alive for the entire sequence. Neither owns
        // the subsequently created garbage.
        let old = repository.retention_hold().await.unwrap();
        let idle = repository.mutation_session().await.unwrap();
        for iteration in 0..4 {
            let writer = repository.mutation_session().await.unwrap();
            let garbage = writer.stage_blob(&[iteration; 4096]).await.unwrap();
            let payload = garbage.record().payload();
            writer.publish_unrooted(vec![garbage]).await.unwrap();
            drop(writer);
            crate::flush_repository_leases().await.unwrap();
            let fresh = repository.retention_hold().await.unwrap();
            assert_eq!(
                repository.collect().await.unwrap().removed.logical_objects,
                0
            );
            assert!(repository.payloads().has(&payload).await.unwrap());
            drop(fresh);
            crate::flush_repository_leases().await.unwrap();
            let collected = repository.collect().await.unwrap();
            assert_eq!(collected.removed.logical_objects, 1);
            assert_eq!(collected.removed.payload_blobs, 1);
            assert!(!repository.payloads().has(&payload).await.unwrap());
            let (_, mut reader) = old.open_payload(&key).await.unwrap().unwrap();
            let mut bytes = Vec::new();
            reader.read_to_end(&mut bytes).await.unwrap();
            assert_eq!(bytes, b"sentinel");
        }
        drop((old, idle));
        crate::flush_repository_leases().await.unwrap();
    }

    #[tokio::test]
    async fn physical_only_writer_growth_allows_collection_without_metadata_changes() {
        check_physical_growth(repository(), false, false).await;
        check_physical_growth(chunked_repository(1024), true, false).await;
        check_physical_growth(chunked_repository(1024), true, true).await;
    }

    async fn check_physical_growth<PS: BlobGc + 'static>(
        repository: Repository<PS, MemoryMetadataStore>,
        chunked: bool,
        manifest_only: bool,
    ) {
        // Memory metadata isolates this conflict from Turso and database locks.
        let bytes: Vec<u8> = (0..8192).map(|i| (i % 251) as u8).collect();
        let seed = repository.mutation_session().await.unwrap();
        let garbage = seed.stage_blob(&bytes).await.unwrap();
        let payload = garbage.record().payload();
        seed.publish_unrooted(vec![garbage]).await.unwrap();
        drop(seed);
        crate::flush_repository_leases().await.unwrap();
        let writer = repository.mutation_session().await.unwrap();
        let plan = repository
            .collection_plan(
                repository.coordination.clone().lock_owned().await,
                None,
                true,
            )
            .await
            .unwrap();
        assert_eq!(plan.preview.logical_objects, 1);
        if chunked {
            assert!(plan.preview.chunks > 1);
        }
        let revision = plan.logical.snapshot_revision;
        // No logical publication, new closure, or snapshot hold is involved.
        let staged = if manifest_only {
            // Protect only the manifest identity: sweep must discover its chunks
            // from this late pin instead of relying on explicit chunk pins.
            writer
                .pin
                .protect(BTreeSet::from([crate::metadata::PinResource::Blob(
                    payload,
                )]))
                .await
                .unwrap();
            None
        } else {
            Some(writer.stage_blob(&bytes).await.unwrap())
        };
        let inventory = repository
            .metadata()
            .pin_store()
            .await
            .unwrap()
            .inventory()
            .await
            .unwrap();
        assert!(inventory.pins.values().all(|pin| {
            pin.scope == crate::metadata::PinScope::Staging
                && pin
                    .resources
                    .iter()
                    .all(|resource| !matches!(resource, crate::metadata::PinResource::Object(_)))
        }));
        assert_eq!(
            repository.metadata().snapshot().await.unwrap().revision(),
            revision
        );
        // Reusing bytes already selected as garbage must retain them physically
        // while allowing the old unrooted logical record to be pruned.
        let result = repository.execute_collection(plan, false).await.unwrap();
        assert_eq!(result.removed.logical_objects, 1);
        assert_eq!(result.removed.payload_blobs, 0);
        assert!(repository.payloads().has(&payload).await.unwrap());
        let mut reader = repository
            .payloads()
            .open_read(&payload)
            .await
            .unwrap()
            .unwrap();
        let mut recovered = Vec::new();
        reader.read_to_end(&mut recovered).await.unwrap();
        assert_eq!(recovered, bytes);
        drop(reader);
        assert_eq!(result.removed.chunks, 0);
        let staged = match staged {
            Some(staged) => staged,
            None => writer.stage_blob(&bytes).await.unwrap(),
        };
        writer.publish_unrooted(vec![staged]).await.unwrap();
        drop(writer);
        crate::flush_repository_leases().await.unwrap();
        assert!(repository.fsck().await.unwrap().is_healthy());
    }

    #[tokio::test]
    async fn logical_prune_fences_validation_and_cleans_up_after_error_or_cancellation() {
        #[derive(Debug)]
        struct Gated {
            inner: Arc<dyn crate::metadata::RetainedObjects>,
            reached: tokio::sync::Notify,
            resume: tokio::sync::Notify,
            first: std::sync::atomic::AtomicBool,
            fail: bool,
        }
        #[async_trait]
        impl crate::metadata::RetainedObjects for Gated {
            fn len(&self) -> usize {
                self.inner.len()
            }
            async fn page(
                &self,
                after: Option<ObjectKey>,
                limit: usize,
            ) -> Result<Vec<ObjectKey>, MetadataError> {
                self.inner.page(after, limit).await
            }
            async fn contains(&self, key: &ObjectKey) -> Result<bool, MetadataError> {
                if self.first.swap(false, Ordering::SeqCst) {
                    self.reached.notify_one();
                    self.resume.notified().await;
                    if self.fail {
                        return Err(MetadataError::Backend("validation lookup failed".into()));
                    }
                }
                self.inner.contains(key).await
            }
        }
        for fail in [false, true] {
            for cancel in [false, true] {
                let repository = repository();
                let seed = repository.mutation_session().await.unwrap();
                let garbage = seed
                    .stage_blob(b"garbage before fenced validation")
                    .await
                    .unwrap();
                let key = garbage.record().key().clone();
                seed.publish_unrooted(vec![garbage]).await.unwrap();
                drop(seed);
                crate::flush_repository_leases().await.unwrap();
                let plan = repository
                    .logical_collection_plan(
                        repository.coordination.clone().lock_owned().await,
                        None,
                        true,
                    )
                    .await
                    .unwrap();
                let ledger = repository.metadata().pin_store().await.unwrap();
                let new_pin = crate::metadata::DataPin {
                    scope: crate::metadata::PinScope::Closures(BTreeSet::from([ObjectKey::blob(
                        BlobId::new(Digest::hash(b"unpublished root")),
                    )])),
                    catalog: None,
                    resources: BTreeSet::new(),
                };
                let pin = crate::metadata::DataPinLease::acquire(ledger.clone(), new_pin.clone())
                    .await
                    .unwrap();
                let gated = Arc::new(Gated {
                    inner: plan.live_objects.clone(),
                    reached: tokio::sync::Notify::new(),
                    resume: tokio::sync::Notify::new(),
                    first: std::sync::atomic::AtomicBool::new(true),
                    fail,
                });
                let publication = repository.publication.clone();
                let protection = plan.protection.clone();
                let expected = plan.snapshot_revision;
                let marked = plan.pins.clone();
                let retained = MetadataMutation::install_retained_source(gated.clone());
                let waiter = tokio::spawn(async move {
                    publication
                        .prune(
                            protection,
                            expected,
                            marked,
                            BTreeSet::new(),
                            None,
                            retained,
                        )
                        .await
                });
                tokio::time::timeout(Duration::from_secs(5), gated.reached.notified())
                    .await
                    .unwrap();
                assert!(ledger.inventory().await.unwrap().logical_prune.is_some());
                assert!(ledger.register(new_pin.clone()).await.unwrap().is_none());
                if cancel {
                    waiter.abort();
                    assert!(waiter.await.unwrap_err().is_cancelled());
                    // Cancellation of the caller cannot open admission while
                    // the tracked validation task still owns the fence.
                    assert!(ledger.inventory().await.unwrap().logical_prune.is_some());
                } else {
                    gated.resume.notify_one();
                    let result = waiter.await.unwrap();
                    if fail {
                        assert!(
                            matches!(result, Err(RepositoryError::Metadata(MetadataError::Backend(ref message))) if message == "validation lookup failed")
                        );
                    } else {
                        result.unwrap();
                    }
                }
                if cancel {
                    gated.resume.notify_one();
                }
                crate::flush_repository_leases().await.unwrap();
                assert!(ledger.inventory().await.unwrap().logical_prune.is_none());
                let admitted = ledger.register(new_pin).await.unwrap().unwrap();
                ledger.release(&admitted).await.unwrap();
                assert_eq!(
                    repository
                        .metadata()
                        .snapshot()
                        .await
                        .unwrap()
                        .object(&key)
                        .await
                        .unwrap()
                        .is_some(),
                    fail
                );
                drop((pin, plan));
                crate::flush_repository_leases().await.unwrap();
                assert!(ledger.inventory().await.unwrap().collector.is_none());
            }
        }
    }

    #[tokio::test]
    async fn collection_accepts_unpublished_roots_but_rejects_concurrent_publication() {
        for published in [false, true] {
            let repository = repository();
            let seed = repository.mutation_session().await.unwrap();
            let old = seed.stage_blob(b"old garbage").await.unwrap();
            seed.publish_unrooted(vec![old]).await.unwrap();
            drop(seed);
            crate::flush_repository_leases().await.unwrap();
            let plan = repository
                .collection_plan(
                    repository.coordination.clone().lock_owned().await,
                    None,
                    true,
                )
                .await
                .unwrap();
            let writer = repository.mutation_session().await.unwrap();
            let staged = writer.stage_blob(b"new data").await.unwrap();
            let key = staged.record().key().clone();
            let payload = staged.record().payload();
            writer
                .pin
                .protect(BTreeSet::from([crate::metadata::PinResource::Object(
                    key.clone(),
                )]))
                .await
                .unwrap();
            assert!(
                plan.logical
                    .snapshot
                    .as_ref()
                    .expect("mark snapshot")
                    .object(&key)
                    .await
                    .unwrap()
                    .is_none()
            );
            let mut staged = Some(staged);
            if published {
                writer
                    .publish_unrooted(vec![staged.take().unwrap()])
                    .await
                    .unwrap();
            }
            let result = repository.execute_collection(plan, false).await;
            if published {
                assert!(matches!(
                    result,
                    Err(RepositoryError::Metadata(
                        MetadataError::StaleRevision { .. }
                    ))
                ));
                assert_eq!(
                    repository.collect().await.unwrap().removed.logical_objects,
                    1
                );
            } else {
                assert_eq!(result.unwrap().removed.logical_objects, 1);
            }
            assert!(repository.payloads().has(&payload).await.unwrap());
            if let Some(staged) = staged {
                writer.publish_unrooted(vec![staged]).await.unwrap();
            }
            drop(writer);
            crate::flush_repository_leases().await.unwrap();
            assert!(repository.fsck().await.unwrap().is_healthy());
        }
    }

    #[tokio::test]
    async fn collection_accepts_new_pins_only_for_already_marked_objects() {
        use crate::metadata::{DataPin, DataPinLease, PinResource, PinScope};
        for covered in [true, false] {
            for explicit_object in [false, true] {
                let repository = repository();
                let seed = repository.mutation_session().await.unwrap();
                let kept = seed.stage_blob(b"rooted").await.unwrap();
                let key = kept.record().key().clone();
                seed.publish_rooted(vec![kept], "kept".parse().unwrap(), key.clone())
                    .await
                    .unwrap();
                let garbage = seed.stage_blob(b"garbage").await.unwrap();
                let garbage_key = garbage.record().key().clone();
                let garbage_payload = garbage.record().payload();
                seed.publish_unrooted(vec![garbage]).await.unwrap();
                drop(seed);
                crate::flush_repository_leases().await.unwrap();
                let plan = repository
                    .collection_plan(
                        repository.coordination.clone().lock_owned().await,
                        None,
                        true,
                    )
                    .await
                    .unwrap();
                assert_eq!(plan.preview.logical_objects, 1);
                let target = if covered { key.clone() } else { garbage_key };
                // Put an absent root first: accepting it must not skip checking
                // the existing root later in this same pin.
                let absent = (0u64..1024)
                    .map(|i| ObjectKey::blob(BlobId::new(Digest::hash(&i.to_le_bytes()))))
                    .find(|candidate| candidate < &target)
                    .unwrap();
                assert!(
                    repository
                        .metadata()
                        .snapshot()
                        .await
                        .unwrap()
                        .object(&absent)
                        .await
                        .unwrap()
                        .is_none()
                );
                let pin = DataPinLease::acquire(
                    repository.metadata().pin_store().await.unwrap(),
                    DataPin {
                        scope: if explicit_object {
                            PinScope::Staging
                        } else {
                            PinScope::Closures(BTreeSet::from([absent.clone(), target.clone()]))
                        },
                        catalog: None,
                        resources: if explicit_object {
                            BTreeSet::from([
                                PinResource::Object(absent),
                                PinResource::Object(target),
                            ])
                        } else {
                            BTreeSet::new()
                        },
                    },
                )
                .await
                .unwrap();
                let result = repository.execute_collection(plan, false).await;
                if covered {
                    assert_eq!(result.unwrap().removed.logical_objects, 1);
                    assert!(!repository.payloads().has(&garbage_payload).await.unwrap());
                } else {
                    assert!(matches!(result, Err(RepositoryError::Busy(_))));
                    assert!(repository.payloads().has(&garbage_payload).await.unwrap());
                }
                let (_, mut reader) = repository.open_payload(&key).await.unwrap().unwrap();
                let mut bytes = Vec::new();
                reader.read_to_end(&mut bytes).await.unwrap();
                assert_eq!(bytes, b"rooted");
                drop((reader, pin));
                crate::flush_repository_leases().await.unwrap();
            }
        }
    }

    #[tokio::test]
    async fn collection_progress_survives_duplicate_readers_after_marking() {
        for new_protection in [false, true] {
            let repository = repository();
            let writer = repository.mutation_session().await.unwrap();
            let kept = writer.stage_blob(b"kept").await.unwrap();
            let key = kept.record().key().clone();
            let garbage = writer.stage_blob(b"garbage").await.unwrap();
            let garbage_key = garbage.record().key().clone();
            let payload = garbage.record().payload();
            writer.publish_unrooted(vec![kept, garbage]).await.unwrap();
            drop(writer);
            crate::flush_repository_leases().await.unwrap();
            let original = repository.open_payload(&key).await.unwrap().unwrap();
            let plan = repository
                .collection_plan(
                    repository.coordination.clone().lock_owned().await,
                    None,
                    true,
                )
                .await
                .unwrap();
            assert_eq!(plan.preview.logical_objects, 1);
            let mut readers = Vec::new();
            for _ in 0..32 {
                readers.push(repository.open_payload(&key).await.unwrap().unwrap());
            }
            // Retired identical pins must also be harmless.
            drop(original);
            crate::flush_repository_leases().await.unwrap();
            if new_protection {
                readers.push(
                    repository
                        .open_payload(&garbage_key)
                        .await
                        .unwrap()
                        .unwrap(),
                );
            }
            let result = repository.execute_collection(plan, false).await;
            if new_protection {
                assert!(matches!(result, Err(RepositoryError::Busy(_))));
                assert!(repository.payloads().has(&payload).await.unwrap());
            } else {
                assert_eq!(result.unwrap().removed.logical_objects, 1);
                assert!(!repository.payloads().has(&payload).await.unwrap());
            }
            for (_, mut reader) in readers {
                let mut bytes = Vec::new();
                reader.read_to_end(&mut bytes).await.unwrap();
                assert!(bytes == b"kept" || (new_protection && bytes == b"garbage"));
            }
            crate::flush_repository_leases().await.unwrap();
        }
    }

    #[tokio::test]
    async fn collection_progress_survives_idle_writers_admitted_after_marking() {
        for acquire_resource in [false, true] {
            let repository = repository();
            let writer = repository.mutation_session().await.unwrap();
            let garbage = writer.stage_blob(b"unreachable").await.unwrap();
            let key = garbage.record().key().clone();
            let payload = garbage.record().payload();
            writer.publish_unrooted(vec![garbage]).await.unwrap();
            drop(writer);
            crate::flush_repository_leases().await.unwrap();
            let plan = repository
                .collection_plan(
                    repository.coordination.clone().lock_owned().await,
                    None,
                    true,
                )
                .await
                .unwrap();
            assert_eq!(plan.preview.logical_objects, 1);
            // Deterministically place admission churn between mark and prune.
            let mut idle = Vec::new();
            for _ in 0..32 {
                idle.push(repository.mutation_session().await.unwrap());
            }
            if acquire_resource {
                idle[0]
                    .pin
                    .protect(BTreeSet::from([
                        crate::metadata::PinResource::Object(key.clone()),
                        crate::metadata::PinResource::Blob(payload),
                    ]))
                    .await
                    .unwrap();
            }
            let result = repository.execute_collection(plan, false).await;
            if acquire_resource {
                assert!(matches!(result, Err(RepositoryError::Busy(_))));
                assert!(repository.payloads().has(&payload).await.unwrap());
            } else {
                let result = result.unwrap();
                assert_eq!(result.removed.logical_objects, 1);
                assert_eq!(result.removed.payload_blobs, 1);
                assert!(!repository.payloads().has(&payload).await.unwrap());
            }
            drop(idle);
            crate::flush_repository_leases().await.unwrap();
        }
    }

    #[tokio::test]
    async fn logical_collection_admits_metadata_reads_registered_after_marking() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation
            .stage_blob(b"unreachable logical object")
            .await
            .unwrap();
        mutation.publish_unrooted(vec![object]).await.unwrap();
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        let plan = repository
            .logical_collection_plan(
                repository.coordination.clone().lock_owned().await,
                None,
                true,
            )
            .await
            .unwrap();
        let metadata = crate::metadata::DataPinLease::acquire(
            repository.metadata().pin_store().await.unwrap(),
            crate::metadata::DataPin {
                scope: crate::metadata::PinScope::Metadata,
                catalog: None,
                resources: BTreeSet::from([crate::metadata::PinResource::MetadataObject(
                    "checkpoint".into(),
                )]),
            },
        )
        .await
        .unwrap();
        assert_eq!(
            repository
                .execute_logical_collection(plan)
                .await
                .unwrap()
                .removed
                .logical_objects,
            1
        );
        assert!(
            repository
                .metadata()
                .pin_store()
                .await
                .unwrap()
                .inventory()
                .await
                .unwrap()
                .pins
                .contains_key(metadata.token())
        );
    }

    #[tokio::test]
    async fn logical_collection_rejects_a_pin_registered_after_marking() {
        use crate::metadata::{DataPin, DataPinLease, PinScope};

        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let held = mutation.stage_blob(b"late pin").await.unwrap();
        let key = held.record().key().clone();
        mutation.publish_unrooted(vec![held]).await.unwrap();
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        let plan = repository
            .logical_collection_plan(
                repository.coordination.clone().lock_owned().await,
                None,
                true,
            )
            .await
            .unwrap();
        assert_eq!(plan.preview.logical_objects, 1);
        let revision = plan.snapshot_revision;
        let pin = DataPinLease::acquire(
            repository.metadata().pin_store().await.unwrap(),
            DataPin {
                scope: PinScope::Closures(BTreeSet::from([key.clone()])),
                catalog: None,
                resources: BTreeSet::new(),
            },
        )
        .await
        .unwrap();
        assert!(matches!(
            repository.execute_logical_collection(plan).await,
            Err(RepositoryError::Busy(_))
        ));
        let snapshot = repository.metadata().snapshot().await.unwrap();
        assert_eq!(snapshot.revision(), revision);
        assert!(snapshot.object(&key).await.unwrap().is_some());
        drop(snapshot);
        drop(pin);
        crate::flush_repository_leases().await.unwrap();
        assert_eq!(
            repository
                .collect_logical()
                .await
                .unwrap()
                .removed
                .logical_objects,
            1
        );
    }

    #[tokio::test]
    async fn pin_marks_retain_selected_closures_and_tolerate_unpublished_inputs() {
        use crate::metadata::{DataPin, PinResource, PinScope};

        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let child = mutation.stage_blob(b"child").await.unwrap();
        let child_key = child.record().key().clone();
        let unrelated = mutation.stage_blob(b"unrelated").await.unwrap();
        let unrelated_key = unrelated.record().key().clone();
        let tree = mutation
            .stage_directory(
                &Directory::try_from_iter([(
                    PathComponent::try_from("child").unwrap(),
                    Node::File {
                        digest: BlobId::new(child_key.native_digest().unwrap()),
                        size: 5,
                        executable: false,
                    },
                )])
                .unwrap(),
            )
            .await
            .unwrap();
        let tree_key = tree.record().key().clone();
        mutation
            .publish_unrooted(vec![child, tree, unrelated])
            .await
            .unwrap();
        let absent = mutation.stage_blob(b"not yet published").await.unwrap();
        let absent_key = absent.record().key().clone();
        drop(absent);
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        let snapshot = repository.metadata().snapshot().await.unwrap();
        let ledger = repository.metadata().pin_store().await.unwrap();

        for pin in [
            DataPin {
                scope: PinScope::Closures(BTreeSet::from([tree_key.clone(), absent_key.clone()])),
                catalog: None,
                resources: BTreeSet::new(),
            },
            DataPin {
                scope: PinScope::Staging,
                catalog: None,
                resources: BTreeSet::from([
                    PinResource::Object(tree_key.clone()),
                    PinResource::Object(absent_key.clone()),
                ]),
            },
            DataPin {
                scope: PinScope::Snapshot {
                    generation: u64::MAX,
                },
                catalog: None,
                resources: BTreeSet::new(),
            },
        ] {
            let all = matches!(pin.scope, PinScope::Snapshot { .. });
            let token = ledger.register(pin).await.unwrap().unwrap();
            let area = repository.spill_area();
            let mut marked = mark_named_roots(snapshot.as_ref(), 100, &area)
                .await
                .unwrap();
            mark_pin_scopes(
                snapshot.as_ref(),
                &ledger.inventory().await.unwrap(),
                &mut marked,
                100,
                &area,
            )
            .await
            .unwrap();
            assert!(marked.contains(&tree_key).await.unwrap());
            assert!(marked.contains(&child_key).await.unwrap());
            assert!(!marked.contains(&absent_key).await.unwrap());
            assert_eq!(marked.contains(&unrelated_key).await.unwrap(), all);
            assert_eq!(marked.len(), if all { 3 } else { 2 });
            ledger.release(&token).await.unwrap();
        }
    }

    #[tokio::test]
    async fn selected_graph_hold_protects_all_roots_and_releases_unrelated_objects() {
        let repository = repository();
        let session = repository.mutation_session().await.unwrap();
        let first = session.stage_blob(b"first selected").await.unwrap();
        let second = session.stage_blob(b"second selected").await.unwrap();
        let garbage = session.stage_blob(b"unrelated").await.unwrap();
        let roots = BTreeSet::from([first.record().key().clone(), second.record().key().clone()]);
        session
            .publish_unrooted(vec![first, second, garbage])
            .await
            .unwrap();
        drop(session);
        let hold = repository.retention_hold_for(&roots).await.unwrap();
        crate::flush_repository_leases().await.unwrap();
        assert_eq!(
            repository
                .try_collect()
                .await
                .unwrap()
                .removed
                .logical_objects,
            1
        );
        for key in roots {
            assert!(hold.object(&key).await.unwrap().is_some());
            assert!(matches!(
                hold.verify_closure(&key).await.unwrap(),
                ClosureStatus::Complete { .. }
            ));
        }
        drop(hold);
        crate::flush_repository_leases().await.unwrap();
        assert_eq!(
            repository
                .try_collect()
                .await
                .unwrap()
                .removed
                .logical_objects,
            2
        );
    }

    #[tokio::test]
    async fn snapshot_admission_retries_when_metadata_files_change_at_the_same_revision() {
        struct RewritingMetadata {
            inner: MemoryMetadataStore,
            snapshots: AtomicUsize,
        }
        struct RewrittenSnapshot {
            inner: Arc<dyn MetadataSnapshot>,
            path: &'static str,
        }
        #[async_trait]
        impl MetadataSnapshot for RewrittenSnapshot {
            fn generation(&self) -> Result<u64, MetadataError> {
                self.inner.generation()
            }
            fn objects_created_through(
                &self,
                generation: u64,
            ) -> futures::stream::BoxStream<'static, Result<ObjectRecord, MetadataError>>
            {
                self.inner.objects_created_through(generation)
            }

            fn revision(&self) -> crate::RepositoryRevision {
                self.inner.revision()
            }
            fn retention_resources(&self) -> BTreeSet<crate::metadata::PinResource> {
                BTreeSet::from([crate::metadata::PinResource::MetadataObject(
                    self.path.into(),
                )])
            }
            async fn object(&self, key: &ObjectKey) -> Result<Option<ObjectRecord>, MetadataError> {
                self.inner.object(key).await
            }
            async fn root(&self, name: &RootName) -> Result<Option<ObjectKey>, MetadataError> {
                self.inner.root(name).await
            }
            fn objects(
                &self,
            ) -> futures::stream::BoxStream<'static, Result<ObjectRecord, MetadataError>>
            {
                self.inner.objects()
            }
            fn roots(
                &self,
            ) -> futures::stream::BoxStream<'static, Result<crate::RootRecord, MetadataError>>
            {
                self.inner.roots()
            }
        }
        #[async_trait]
        impl MetadataStore for RewritingMetadata {
            async fn pin_store(&self) -> Result<Arc<dyn crate::metadata::PinStore>, MetadataError> {
                self.inner.pin_store().await
            }
            async fn snapshot(&self) -> Result<Arc<dyn MetadataSnapshot>, MetadataError> {
                let call = self.snapshots.fetch_add(1, Ordering::SeqCst);
                Ok(Arc::new(RewrittenSnapshot {
                    inner: self.inner.snapshot().await?,
                    path: if call == 0 {
                        "old-shard"
                    } else {
                        "rewritten-shard"
                    },
                }))
            }
            async fn commit(
                &self,
                expected: &crate::RepositoryRevision,
                mutation: MetadataMutation,
            ) -> Result<CommitResult, MetadataError> {
                self.inner.commit(expected, mutation).await
            }
        }
        for (claimed, metadata_only) in [(false, false), (true, false), (false, true), (true, true)]
        {
            let repository = Repository::new(
                MemoryBlobStore::new(),
                RewritingMetadata {
                    inner: MemoryMetadataStore::new().unwrap(),
                    snapshots: AtomicUsize::new(0),
                },
            );
            let ledger = repository.metadata().pin_store().await.unwrap();
            let claim = if claimed {
                Some(
                    ledger
                        .claim_deletions(
                            ledger.inventory().await.unwrap().revision,
                            BTreeSet::from([crate::metadata::PinResource::MetadataObject(
                                "old-shard".into(),
                            )]),
                        )
                        .await
                        .unwrap()
                        .unwrap(),
                )
            } else {
                None
            };
            let (resources, _hold, _metadata_pin) =
                tokio::time::timeout(std::time::Duration::from_secs(2), async {
                    if metadata_only {
                        let (snapshot, pin) =
                            crate::metadata::read_snapshot(repository.metadata()).await?;
                        Ok::<_, MetadataError>((snapshot.retention_resources(), None, pin))
                    } else {
                        let hold = repository.retention_hold().await.unwrap();
                        Ok((hold.snapshot().retention_resources(), Some(hold), None))
                    }
                })
                .await
                .expect("admission must reload an obsolete claimed candidate")
                .unwrap();
            assert_eq!(
                repository.metadata().snapshots.load(Ordering::SeqCst),
                if claimed { 3 } else { 4 }
            );
            crate::metadata::flush_pin_releases().await;
            let inventory = repository
                .metadata()
                .pin_store()
                .await
                .unwrap()
                .inventory()
                .await
                .unwrap();
            assert_eq!(inventory.pins.len(), 1);
            if metadata_only {
                assert_eq!(
                    inventory.pins.values().next().unwrap().scope,
                    crate::metadata::PinScope::Metadata
                );
            }
            assert_eq!(inventory.pins.values().next().unwrap().resources, resources);
            assert!(inventory.pins.values().next().unwrap().resources.contains(
                &crate::metadata::PinResource::MetadataObject("rewritten-shard".into())
            ));
            if let Some(claim) = claim {
                assert!(inventory.deletions.contains_key(&claim));
                ledger.finish_deletions(&claim).await.unwrap();
            }
        }
    }

    #[tokio::test]
    async fn payload_readers_keep_snapshot_pins_after_both_hold_forms_are_dropped() {
        use tokio::io::AsyncSeekExt;

        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation.stage_blob(b"retained stream").await.unwrap();
        let key = object.record().key().clone();
        mutation
            .publish_rooted(
                vec![object],
                RootName::try_from("reader").unwrap(),
                key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        let ledger = repository.metadata().pin_store().await.unwrap();
        let revision = repository.metadata().snapshot().await.unwrap().revision();

        let borrowed = repository.retention_hold().await.unwrap();
        let owned = repository.owned_retention_hold().await.unwrap();
        let (_, mut first) = borrowed.open_payload(&key).await.unwrap().unwrap();
        let (_, mut second) = owned.open_payload(&key).await.unwrap().unwrap();
        drop(borrowed);
        drop(owned);
        crate::flush_repository_leases().await.unwrap();
        let inventory = ledger.inventory().await.unwrap();
        assert_eq!(inventory.pins.len(), 2);
        assert!(
            inventory
                .pins
                .values()
                .all(|pin| matches!(pin.scope, crate::metadata::PinScope::Snapshot { .. }))
        );
        assert_eq!(
            repository.metadata().snapshot().await.unwrap().revision(),
            revision
        );
        let mut bytes = Vec::new();
        first.read_to_end(&mut bytes).await.unwrap();
        assert_eq!(bytes, b"retained stream");
        second.seek(std::io::SeekFrom::Start(9)).await.unwrap();
        bytes.clear();
        second.read_to_end(&mut bytes).await.unwrap();
        assert_eq!(bytes, b"stream");
        drop(first);
        crate::flush_repository_leases().await.unwrap();
        assert_eq!(ledger.inventory().await.unwrap().pins.len(), 1);
        drop(second);
        crate::flush_repository_leases().await.unwrap();
        assert!(ledger.inventory().await.unwrap().pins.is_empty());
    }

    #[tokio::test]
    async fn mutation_session_registers_staged_bytes_in_the_shared_pin_ledger() {
        let repository = repository();
        let state = repository.metadata();
        let revision = state.snapshot().await.unwrap().revision();
        let ledger = state.pin_store().await.unwrap();
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation
            .stage_blob(b"pending importer bytes")
            .await
            .unwrap();
        let inventory = ledger.inventory().await.unwrap();
        assert_eq!(inventory.pins.len(), 1);
        assert!(inventory.pins.values().next().unwrap().resources.contains(
            &crate::metadata::PinResource::Blob(object.record().payload()),
        ));
        assert_eq!(state.snapshot().await.unwrap().revision(), revision);
        drop(object);
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        assert!(ledger.inventory().await.unwrap().pins.is_empty());
    }

    #[tokio::test]
    async fn publishes_payload_record_and_root_atomically() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation.stage_blob(b"hello").await.unwrap();
        let key = object.record().key().clone();
        mutation
            .publish_rooted(
                vec![object],
                RootName::try_from("profiles/main").unwrap(),
                key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);

        assert!(matches!(
            repository.verify_closure(&key).await.unwrap(),
            ClosureStatus::Complete { .. }
        ));
    }

    /// The point of the shortcut: naming a graph that overlaps one already
    /// verified must only re-read the part that is new.
    #[tokio::test]
    async fn an_incremental_walk_stops_at_an_already_verified_closure() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let mut staged = Vec::new();
        let mut entries = Vec::new();
        for index in 0..4u8 {
            let blob = mutation.stage_blob(&[index; 32]).await.unwrap();
            entries.push((
                PathComponent::try_from(format!("file{index}").as_str()).unwrap(),
                Node::File {
                    digest: BlobId::new(blob.record().key().native_digest().unwrap()),
                    size: 32,
                    executable: false,
                },
            ));
            staged.push(blob);
        }
        let directory = Directory::try_from_iter(entries).unwrap();
        let tree = mutation.stage_directory(&directory).await.unwrap();
        let tree_key = tree.record().key().clone();
        staged.push(tree);
        mutation
            .publish_rooted(
                staged,
                RootName::try_from("profiles/first").unwrap(),
                tree_key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);

        let hold = repository.retention_hold().await.unwrap();
        // An audit reads the directory and all four blobs, every time.
        assert!(matches!(
            hold.verify_closure(&tree_key).await.unwrap(),
            ClosureStatus::Complete { objects: 5 }
        ));
        // Verified once, so an incremental walk stops at the root and never
        // descends into what it already vouched for.
        assert!(matches!(
            hold.verify_closure_incremental(&tree_key).await.unwrap(),
            ClosureStatus::Complete { objects: 1 }
        ));
        let owned = repository.owned_retention_hold().await.unwrap();
        assert!(matches!(
            owned.verify_closure(&tree_key).await.unwrap(),
            ClosureStatus::Complete { objects: 5 }
        ));
        assert!(matches!(
            owned.verify_closure_incremental(&tree_key).await.unwrap(),
            ClosureStatus::Complete { objects: 1 }
        ));
    }

    /// The shortcut must never let an incomplete graph acquire a name, and a
    /// mark must never outlive the object it vouches for.
    #[tokio::test]
    async fn an_incremental_walk_still_reports_an_absent_object() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation.stage_blob(b"collected later").await.unwrap();
        let key = object.record().key().clone();
        let name = RootName::try_from("profiles/temporary").unwrap();
        mutation
            .publish_rooted(vec![object], name.clone(), key.clone())
            .await
            .unwrap();
        drop(mutation);

        // Unnamed and collected, the object is gone and so is its mark.
        repository
            .mutation_session()
            .await
            .unwrap()
            .remove_root_if_matches(&name, &key)
            .await
            .unwrap()
            .unwrap();
        repository.collect().await.unwrap();

        assert!(matches!(
            repository.verify_closure_incremental(&key).await.unwrap(),
            ClosureStatus::Missing { .. }
        ));
    }

    #[tokio::test]
    async fn publication_revalidates_and_retries_a_revision_race() {
        let state = StaleOnceMetadataStore {
            inner: MemoryMetadataStore::new().unwrap(),
            stale_once: Arc::new(AtomicBool::new(true)),
        };
        let repository = Repository::new(MemoryBlobStore::new(), state);
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation.stage_blob(b"race-safe").await.unwrap();
        let key = object.record().key().clone();
        mutation
            .publish_rooted(
                vec![object],
                RootName::try_from("roots/raced").unwrap(),
                key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);

        assert!(matches!(
            repository.verify_closure(&key).await.unwrap(),
            ClosureStatus::Complete { .. }
        ));
    }

    #[tokio::test]
    async fn conditional_publication_creates_and_repoints_a_matching_root() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let name = RootName::try_from("replicated/workspace").unwrap();

        let first = mutation.stage_blob(b"first frontier").await.unwrap();
        let first_key = first.record().key().clone();
        let first_result = mutation
            .publish_if_roots_match(
                vec![first],
                vec![RootExpectation {
                    name: name.clone(),
                    target: None,
                }],
                vec![RootChange::Set {
                    name: name.clone(),
                    target: first_key.clone(),
                }],
            )
            .await
            .unwrap();
        assert!(matches!(
            first_result,
            ConditionalPublishResult::Committed(CommitResult {
                objects_inserted: 1,
                roots_changed: 1,
                ..
            })
        ));

        let second = mutation.stage_blob(b"second frontier").await.unwrap();
        let second_key = second.record().key().clone();
        let second_result = mutation
            .publish_if_roots_match(
                vec![second],
                vec![RootExpectation {
                    name: name.clone(),
                    target: Some(first_key),
                }],
                vec![RootChange::Set {
                    name: name.clone(),
                    target: second_key.clone(),
                }],
            )
            .await
            .unwrap();
        assert!(matches!(
            second_result,
            ConditionalPublishResult::Committed(CommitResult {
                objects_inserted: 1,
                roots_changed: 1,
                ..
            })
        ));
        assert_eq!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .root(&name)
                .await
                .unwrap(),
            Some(second_key)
        );
    }

    #[tokio::test]
    async fn conditional_root_mismatch_publishes_nothing() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let name = RootName::try_from("replicated/workspace").unwrap();
        let current = mutation.stage_blob(b"current frontier").await.unwrap();
        let current_key = current.record().key().clone();
        mutation
            .publish_rooted(vec![current], name.clone(), current_key.clone())
            .await
            .unwrap();

        let candidate = mutation.stage_blob(b"candidate frontier").await.unwrap();
        let candidate_key = candidate.record().key().clone();
        let candidate_payload = candidate.record().payload();
        let before = repository.metadata().snapshot().await.unwrap().revision();
        let wrong = ObjectKey::blob(BlobId::new(Digest::hash(b"wrong frontier")));
        let result = mutation
            .publish_if_roots_match(
                vec![candidate],
                vec![RootExpectation {
                    name: name.clone(),
                    target: Some(wrong.clone()),
                }],
                vec![RootChange::Set {
                    name: name.clone(),
                    target: candidate_key.clone(),
                }],
            )
            .await
            .unwrap();
        assert_eq!(
            result,
            ConditionalPublishResult::RootMismatch {
                name: name.clone(),
                expected: Some(wrong),
                actual: Some(current_key.clone()),
            }
        );

        let after = repository.metadata().snapshot().await.unwrap();
        assert_eq!(after.revision(), before);
        assert_eq!(after.root(&name).await.unwrap(), Some(current_key));
        assert!(after.object(&candidate_key).await.unwrap().is_none());
        assert!(repository.payloads().has(&candidate_payload).await.unwrap());
        drop(after);
        drop(mutation);
        repository.collect().await.unwrap();
        assert!(!repository.payloads().has(&candidate_payload).await.unwrap());
    }

    #[tokio::test]
    async fn conditional_publication_checks_multiple_roots_atomically() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let first_name = RootName::try_from("replicated/a").unwrap();
        let second_name = RootName::try_from("replicated/z").unwrap();
        let current = mutation.stage_blob(b"current frontier").await.unwrap();
        let current_key = current.record().key().clone();
        mutation
            .publish_rooted(vec![current], first_name.clone(), current_key.clone())
            .await
            .unwrap();

        let first_candidate = mutation.stage_blob(b"first candidate").await.unwrap();
        let first_candidate_key = first_candidate.record().key().clone();
        let second_candidate = mutation.stage_blob(b"second candidate").await.unwrap();
        let second_candidate_key = second_candidate.record().key().clone();
        let wrong = ObjectKey::blob(BlobId::new(Digest::hash(b"wrong frontier")));
        let before = repository.metadata().snapshot().await.unwrap().revision();
        let result = mutation
            .publish_if_roots_match(
                vec![first_candidate, second_candidate],
                vec![
                    RootExpectation {
                        name: second_name.clone(),
                        target: None,
                    },
                    RootExpectation {
                        name: first_name.clone(),
                        target: Some(wrong.clone()),
                    },
                ],
                vec![
                    RootChange::Set {
                        name: first_name.clone(),
                        target: first_candidate_key.clone(),
                    },
                    RootChange::Set {
                        name: second_name.clone(),
                        target: second_candidate_key.clone(),
                    },
                ],
            )
            .await
            .unwrap();
        assert_eq!(
            result,
            ConditionalPublishResult::RootMismatch {
                name: first_name.clone(),
                expected: Some(wrong),
                actual: Some(current_key.clone()),
            }
        );

        let after = repository.metadata().snapshot().await.unwrap();
        assert_eq!(after.revision(), before);
        assert_eq!(after.root(&first_name).await.unwrap(), Some(current_key));
        assert_eq!(after.root(&second_name).await.unwrap(), None);
        assert!(after.object(&first_candidate_key).await.unwrap().is_none());
        assert!(after.object(&second_candidate_key).await.unwrap().is_none());
    }

    #[tokio::test]
    async fn conditional_publication_retries_an_unrelated_revision_race() {
        let state = StaleOnceMetadataStore {
            inner: MemoryMetadataStore::new().unwrap(),
            stale_once: Arc::new(AtomicBool::new(true)),
        };
        let repository = Repository::new(MemoryBlobStore::new(), state);
        let mutation = repository.mutation_session().await.unwrap();
        let name = RootName::try_from("replicated/workspace").unwrap();
        let object = mutation.stage_blob(b"race-safe frontier").await.unwrap();
        let key = object.record().key().clone();

        let result = mutation
            .publish_if_roots_match(
                vec![object],
                vec![RootExpectation {
                    name: name.clone(),
                    target: None,
                }],
                vec![RootChange::Set {
                    name: name.clone(),
                    target: key.clone(),
                }],
            )
            .await
            .unwrap();
        assert!(matches!(result, ConditionalPublishResult::Committed(_)));
        assert_eq!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .root(&name)
                .await
                .unwrap(),
            Some(key)
        );
    }

    #[tokio::test]
    async fn conditional_publication_reports_a_concurrent_root_change() {
        #[derive(Clone)]
        struct RepointOnceMetadataStore {
            inner: MemoryMetadataStore,
            competing: Arc<std::sync::RwLock<Option<(RootName, ObjectKey)>>>,
        }

        #[async_trait]
        impl MetadataStore for RepointOnceMetadataStore {
            async fn pin_store(
                &self,
            ) -> Result<std::sync::Arc<dyn crate::metadata::PinStore>, crate::metadata::MetadataError>
            {
                self.inner.pin_store().await
            }

            async fn snapshot(&self) -> Result<Arc<dyn MetadataSnapshot>, MetadataError> {
                self.inner.snapshot().await
            }

            async fn commit(
                &self,
                expected: &crate::RepositoryRevision,
                mutation: MetadataMutation,
            ) -> Result<CommitResult, MetadataError> {
                let competing = self
                    .competing
                    .write()
                    .map_err(|_| MetadataError::Poisoned)?
                    .take();
                if let Some((name, target)) = competing {
                    let mut repoint = MetadataMutation::new();
                    repoint.set_root(name, target);
                    let competing = self.inner.commit(expected, repoint).await?;
                    return Err(MetadataError::StaleRevision {
                        expected: *expected,
                        actual: competing.revision,
                    });
                }
                self.inner.commit(expected, mutation).await
            }
        }

        let competing = Arc::new(std::sync::RwLock::new(None));
        let state = RepointOnceMetadataStore {
            inner: MemoryMetadataStore::new().unwrap(),
            competing: competing.clone(),
        };
        let repository = Repository::new(MemoryBlobStore::new(), state);
        let mutation = repository.mutation_session().await.unwrap();
        let name = RootName::try_from("replicated/workspace").unwrap();

        let current = mutation.stage_blob(b"current frontier").await.unwrap();
        let current_key = current.record().key().clone();
        let concurrent = mutation.stage_blob(b"concurrent frontier").await.unwrap();
        let concurrent_key = concurrent.record().key().clone();
        mutation
            .publish(
                vec![current, concurrent],
                vec![RootChange::Set {
                    name: name.clone(),
                    target: current_key.clone(),
                }],
            )
            .await
            .unwrap();

        let candidate = mutation
            .stage_blob(b"stale derived frontier")
            .await
            .unwrap();
        let candidate_key = candidate.record().key().clone();
        *competing.write().unwrap() = Some((name.clone(), concurrent_key.clone()));
        let result = mutation
            .publish_if_roots_match(
                vec![candidate],
                vec![RootExpectation {
                    name: name.clone(),
                    target: Some(current_key.clone()),
                }],
                vec![RootChange::Set {
                    name: name.clone(),
                    target: candidate_key.clone(),
                }],
            )
            .await
            .unwrap();
        assert_eq!(
            result,
            ConditionalPublishResult::RootMismatch {
                name: name.clone(),
                expected: Some(current_key),
                actual: Some(concurrent_key.clone()),
            }
        );
        let snapshot = repository.metadata().snapshot().await.unwrap();
        assert_eq!(snapshot.root(&name).await.unwrap(), Some(concurrent_key));
        assert!(snapshot.object(&candidate_key).await.unwrap().is_none());
    }

    #[tokio::test]
    async fn conditional_publication_rejects_duplicate_expectations() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let name = RootName::try_from("replicated/workspace").unwrap();
        let error = mutation
            .publish_if_roots_match(
                Vec::new(),
                vec![
                    RootExpectation {
                        name: name.clone(),
                        target: None,
                    },
                    RootExpectation { name, target: None },
                ],
                Vec::new(),
            )
            .await
            .unwrap_err();
        assert!(matches!(error, RepositoryError::InvalidInput(_)));
    }

    #[tokio::test]
    async fn root_release_is_an_exact_compare_and_remove() {
        let repository = repository();
        let name = RootName::try_from("services/cache").unwrap();
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation.stage_blob(b"owned").await.unwrap();
        let key = object.record().key().clone();
        mutation
            .publish_rooted(vec![object], name.clone(), key.clone())
            .await
            .unwrap();
        drop(mutation);

        let wrong = ObjectKey::blob(BlobId::new(Digest::hash(b"wrong")));
        assert!(
            repository
                .remove_root_if_matches(&name, &wrong)
                .await
                .unwrap()
                .is_none()
        );
        assert_eq!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .root(&name)
                .await
                .unwrap(),
            Some(key.clone())
        );
        assert!(
            repository
                .remove_root_if_matches(&name, &key)
                .await
                .unwrap()
                .is_some()
        );
        assert!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .root(&name)
                .await
                .unwrap()
                .is_none()
        );
    }

    #[tokio::test]
    async fn nonblocking_collection_runs_under_a_live_mutation() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        repository.try_collect().await.unwrap();
        drop(mutation);
        repository.try_collect().await.unwrap();
    }

    #[tokio::test]
    async fn mutation_start_runs_before_staging_pin_admission() {
        let mut repository = repository();
        let calls = Arc::new(AtomicUsize::new(0));
        repository.mutation_start = Some(Arc::new(CollectOnMutationStart {
            repository: repository.clone(),
            calls: calls.clone(),
        }));

        let mutation = repository.mutation_session().await.unwrap();
        assert_eq!(calls.load(Ordering::SeqCst), 1);
        repository.try_collect().await.unwrap();
        drop(mutation);
    }

    #[tokio::test]
    async fn later_leaf_completes_graph_without_rewriting_parent() {
        let repository = repository();
        let child_bytes = b"arrives later";
        let child_id = BlobId::new(Digest::hash(child_bytes));
        let parent = Directory::try_from_iter([(
            pc("child"),
            Node::File {
                digest: child_id,
                size: child_bytes.len() as u64,
                executable: false,
            },
        )])
        .unwrap();
        let parent_key = ObjectKey::directory(parent.digest());

        let mutation = repository.mutation_session().await.unwrap();
        let staged_parent = mutation.stage_directory(&parent).await.unwrap();
        mutation
            .publish_unrooted(vec![staged_parent])
            .await
            .unwrap();
        let error = mutation
            .publish_rooted(
                Vec::new(),
                RootName::try_from("tree").unwrap(),
                parent_key.clone(),
            )
            .await
            .unwrap_err();
        assert!(matches!(
            error,
            RepositoryError::RootNotPublishable {
                status: ClosureStatus::Missing { .. },
                ..
            }
        ));

        let child = mutation.stage_blob(child_bytes).await.unwrap();
        mutation
            .publish_rooted(
                vec![child],
                RootName::try_from("tree").unwrap(),
                parent_key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);
        assert!(matches!(
            repository.verify_closure(&parent_key).await.unwrap(),
            ClosureStatus::Complete { .. }
        ));
    }

    #[tokio::test]
    async fn generic_closure_handles_cycles_and_high_fanout() {
        let repository = graph_repository();
        let mutation = repository.mutation_session().await.unwrap();
        let a = stage_graph(&mutation, 1, &[2]).await;
        let a_key = a.record().key().clone();
        let b = stage_graph(&mutation, 2, &[1]).await;
        mutation
            .publish_rooted(
                vec![a, b],
                RootName::try_from("cycles/main").unwrap(),
                a_key.clone(),
            )
            .await
            .unwrap();
        assert!(matches!(
            mutation
                .repository
                .verify_closure(&a_key)
                .await
                .unwrap(),
            ClosureStatus::Complete { objects } if objects == 2
        ));
        drop(mutation);

        let repository = graph_repository();
        let mutation = repository.mutation_session().await.unwrap();
        let mut staged = Vec::new();
        for native in 0..200u8 {
            staged.push(stage_graph(&mutation, native, &[]).await);
        }
        let root = stage_graph(&mutation, 250, &(0..200u8).collect::<Vec<_>>()).await;
        let root_key = root.record().key().clone();
        staged.push(root);
        mutation
            .publish_rooted(
                staged,
                RootName::try_from("fanout/main").unwrap(),
                root_key.clone(),
            )
            .await
            .unwrap();
        assert!(matches!(
            mutation
                .repository
                .verify_closure(&root_key)
                .await
                .unwrap(),
            ClosureStatus::Complete { objects } if objects == 201
        ));
    }

    #[tokio::test]
    async fn immutable_conflict_is_distinct_from_idempotent_reinsertion() {
        let repository = graph_repository();
        let mutation = repository.mutation_session().await.unwrap();
        let first = stage_graph(&mutation, 1, &[]).await;
        mutation.publish_unrooted(vec![first]).await.unwrap();
        let identical = stage_graph(&mutation, 1, &[]).await;
        let outcome = mutation.publish_unrooted(vec![identical]).await.unwrap();
        assert_eq!(outcome.objects_inserted, 0);

        let conflict = stage_graph(&mutation, 1, &[2]).await;
        assert!(matches!(
            mutation.publish_unrooted(vec![conflict]).await,
            Err(RepositoryError::Metadata(MetadataError::ImmutableConflict(
                _
            )))
        ));
    }

    #[tokio::test]
    async fn unavailable_namespace_remains_conservatively_collectable() {
        let repository = graph_repository();
        let mutation = repository.mutation_session().await.unwrap();
        let child = stage_graph(&mutation, 1, &[]).await;
        let root = stage_graph(&mutation, 2, &[1]).await;
        let root_key = root.record().key().clone();
        mutation
            .publish_rooted(
                vec![child, root],
                RootName::try_from("graphs/main").unwrap(),
                root_key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);

        let without_format = Repository::with_formats(
            repository.payloads().clone(),
            repository.metadata().clone(),
            FormatRegistry::new(Vec::<Arc<dyn ObjectFormat>>::new()).unwrap(),
            FormatLimits::default(),
        );
        assert!(matches!(
            without_format.verify_closure(&root_key).await.unwrap(),
            ClosureStatus::Unsupported { .. }
        ));
        let outcome = without_format.collect().await.unwrap();
        assert_eq!(outcome.removed.logical_objects, 0);
        let snapshot = without_format.metadata().snapshot().await.unwrap();
        assert_eq!(
            snapshot
                .objects()
                .try_collect::<Vec<_>>()
                .await
                .unwrap()
                .len(),
            2
        );
    }

    #[tokio::test]
    async fn direct_relation_mismatch_prevents_root_publication() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let child = mutation.stage_blob(b"four").await.unwrap();
        let child_id = child.record().payload();
        let parent = Directory::try_from_iter([(
            pc("child"),
            Node::File {
                digest: child_id,
                size: 99,
                executable: false,
            },
        )])
        .unwrap();
        let parent_key = ObjectKey::directory(parent.digest());
        let parent = mutation.stage_directory(&parent).await.unwrap();
        let error = mutation
            .publish_rooted(
                vec![child, parent],
                RootName::try_from("tree").unwrap(),
                parent_key,
            )
            .await
            .unwrap_err();
        assert!(matches!(
            error,
            RepositoryError::RootNotPublishable {
                status: ClosureStatus::Invalid { .. },
                ..
            }
        ));
    }

    #[tokio::test]
    async fn generic_collection_prunes_logical_and_physical_orphans() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let live = mutation.stage_blob(b"live").await.unwrap();
        let live_key = live.record().key().clone();
        let live_payload = live.record().payload();
        let orphan = mutation.stage_blob(b"orphan").await.unwrap();
        let orphan_key = orphan.record().key().clone();
        let orphan_payload = orphan.record().payload();
        mutation
            .publish_rooted(
                vec![live, orphan],
                RootName::try_from("live").unwrap(),
                live_key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);

        let preview = repository.preview_collection().await.unwrap();
        assert_eq!(preview.logical_objects, 1);
        assert_eq!(preview.payload_blobs, 1);
        let outcome = repository.collect().await.unwrap();
        assert_eq!(outcome.removed, preview);

        let snapshot = repository.metadata().snapshot().await.unwrap();
        assert!(snapshot.object(&live_key).await.unwrap().is_some());
        assert!(snapshot.object(&orphan_key).await.unwrap().is_none());
        assert!(repository.payloads().has(&live_payload).await.unwrap());
        assert!(!repository.payloads().has(&orphan_payload).await.unwrap());
    }

    #[tokio::test]
    async fn logical_collection_prunes_one_tenant_without_deleting_a_shared_blob() {
        let payloads = SharedBlobStore {
            inner: MemoryBlobStore::new(),
        };
        let tenant_a = Repository::new(payloads.clone(), MemoryMetadataStore::new().unwrap());
        let tenant_b = Repository::new(payloads.clone(), MemoryMetadataStore::new().unwrap());

        let mutation_a = tenant_a.mutation_session().await.unwrap();
        let shared = mutation_a
            .stage_blob(b"shared across tenants")
            .await
            .unwrap();
        let shared_key = shared.record().key().clone();
        let shared_payload = shared.record().payload();
        mutation_a.publish_unrooted(vec![shared]).await.unwrap();
        drop(mutation_a);

        let mutation_b = tenant_b.mutation_session().await.unwrap();
        let shared_for_b = mutation_b
            .stage_existing(shared_key.clone(), shared_payload)
            .await
            .unwrap();
        mutation_b
            .publish_rooted(
                vec![shared_for_b],
                RootName::try_from("inputs/source").unwrap(),
                shared_key.clone(),
            )
            .await
            .unwrap();
        drop(mutation_b);

        assert_eq!(
            tenant_a.preview_logical_collection().await.unwrap(),
            LogicalCollectionPreview { logical_objects: 1 }
        );
        let outcome = tenant_a.collect_logical().await.unwrap();
        assert_eq!(outcome.removed.logical_objects, 1);
        assert!(outcome.revision.is_some());
        assert!(
            tenant_a
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .object(&shared_key)
                .await
                .unwrap()
                .is_none()
        );

        // The byte remains readable because physical lifetime is not owned by
        // tenant A's logical collection. A remote backend's aggregate ledger
        // may reclaim it only after tenant B releases it too.
        assert!(payloads.has(&shared_payload).await.unwrap());
        assert!(matches!(
            tenant_b.verify_closure(&shared_key).await.unwrap(),
            ClosureStatus::Complete { objects: 1 }
        ));
    }

    #[tokio::test]
    async fn borrowed_and_owned_holds_independently_retain_their_snapshot() {
        for drop_owned_first in [false, true] {
            let directory = tempfile::tempdir().unwrap();
            let repository = Repository::local(directory.path()).await.unwrap();
            let name = RootName::try_from("held/root").unwrap();
            let bytes = b"protected by either hold";
            let mutation = repository.mutation_session().await.unwrap();
            let staged = mutation.stage_blob(bytes).await.unwrap();
            let record = staged.record().clone();
            let key = record.key().clone();
            mutation
                .publish_rooted(vec![staged], name.clone(), key.clone())
                .await
                .unwrap();
            drop(mutation);

            // Opening a local handle takes exclusive initialization ownership.
            let collector = Repository::local(directory.path()).await.unwrap();
            let borrowed = repository.retention_hold().await.unwrap();
            let owned = repository.owned_retention_hold().await.unwrap();
            let revision = borrowed.snapshot().revision();
            assert_eq!(owned.snapshot().revision(), revision);
            for found in [
                borrowed.object(&key).await.unwrap(),
                owned.object(&key).await.unwrap(),
            ] {
                assert_eq!(found, Some(record.clone()));
            }

            collector
                .remove_root_if_matches(&name, &key)
                .await
                .unwrap()
                .unwrap();
            assert_ne!(
                collector.metadata().snapshot().await.unwrap().revision(),
                revision
            );
            for snapshot in [borrowed.snapshot(), owned.snapshot()] {
                assert_eq!(snapshot.root(&name).await.unwrap(), Some(key.clone()));
            }
            assert_eq!(
                collector
                    .try_collect()
                    .await
                    .unwrap()
                    .removed
                    .logical_objects,
                0
            );

            if drop_owned_first {
                drop(owned);
                assert_eq!(
                    collector
                        .try_collect()
                        .await
                        .unwrap()
                        .removed
                        .logical_objects,
                    0
                );
                let (_, mut reader) = borrowed.open_payload(&key).await.unwrap().unwrap();
                let mut actual = Vec::new();
                reader.read_to_end(&mut actual).await.unwrap();
                assert_eq!(actual, bytes);
                drop(reader);
                drop(borrowed);
            } else {
                drop(borrowed);
                drop(repository);
                assert_eq!(
                    collector
                        .try_collect()
                        .await
                        .unwrap()
                        .removed
                        .logical_objects,
                    0
                );
                let (_, mut reader) = owned.open_payload(&key).await.unwrap().unwrap();
                let mut actual = Vec::new();
                reader.read_to_end(&mut actual).await.unwrap();
                assert_eq!(actual, bytes);
                drop(reader);
                drop(owned);
            }
            // Both read pins are gone, so an independent handle can reclaim
            // the now-unrooted object and its physical payload.
            let outcome = collector.try_collect().await.unwrap();
            assert_eq!(outcome.removed.logical_objects, 1);
            assert!(
                collector
                    .metadata()
                    .snapshot()
                    .await
                    .unwrap()
                    .object(&key)
                    .await
                    .unwrap()
                    .is_none()
            );
        }
    }

    #[tokio::test]
    async fn nonblocking_logical_collection_respects_a_retention_hold() {
        let repository = Repository::new(
            SharedBlobStore {
                inner: MemoryBlobStore::new(),
            },
            MemoryMetadataStore::new().unwrap(),
        );
        let hold = repository.retention_hold().await.unwrap();
        assert_eq!(
            repository
                .try_collect_logical()
                .await
                .unwrap()
                .removed
                .logical_objects,
            0
        );
        drop(hold);
        assert!(repository.try_collect_logical().await.is_ok());
    }

    #[tokio::test]
    async fn existing_payload_pin_preserves_chunks_during_an_older_sweep() {
        let repository = chunked_repository(1024);
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation.stage_blob(&[1; 4096]).await.unwrap();
        let key = object.record().key().clone();
        let payload = object.record().payload();
        let unrelated = mutation.stage_blob(&[2; 4096]).await.unwrap();
        let unrelated_payload = unrelated.record().payload();
        drop((object, unrelated));
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        let plan = repository
            .collection_plan(
                repository.coordination.clone().lock_owned().await,
                None,
                true,
            )
            .await
            .unwrap();
        assert_eq!(plan.preview.payload_blobs, 2);
        assert_eq!(plan.preview.chunks, 2);
        let writer = Repository::new(repository.payloads().clone(), repository.metadata().clone());
        let mutation = writer.mutation_session().await.unwrap();
        let object = mutation.stage_existing(key.clone(), payload).await.unwrap();
        mutation
            .publish_rooted(
                vec![object],
                RootName::try_from("reused").unwrap(),
                key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);
        crate::metadata::flush_pin_releases().await;
        let outcome = repository.execute_collection(plan, false).await.unwrap();
        assert_eq!(outcome.removed.payload_blobs, 1);
        assert_eq!(outcome.removed.chunks, 1);
        assert!(!repository.payloads().has(&unrelated_payload).await.unwrap());
        let mut reader = repository
            .payloads()
            .open_read(&payload)
            .await
            .unwrap()
            .unwrap();
        let mut bytes = Vec::new();
        reader.read_to_end(&mut bytes).await.unwrap();
        assert_eq!(bytes, &[1; 4096]);
        crate::flush_repository_leases().await.unwrap();
    }

    async fn assert_writer_pin_isolation<PS: BlobGc + Clone + 'static>(payloads: PS) {
        let repository = Repository::new(payloads, MemoryMetadataStore::new().unwrap());
        let first = repository.mutation_session().await.unwrap();
        let held = first.stage_blob(&[21; 4096]).await.unwrap();
        let held_payload = held.record().payload();
        let second = repository.mutation_session().await.unwrap();
        let garbage = second.stage_blob(&[22; 4096]).await.unwrap();
        let garbage_payload = garbage.record().payload();
        second.publish_unrooted(vec![garbage]).await.unwrap();
        drop(second);
        crate::metadata::flush_pin_releases().await;
        let inventory = repository
            .metadata()
            .pin_store()
            .await
            .unwrap()
            .inventory()
            .await
            .unwrap();
        let first_resources = &inventory.pins[first.pin.token()].resources;
        assert!(first_resources.contains(&crate::metadata::PinResource::Blob(held_payload)));
        assert!(
            !first_resources.contains(&crate::metadata::PinResource::Blob(garbage_payload)),
            "an idle session must not acquire another writer's payload"
        );
        // Independent facade shares storage and pins while avoiding the old
        // process-wide guard, which is still present during this transition.
        let collector =
            Repository::new(repository.payloads().clone(), repository.metadata().clone());
        let collected = collector.collect().await.unwrap();
        assert_eq!(collected.removed.logical_objects, 1);
        assert_eq!(collected.removed.payload_blobs, 1);
        assert!(!repository.payloads().has(&garbage_payload).await.unwrap());
        assert!(repository.payloads().has(&held_payload).await.unwrap());
        drop(held);
        drop(first);
        crate::flush_repository_leases().await.unwrap();
        collector.collect().await.unwrap();
        assert!(!repository.payloads().has(&held_payload).await.unwrap());
    }

    #[tokio::test]
    async fn post_prune_snapshot_reader_can_enter_during_physical_sweep() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let live = mutation.stage_blob(b"live during sweep").await.unwrap();
        let live_key = live.record().key().clone();
        let garbage = mutation.stage_blob(b"old unrooted record").await.unwrap();
        let garbage_key = garbage.record().key().clone();
        let garbage_payload = garbage.record().payload();
        mutation
            .publish(
                vec![live, garbage],
                vec![RootChange::Set {
                    name: "live".parse().unwrap(),
                    target: live_key.clone(),
                }],
            )
            .await
            .unwrap();
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        let plan = repository
            .collection_plan(
                repository.coordination.clone().lock_owned().await,
                None,
                true,
            )
            .await
            .unwrap();
        repository
            .publication
            .prune(
                plan.logical.protection.clone(),
                plan.logical.snapshot_revision,
                plan.logical.pins.clone(),
                BTreeSet::new(),
                None,
                MetadataMutation::install_retained_source(plan.logical.live_objects.clone()),
            )
            .await
            .unwrap();
        let ledger = repository.metadata().pin_store().await.unwrap();
        let claim = ledger
            .claim_deletions(
                ledger.inventory().await.unwrap().revision,
                BTreeSet::from([crate::metadata::PinResource::Blob(garbage_payload)]),
            )
            .await
            .unwrap()
            .unwrap();
        let reader = Repository::new(repository.payloads().clone(), repository.metadata().clone());
        let hold = tokio::time::timeout(Duration::from_secs(2), reader.retention_hold())
            .await
            .unwrap()
            .unwrap();
        assert!(
            hold.snapshot()
                .object(&garbage_key)
                .await
                .unwrap()
                .is_none()
        );
        assert!(hold.snapshot().object(&live_key).await.unwrap().is_some());
        assert!(matches!(
            hold.verify_closure(&live_key).await.unwrap(),
            ClosureStatus::Complete { .. }
        ));
        assert!(
            ledger
                .inventory()
                .await
                .unwrap()
                .deletions
                .contains_key(&claim)
        );
        drop(hold);
        crate::metadata::flush_pin_releases().await;
        ledger.finish_deletions(&claim).await.unwrap();
        plan.logical.protection.collector.finish().await.unwrap();
        drop(plan);
        crate::flush_repository_leases().await.unwrap();
        repository.collect().await.unwrap();
        assert!(!repository.payloads().has(&garbage_payload).await.unwrap());
    }

    #[tokio::test]
    async fn mutation_sessions_only_pin_their_own_writes() {
        assert_writer_pin_isolation(MemoryBlobStore::new()).await;
        assert_writer_pin_isolation(chunked_repository(1024).payloads().clone()).await;
        let packed = ChunkedBlobStore::new_packed(
            Arc::new(object_store::memory::InMemory::new()),
            object_store::path::Path::default(),
            1024,
            u64::MAX,
        )
        .await
        .unwrap();
        assert_writer_pin_isolation(packed).await;
    }

    #[tokio::test]
    async fn completed_writer_cannot_disappear_from_an_older_collection_mark() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let orphan = mutation
            .stage_blob(b"published during collection")
            .await
            .unwrap();
        let payload = orphan.record().payload();
        let unrelated = mutation.stage_blob(b"unrelated garbage").await.unwrap();
        let unrelated_payload = unrelated.record().payload();
        drop(unrelated);
        drop(orphan);
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        let plan = repository
            .collection_plan(
                repository.coordination.clone().lock_owned().await,
                None,
                true,
            )
            .await
            .unwrap();
        assert_eq!(plan.preview.payload_blobs, 2);
        assert_eq!(plan.preview.logical_objects, 0);
        // Independent facade: its generic metadata/backend handles share the
        // durable ledger, not this collector's legacy in-process guard.
        let writer = Repository::new(repository.payloads().clone(), repository.metadata().clone());
        let mutation = writer.mutation_session().await.unwrap();
        let object = mutation
            .stage_blob(b"published during collection")
            .await
            .unwrap();
        let key = object.record().key().clone();
        mutation
            .publish_rooted(
                vec![object],
                RootName::try_from("new-root").unwrap(),
                key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);
        crate::metadata::flush_pin_releases().await;
        let ledger = repository.metadata().pin_store().await.unwrap();
        let inventory = ledger.inventory().await.unwrap();
        assert!(!inventory.retired.is_empty());
        assert!(inventory.pins.values().any(|pin| {
            pin.resources
                .contains(&crate::metadata::PinResource::Blob(payload))
        }));
        let outcome = repository.execute_collection(plan, false).await.unwrap();
        assert_eq!(outcome.removed.payload_blobs, 1);
        assert_eq!(outcome.removed.logical_objects, 0);
        assert!(!repository.payloads().has(&unrelated_payload).await.unwrap());
        crate::flush_repository_leases().await.unwrap();
        assert!(repository.payloads().has(&payload).await.unwrap());
        assert!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .object(&key)
                .await
                .unwrap()
                .is_some()
        );
        repository.collect().await.unwrap();
        assert!(repository.payloads().has(&payload).await.unwrap());
    }

    #[tokio::test]
    async fn collection_preserves_pinned_unpublished_payloads_and_individual_chunks() {
        use crate::metadata::{DataPin, DataPinLease, PinResource, PinScope};

        let repository = chunked_repository(1024);
        let mutation = repository.mutation_session().await.unwrap();
        let held = mutation.stage_blob(&[1; 4096]).await.unwrap();
        let held_payload = held.record().payload();
        let chunk_only = mutation.stage_blob(&[2; 4096]).await.unwrap();
        let chunk_payload = chunk_only.record().payload();
        let orphan = mutation.stage_blob(&[3; 4096]).await.unwrap();
        let orphan_payload = orphan.record().payload();
        // Leave all records unpublished: only the physical staging pins below
        // establish liveness, so this cannot pass through named-root marking.
        drop((held, chunk_only, orphan));
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        let held_chunk = repository
            .payloads()
            .chunks(&chunk_payload)
            .await
            .unwrap()
            .unwrap()[0]
            .digest;
        let absent = BlobId::new(Digest::hash(b"absent physical pin"));
        let ledger = repository.metadata().pin_store().await.unwrap();
        let pin = DataPinLease::acquire(
            ledger.clone(),
            DataPin {
                scope: PinScope::Staging,
                catalog: None,
                resources: BTreeSet::from([
                    PinResource::Blob(held_payload),
                    PinResource::Chunk(held_chunk),
                    PinResource::Blob(absent),
                ]),
            },
        )
        .await
        .unwrap();
        repository.collect().await.unwrap();
        assert_eq!(
            repository
                .payloads()
                .read_to_vec(&held_payload)
                .await
                .unwrap()
                .unwrap(),
            vec![1; 4096]
        );
        assert!(!repository.payloads().has(&orphan_payload).await.unwrap());
        let chunks: BTreeSet<_> = repository
            .payloads()
            .list_chunks()
            .try_collect()
            .await
            .unwrap();
        assert!(chunks.contains(&held_chunk));
        assert!(ledger.inventory().await.unwrap().deletions.is_empty());
        drop(pin);
        crate::flush_repository_leases().await.unwrap();
        repository.collect().await.unwrap();
        assert!(
            repository
                .payloads()
                .list_blobs()
                .try_collect::<Vec<_>>()
                .await
                .unwrap()
                .is_empty()
        );
        assert!(
            repository
                .payloads()
                .list_chunks()
                .try_collect::<Vec<_>>()
                .await
                .unwrap()
                .is_empty()
        );
    }

    #[tokio::test]
    async fn collection_keeps_chunks_shared_with_a_live_payload() {
        let repository = chunked_repository(1024);
        let common: Vec<u8> = (0..50_000).map(|index| (index % 251) as u8).collect();
        let mut live_bytes = common.clone();
        live_bytes.extend_from_slice(b"----live-suffix-AAAA");
        let mut orphan_bytes = common;
        orphan_bytes.extend_from_slice(b"----orphan-suffix-BBBB");

        let mutation = repository.mutation_session().await.unwrap();
        let live = mutation.stage_blob(&live_bytes).await.unwrap();
        let live_key = live.record().key().clone();
        let live_payload = live.record().payload();
        let orphan = mutation.stage_blob(&orphan_bytes).await.unwrap();
        let orphan_payload = orphan.record().payload();
        mutation
            .publish_rooted(
                vec![live, orphan],
                RootName::try_from("chunks/live").unwrap(),
                live_key,
            )
            .await
            .unwrap();
        drop(mutation);

        let live_chunks: BTreeSet<_> = repository
            .payloads()
            .chunks(&live_payload)
            .await
            .unwrap()
            .unwrap()
            .into_iter()
            .map(|chunk| chunk.digest)
            .collect();
        let orphan_chunks: BTreeSet<_> = repository
            .payloads()
            .chunks(&orphan_payload)
            .await
            .unwrap()
            .unwrap()
            .into_iter()
            .map(|chunk| chunk.digest)
            .collect();
        assert!(!live_chunks.is_disjoint(&orphan_chunks));
        let orphan_only: BTreeSet<_> = orphan_chunks.difference(&live_chunks).copied().collect();
        assert!(!orphan_only.is_empty());

        repository.collect().await.unwrap();
        assert_eq!(
            repository
                .payloads()
                .read_to_vec(&live_payload)
                .await
                .unwrap()
                .as_deref(),
            Some(live_bytes.as_slice())
        );
        assert!(!repository.payloads().has(&orphan_payload).await.unwrap());
        let remaining: BTreeSet<_> = repository
            .payloads()
            .list_chunks()
            .try_collect()
            .await
            .unwrap();
        assert!(live_chunks.is_subset(&remaining));
        assert!(orphan_only.is_disjoint(&remaining));
    }

    #[tokio::test]
    async fn reimport_after_collection_reuploads_swept_chunks() {
        let repository = chunked_repository(1024);
        let bytes = b"content that must survive a stale deduplication index";

        let mutation = repository.mutation_session().await.unwrap();
        let first = mutation.stage_blob(bytes).await.unwrap();
        let key = first.record().key().clone();
        let payload = first.record().payload();
        mutation.publish_unrooted(vec![first]).await.unwrap();
        drop(mutation);

        repository.collect().await.unwrap();
        assert!(!repository.payloads().has(&payload).await.unwrap());

        let mutation = repository.mutation_session().await.unwrap();
        let second = mutation.stage_blob(bytes).await.unwrap();
        assert_eq!(second.record().key(), &key);
        mutation
            .publish_rooted(
                vec![second],
                RootName::try_from("reimport/current").unwrap(),
                key,
            )
            .await
            .unwrap();
        drop(mutation);
        assert_eq!(
            repository.payloads().read_to_vec(&payload).await.unwrap(),
            Some(bytes.to_vec())
        );
    }

    #[tokio::test]
    async fn collection_with_no_roots_empties_storage_and_second_pass_is_a_noop() {
        let repository = chunked_repository(1024);
        let mutation = repository.mutation_session().await.unwrap();
        let first = mutation.stage_blob(b"first orphan").await.unwrap();
        let second = mutation.stage_blob(&vec![0xabu8; 16 * 1024]).await.unwrap();
        mutation
            .publish_unrooted(vec![first, second])
            .await
            .unwrap();
        drop(mutation);

        let first = repository.collect().await.unwrap();
        assert_eq!(first.removed.logical_objects, 2);
        assert_eq!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .objects()
                .try_collect::<Vec<_>>()
                .await
                .unwrap(),
            Vec::new()
        );
        assert!(
            repository
                .payloads()
                .list_blobs()
                .try_collect::<Vec<_>>()
                .await
                .unwrap()
                .is_empty()
        );
        assert!(
            repository
                .payloads()
                .list_chunks()
                .try_collect::<Vec<_>>()
                .await
                .unwrap()
                .is_empty()
        );

        let second = repository.collect().await.unwrap();
        assert_eq!(second.removed, CollectionPreview::default());
        assert_eq!(second.revision, None);
        assert!(repository.fsck().await.unwrap().is_clean());
    }

    #[tokio::test]
    async fn logical_prune_failure_never_starts_physical_deletion() {
        let fail_once = Arc::new(AtomicBool::new(false));
        let repository = Repository::new(
            MemoryBlobStore::new(),
            FailingCommitMetadataStore {
                inner: MemoryMetadataStore::new().unwrap(),
                fail_once: fail_once.clone(),
            },
        );
        let mutation = repository.mutation_session().await.unwrap();
        let orphan = mutation.stage_blob(b"survives failed prune").await.unwrap();
        let key = orphan.record().key().clone();
        let payload = orphan.record().payload();
        mutation.publish_unrooted(vec![orphan]).await.unwrap();
        drop(mutation);

        let before = repository.metadata().snapshot().await.unwrap().revision();
        fail_once.store(true, Ordering::SeqCst);
        assert!(matches!(
            repository.collect().await,
            Err(RepositoryError::Metadata(MetadataError::Backend(message)))
                if message.contains("injected failure")
        ));
        let after = repository.metadata().snapshot().await.unwrap();
        assert_eq!(after.revision(), before);
        assert!(after.object(&key).await.unwrap().is_some());
        assert!(repository.payloads().has(&payload).await.unwrap());

        repository.collect().await.unwrap();
        assert!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .object(&key)
                .await
                .unwrap()
                .is_none()
        );
        assert!(!repository.payloads().has(&payload).await.unwrap());
    }

    #[tokio::test]
    async fn local_emergency_collection_uses_stale_payload_as_commit_space() {
        let fail_once = Arc::new(AtomicBool::new(false));
        let mut repository = Repository::new(
            MemoryBlobStore::new(),
            StorageFullOnceMetadataStore {
                inner: MemoryMetadataStore::new().unwrap(),
                fail_once: fail_once.clone(),
            },
        );
        // The standard local profile sets this only because its state and
        // payload bytes are guaranteed to occupy the same filesystem.
        repository.emergency_collection = true;
        let mutation = repository.mutation_session().await.unwrap();
        let orphan = mutation
            .stage_blob(b"garbage funds the state retry")
            .await
            .unwrap();
        let key = orphan.record().key().clone();
        let payload = orphan.record().payload();
        mutation.publish_unrooted(vec![orphan]).await.unwrap();
        drop(mutation);

        fail_once.store(true, Ordering::SeqCst);
        let outcome = repository.collect().await.unwrap();
        assert_eq!(outcome.removed.logical_objects, 1);
        assert!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .object(&key)
                .await
                .unwrap()
                .is_none()
        );
        assert!(!repository.payloads().has(&payload).await.unwrap());
    }

    #[tokio::test]
    async fn generic_storage_full_does_not_assume_colocated_payload_capacity() {
        let fail_once = Arc::new(AtomicBool::new(false));
        let repository = Repository::new(
            MemoryBlobStore::new(),
            StorageFullOnceMetadataStore {
                inner: MemoryMetadataStore::new().unwrap(),
                fail_once: fail_once.clone(),
            },
        );
        let mutation = repository.mutation_session().await.unwrap();
        let orphan = mutation
            .stage_blob(b"custom backends may live on different devices")
            .await
            .unwrap();
        let key = orphan.record().key().clone();
        let payload = orphan.record().payload();
        mutation.publish_unrooted(vec![orphan]).await.unwrap();
        drop(mutation);

        fail_once.store(true, Ordering::SeqCst);
        assert!(matches!(
            repository.collect().await,
            Err(RepositoryError::Metadata(MetadataError::StorageFull))
        ));
        assert!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .object(&key)
                .await
                .unwrap()
                .is_some()
        );
        assert!(repository.payloads().has(&payload).await.unwrap());
    }

    #[tokio::test]
    async fn interrupted_emergency_sweep_is_collectible_and_retryable() {
        let failures = Arc::new(AtomicUsize::new(0));
        let mut repository = Repository::new(
            MemoryBlobStore::new(),
            InterruptedEmergencyMetadataStore {
                inner: MemoryMetadataStore::new().unwrap(),
                failures: failures.clone(),
            },
        );
        repository.emergency_collection = true;
        let mutation = repository.mutation_session().await.unwrap();
        let orphan = mutation
            .stage_blob(b"unreachable payload removed before interrupted retry")
            .await
            .unwrap();
        let key = orphan.record().key().clone();
        let payload = orphan.record().payload();
        mutation.publish_unrooted(vec![orphan]).await.unwrap();
        drop(mutation);

        failures.store(2, Ordering::SeqCst);
        assert!(matches!(
            repository.collect().await,
            Err(RepositoryError::Metadata(MetadataError::Backend(message)))
                if message.contains("after emergency sweep")
        ));
        assert!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .object(&key)
                .await
                .unwrap()
                .is_some()
        );
        assert!(!repository.payloads().has(&payload).await.unwrap());
        let ledger = repository.metadata().pin_store().await.unwrap();
        let interrupted = ledger.inventory().await.unwrap();
        assert!(
            interrupted.logical_prune.is_some(),
            "the emergency fence must survive a failed metadata retry"
        );
        assert!(interrupted.collector.is_some());
        assert!(!interrupted.deletions.is_empty());
        assert!(
            ledger
                .register(crate::metadata::DataPin {
                    scope: crate::metadata::PinScope::Staging,
                    catalog: None,
                    resources: BTreeSet::from([crate::metadata::PinResource::Object(key.clone())]),
                })
                .await
                .unwrap()
                .is_none(),
            "an old unrooted record cannot become a new root after its payload was swept"
        );
        assert!(matches!(
            repository.fsck().await,
            Err(RepositoryError::Busy(_))
        ));

        let plan = repository
            .collection_plan(
                repository.coordination.clone().lock_owned().await,
                None,
                true,
            )
            .await
            .unwrap();
        let remarking = ledger.inventory().await.unwrap();
        assert_eq!(
            remarking.logical_prune, interrupted.logical_prune,
            "recovery must not reopen admission while rebuilding its mark"
        );
        assert!(
            ledger
                .register(crate::metadata::DataPin {
                    scope: crate::metadata::PinScope::Snapshot {
                        generation: u64::MAX
                    },
                    catalog: None,
                    resources: BTreeSet::new(),
                })
                .await
                .unwrap()
                .is_none()
        );
        repository.execute_collection(plan, false).await.unwrap();
        assert!(repository.fsck().await.unwrap().is_clean());
        let recovered = ledger.inventory().await.unwrap();
        assert!(recovered.logical_prune.is_none());
        assert!(recovered.deletions.is_empty());
    }

    #[tokio::test]
    async fn missing_rooted_descendant_aborts_before_logical_prune() {
        let hidden = Arc::new(StdRwLock::new(None));
        let state = HiddenObjectMetadataStore {
            inner: MemoryMetadataStore::new().unwrap(),
            hidden: hidden.clone(),
        };
        let repository = Repository::with_formats(
            MemoryBlobStore::new(),
            state,
            FormatRegistry::new([Arc::new(SyntheticFormat::default()) as Arc<dyn ObjectFormat>])
                .unwrap(),
            FormatLimits::default(),
        );
        let mutation = repository.mutation_session().await.unwrap();
        let child = stage_graph(&mutation, 1, &[]).await;
        let child_key = child.record().key().clone();
        let root = stage_graph(&mutation, 2, &[1]).await;
        let root_key = root.record().key().clone();
        let orphan = stage_graph(&mutation, 3, &[]).await;
        let orphan_key = orphan.record().key().clone();
        mutation
            .publish_rooted(
                vec![child, root, orphan],
                RootName::try_from("corrupt/root").unwrap(),
                root_key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);

        let before = repository.metadata().snapshot().await.unwrap().revision();
        *hidden.write().unwrap() = Some(child_key);
        assert!(matches!(
            repository.collect().await,
            Err(RepositoryError::Metadata(MetadataError::Corruption(message)))
                if message.contains("links to missing")
        ));
        let after = repository.metadata().snapshot().await.unwrap();
        assert_eq!(after.revision(), before);
        assert!(after.object(&root_key).await.unwrap().is_some());
        assert!(after.object(&orphan_key).await.unwrap().is_some());

        *hidden.write().unwrap() = None;
        repository.collect().await.unwrap();
        assert!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .object(&orphan_key)
                .await
                .unwrap()
                .is_none()
        );
    }

    #[tokio::test]
    async fn physical_deletion_failure_leaks_after_safe_logical_prune() {
        let payloads = FailingDeleteStore {
            inner: MemoryBlobStore::new(),
        };
        let repository = Repository::new(payloads, MemoryMetadataStore::new().unwrap());
        let mutation = repository.mutation_session().await.unwrap();
        let orphan = mutation.stage_blob(b"leaked safely").await.unwrap();
        let key = orphan.record().key().clone();
        let payload = orphan.record().payload();
        mutation.publish_unrooted(vec![orphan]).await.unwrap();
        drop(mutation);

        assert!(matches!(
            repository.collect().await,
            Err(RepositoryError::Payload(crate::error::Error::Msg(_)))
        ));
        assert!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .object(&key)
                .await
                .unwrap()
                .is_none()
        );
        assert!(repository.payloads().has(&payload).await.unwrap());
        let ledger = repository.metadata().pin_store().await.unwrap();
        let inventory = ledger.inventory().await.unwrap();
        assert_eq!(inventory.deletions.len(), 1);
        assert!(
            inventory
                .deletions
                .values()
                .next()
                .unwrap()
                .contains(&crate::metadata::PinResource::Blob(payload))
        );
        assert!(
            ledger
                .register(crate::metadata::DataPin {
                    scope: crate::metadata::PinScope::Staging,
                    catalog: None,
                    resources: BTreeSet::from([crate::metadata::PinResource::Blob(payload)]),
                })
                .await
                .unwrap()
                .is_none()
        );
        assert!(
            matches!(repository.collect().await, Err(RepositoryError::Busy(message)) if message.contains("exact-token recovery"))
        );
        assert_eq!(
            ledger.inventory().await.unwrap().deletions,
            inventory.deletions
        );
        let healthy = Repository::new(
            repository.payloads().inner.clone(),
            repository.metadata().clone(),
        );
        healthy
            .recover_collection(inventory.collector.as_ref().unwrap())
            .await
            .unwrap();
        assert!(!healthy.payloads().has(&payload).await.unwrap());
        let recovered = ledger.inventory().await.unwrap();
        assert!(recovered.collector.is_none());
        assert!(recovered.deletions.is_empty());
    }

    #[tokio::test]
    async fn overlapping_roots_keep_shared_payload_until_the_last_release() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let shared = mutation.stage_blob(b"shared").await.unwrap();
        let key = shared.record().key().clone();
        let payload = shared.record().payload();
        mutation
            .publish(
                vec![shared],
                vec![
                    RootChange::Set {
                        name: "roots/a".parse().unwrap(),
                        target: key.clone(),
                    },
                    RootChange::Set {
                        name: "roots/b".parse().unwrap(),
                        target: key.clone(),
                    },
                ],
            )
            .await
            .unwrap();
        mutation
            .publish(
                Vec::new(),
                vec![RootChange::Remove {
                    name: "roots/a".parse().unwrap(),
                }],
            )
            .await
            .unwrap();
        drop(mutation);
        repository.collect().await.unwrap();
        assert!(repository.payloads().has(&payload).await.unwrap());

        repository
            .mutation_session()
            .await
            .unwrap()
            .publish(
                Vec::new(),
                vec![RootChange::Remove {
                    name: "roots/b".parse().unwrap(),
                }],
            )
            .await
            .unwrap();
        repository.collect().await.unwrap();
        assert!(!repository.payloads().has(&payload).await.unwrap());
    }

    #[tokio::test]
    async fn missing_rooted_payload_aborts_before_logical_prune() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let live = mutation.stage_blob(b"live").await.unwrap();
        let live_key = live.record().key().clone();
        let live_payload = live.record().payload();
        mutation
            .publish_rooted(
                vec![live],
                RootName::try_from("live").unwrap(),
                live_key.clone(),
            )
            .await
            .unwrap();
        drop(mutation);
        let before = repository.metadata().snapshot().await.unwrap().revision();
        repository
            .payloads()
            .delete_blob(&live_payload)
            .await
            .unwrap();
        assert!(matches!(
            repository.collect().await,
            Err(RepositoryError::Metadata(MetadataError::Corruption(_)))
        ));
        let after = repository.metadata().snapshot().await.unwrap();
        assert_eq!(after.revision(), before);
        assert!(after.object(&live_key).await.unwrap().is_some());
    }

    #[tokio::test]
    async fn fsck_distinguishes_corruption_from_collectible_staging() {
        let repository = repository();
        let mutation = repository.mutation_session().await.unwrap();
        let live = mutation.stage_blob(b"live").await.unwrap();
        let live_key = live.record().key().clone();
        let live_payload = live.record().payload();
        let orphan = mutation.stage_blob(b"orphan").await.unwrap();
        mutation
            .publish_rooted(
                vec![live, orphan],
                RootName::try_from("live").unwrap(),
                live_key,
            )
            .await
            .unwrap();
        drop(mutation);

        let report = repository.fsck().await.unwrap();
        assert!(report.is_healthy());
        assert!(!report.is_clean());
        assert!(report.issues.iter().any(|issue| {
            issue.kind == FsckIssueKind::UnrootedObject
                && issue.disposition == FsckDisposition::Collectible
        }));

        let spilled_repository = repository.clone().with_spill_limits(SpillLimits {
            max_memory_objects: 1,
            ..SpillLimits::default()
        });
        let mut spilled = spilled_repository.fsck().await.unwrap();
        assert!(spilled.spill.files_opened > 0);
        spilled.spill = report.spill;
        assert_eq!(spilled, report);

        repository
            .payloads()
            .delete_blob(&live_payload)
            .await
            .unwrap();
        let report = repository.fsck().await.unwrap();
        assert!(!report.is_healthy());
        assert!(report.issues.iter().any(|issue| {
            issue.kind == FsckIssueKind::MissingPayload
                && issue.disposition == FsckDisposition::Corrupt
        }));
        let mut spilled = spilled_repository.fsck().await.unwrap();
        assert!(spilled.spill.files_opened > 0);
        spilled.spill = report.spill;
        assert_eq!(spilled, report);
    }

    #[tokio::test]
    async fn fsck_batched_sets_preserve_shared_graphs_and_traversal_limits() {
        let source = tempfile::tempdir().unwrap();
        for group in 0..2 {
            let directory = source.path().join(format!("group-{group}"));
            std::fs::create_dir(&directory).unwrap();
            for index in 0u32..257 {
                std::fs::write(
                    directory.join(format!("{group}-{index}")),
                    index.to_le_bytes(),
                )
                .unwrap();
            }
        }
        let repository = repository();
        repository
            .import(crate::FilesystemImport::new(
                source.path(),
                RootName::try_from("shared").unwrap(),
            ))
            .await
            .unwrap();
        let expected = repository.fsck().await.unwrap();
        assert!(expected.is_clean());
        assert_eq!(expected.objects_checked, 260);
        for limit in [1, 17, 259, 260, 261, 1024] {
            let mut bounded = repository.clone().with_spill_limits(SpillLimits {
                max_memory_objects: limit,
                ..SpillLimits::default()
            });
            bounded.limits.max_traversal_objects = 260;
            let mut actual = bounded.fsck().await.unwrap();
            // Shared children appear twice in the queue even though sets
            // count them once. Its 514 pending edges also spill at 261.
            assert_eq!(actual.spill.files_opened > 0, limit <= 514);
            actual.spill = expected.spill;
            assert_eq!(actual, expected);
            bounded.limits.max_traversal_objects = 259;
            assert!(matches!(
                bounded.fsck().await,
                Err(RepositoryError::LimitExceeded(_))
            ));
        }
    }

    #[tokio::test]
    async fn fsck_inventory_difference_preserves_garbage_findings_across_spill_limits() {
        let repository = chunked_repository(1024);
        let mutation = repository.mutation_session().await.unwrap();
        let live = mutation.stage_blob(&vec![42; 4096]).await.unwrap();
        let live_key = live.record().key().clone();
        let live_payload = live.record().payload();
        let mut garbage = BTreeSet::new();
        for byte in 1..=4 {
            let staged = mutation.stage_blob(&vec![byte; 4096]).await.unwrap();
            garbage.insert(staged.record().payload());
        }
        mutation
            .publish_rooted(vec![live], RootName::try_from("live").unwrap(), live_key)
            .await
            .unwrap();
        drop(mutation);

        let live_chunks: BTreeSet<_> = repository
            .payloads()
            .chunks(&live_payload)
            .await
            .unwrap()
            .unwrap()
            .into_iter()
            .map(|chunk| chunk.digest)
            .collect();
        let all_chunks: BTreeSet<_> = repository
            .payloads()
            .list_chunks()
            .try_collect()
            .await
            .unwrap();
        let unused: Vec<_> = all_chunks.difference(&live_chunks).copied().collect();
        assert!(!unused.is_empty());
        let expected: Vec<_> = garbage
            .iter()
            .map(|payload| FsckIssue {
                disposition: FsckDisposition::Collectible,
                kind: FsckIssueKind::UnreferencedPayload,
                object: None,
                message: format!("physical payload {payload} has no logical record"),
            })
            .chain(unused.iter().map(|chunk| FsckIssue {
                disposition: FsckDisposition::Collectible,
                kind: FsckIssueKind::UnreferencedChunk,
                object: None,
                message: format!("physical chunk {chunk} has no logical payload"),
            }))
            .collect();
        let report = repository.fsck().await.unwrap();
        assert!(report.is_healthy());
        assert_eq!(report.payloads_checked, 1);
        assert_eq!(report.issues, expected);
        for max_memory_objects in [1, 2, 3] {
            let mut spilled = repository
                .clone()
                .with_spill_limits(SpillLimits {
                    max_memory_objects,
                    ..SpillLimits::default()
                })
                .fsck()
                .await
                .unwrap();
            assert!(spilled.spill.files_opened > 0);
            spilled.spill = report.spill;
            assert_eq!(spilled, report);
        }
    }

    #[tokio::test]
    async fn filesystem_import_checkout_and_reimport_preserve_identity() {
        let source = tempfile::tempdir().unwrap();
        std::fs::create_dir(source.path().join("sub")).unwrap();
        std::fs::create_dir(source.path().join("empty")).unwrap();
        std::fs::write(source.path().join("file.txt"), b"hello").unwrap();
        std::fs::write(source.path().join("sub/data.bin"), [7u8; 32]).unwrap();
        let executable = source.path().join("run.sh");
        std::fs::write(&executable, b"#!/bin/sh\n").unwrap();
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut permissions = std::fs::metadata(&executable).unwrap().permissions();
            permissions.set_mode(0o755);
            std::fs::set_permissions(&executable, permissions).unwrap();
            std::os::unix::fs::symlink("file.txt", source.path().join("link")).unwrap();
        }

        let repository = repository();
        let first = repository
            .import(crate::FilesystemImport::new(
                source.path(),
                RootName::try_from("trees/first").unwrap(),
            ))
            .await
            .unwrap();
        let output = tempfile::tempdir().unwrap();
        let target = output.path().join("tree");
        repository.checkout(&first, &target).await.unwrap();
        let second = repository
            .import(crate::FilesystemImport::new(
                &target,
                RootName::try_from("trees/second").unwrap(),
            ))
            .await
            .unwrap();
        assert_eq!(first, second);
        assert_eq!(std::fs::read(target.join("file.txt")).unwrap(), b"hello");
        assert!(target.join("empty").is_dir());
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            assert_ne!(
                std::fs::metadata(target.join("run.sh"))
                    .unwrap()
                    .permissions()
                    .mode()
                    & 0o100,
                0
            );
            assert_eq!(
                std::fs::read_link(target.join("link")).unwrap(),
                PathBuf::from("file.txt")
            );
        }
    }

    #[tokio::test]
    async fn slice_staging_verifies_native_identity_without_reopening_storage() {
        let reads = Arc::new(AtomicUsize::new(0));
        let repository = Repository::new(
            CountingBlobStore {
                inner: MemoryBlobStore::new(),
                reads: reads.clone(),
            },
            MemoryMetadataStore::new().unwrap(),
        );
        let bytes = b"native Git blob content";
        let key = crate::git::git_object_key_for_body(
            crate::GitObjectFormat::Sha256,
            crate::GitObjectKind::Blob,
            bytes,
        )
        .unwrap();
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation.stage_object(key.clone(), bytes).await.unwrap();
        assert_eq!(object.record().key(), &key);
        assert_eq!(object.record().payload_size(), bytes.len() as u64);
        assert_eq!(reads.load(Ordering::SeqCst), 0);
        assert!(
            mutation
                .stage_object(key.clone(), b"wrong content")
                .await
                .is_err()
        );
        let reread = mutation
            .stage_existing(key, object.record().payload())
            .await
            .unwrap();
        assert_eq!(reread.record(), object.record());
        assert_eq!(reads.load(Ordering::SeqCst), 1);

        let lying = Repository::new(
            LyingWriterStore {
                inner: MemoryBlobStore::new(),
                lie: WriterLie::Digest,
            },
            MemoryMetadataStore::new().unwrap(),
        );
        let mutation = lying.mutation_session().await.unwrap();
        assert!(matches!(
            mutation
                .stage_object(ObjectKey::blob(BlobId::new(Digest::hash(bytes))), bytes)
                .await,
            Err(RepositoryError::PayloadIdentityMismatch { .. })
        ));
    }

    #[tokio::test]
    async fn overwrite_publication_rejects_backend_digest_and_proof_lies() {
        for lie in [WriterLie::Digest, WriterLie::Size] {
            let inner = MemoryBlobStore::new();
            let original = vec![3; 40_000];
            let id = inner.put_slice(&original).await.unwrap();
            let repository = Repository::new(
                LyingWriterStore { inner, lie },
                MemoryMetadataStore::new().unwrap(),
            );
            let mutation = repository.mutation_session().await.unwrap();
            let staged = mutation
                .stage_existing(ObjectKey::blob(id), id)
                .await
                .unwrap();
            let name = RootName::try_from("file").unwrap();
            mutation
                .publish_rooted(vec![staged], name.clone(), ObjectKey::blob(id))
                .await
                .unwrap();
            assert!(
                mutation
                    .stage_blob_overwrite(&ObjectKey::blob(id), 16_380, &[42; 300])
                    .await
                    .is_err()
            );
            assert_eq!(
                repository
                    .metadata()
                    .snapshot()
                    .await
                    .unwrap()
                    .root(&name)
                    .await
                    .unwrap(),
                Some(ObjectKey::blob(id))
            );
        }
    }

    #[tokio::test]
    async fn filesystem_construction_proof_avoids_a_second_payload_walk() {
        let source = tempfile::tempdir().unwrap();
        std::fs::create_dir(source.path().join("nested")).unwrap();
        std::fs::create_dir(source.path().join("empty")).unwrap();
        std::fs::write(source.path().join("one"), b"one").unwrap();
        std::fs::write(source.path().join("nested/two"), b"two").unwrap();

        let reads = Arc::new(AtomicUsize::new(0));
        let repository = Repository::new(
            CountingBlobStore {
                inner: MemoryBlobStore::new(),
                reads: reads.clone(),
            },
            MemoryMetadataStore::new().unwrap(),
        );
        let root = repository
            .import(crate::FilesystemImport::new(
                source.path(),
                RootName::try_from("trees/constructed").unwrap(),
            ))
            .await
            .unwrap();

        // The content-addressed writers and canonical directory encodings
        // prove the five staged payloads without reopening them. Publication
        // must not read them or reopen child directories either.
        assert_eq!(reads.load(Ordering::SeqCst), 0);
        assert_eq!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .validated_closures(&[root])
                .await
                .unwrap(),
            vec![true]
        );
    }

    #[tokio::test]
    async fn raw_blob_fast_seal_rejects_dishonest_writer_completion() {
        for lie in [WriterLie::Digest, WriterLie::Size] {
            let repository = Repository::new(
                LyingWriterStore {
                    inner: MemoryBlobStore::new(),
                    lie,
                },
                MemoryMetadataStore::new().unwrap(),
            );
            let mutation = repository.mutation_session().await.unwrap();
            let mut source = b"independently observed source bytes".as_slice();
            let error = match mutation.stage_blob_reader(&mut source).await {
                Ok(_) => panic!("a dishonest writer completion must not produce a seal"),
                Err(error) => error,
            };
            match lie {
                WriterLie::Digest => {
                    assert!(matches!(
                        error,
                        RepositoryError::PayloadIdentityMismatch { .. }
                    ));
                }
                WriterLie::Size => {
                    assert!(matches!(error, RepositoryError::PayloadSizeMismatch { .. }));
                }
            }
            assert_eq!(error.category(), RepositoryErrorCategory::InvalidData);
            assert_eq!(error.retry_disposition(), crate::RetryDisposition::Never);
        }
    }

    #[tokio::test]
    async fn a_small_packed_import_performs_no_post_staging_range_reads() {
        let temporary = tempfile::tempdir().unwrap();
        let source = temporary.path().join("source");
        std::fs::create_dir_all(source.join("nested")).unwrap();
        std::fs::write(source.join("one"), b"one").unwrap();
        std::fs::write(source.join("nested/two"), b"two").unwrap();
        let repository = Repository::local(temporary.path().join("repository"))
            .await
            .unwrap();
        repository.payloads().reset_pack_read_stats();

        repository
            .import(crate::FilesystemImport::new(
                &source,
                RootName::try_from("trees/packed").unwrap(),
            ))
            .await
            .unwrap();

        let stats = repository.payloads().pack_read_stats().unwrap();
        assert_eq!(stats.chunk_range_requests, 0);
        assert_eq!(stats.whole_pack_requests, 0);
        assert_eq!(
            stats.index_pointer_requests, 0,
            "the state catalog must cover every negative payload probe"
        );
    }

    #[tokio::test]
    async fn packed_fsck_groups_reads_in_physical_order_under_cache_pressure() {
        let temporary = tempfile::tempdir().unwrap();
        let source = temporary.path().join("source");
        std::fs::create_dir(&source).unwrap();
        for index in 0..256_u32 {
            let mut bytes = Vec::with_capacity(1024);
            for block in 0..32_u32 {
                bytes.extend_from_slice(
                    blake3::hash(format!("fsck-{index}-{block}").as_bytes()).as_bytes(),
                );
            }
            std::fs::write(source.join(format!("file-{index:04}")), bytes).unwrap();
        }
        let payloads = ChunkedBlobStore::new_packed_with_cache(
            Arc::new(object_store::memory::InMemory::new()),
            object_store::path::Path::default(),
            crate::DEFAULT_AVG_CHUNK_SIZE,
            16 * 1024,
            32 * 1024,
        )
        .await
        .unwrap();
        let repository = Repository::new(payloads, MemoryMetadataStore::new().unwrap());
        repository
            .import(crate::FilesystemImport::new(
                &source,
                RootName::try_from("trees/fsck-order").unwrap(),
            ))
            .await
            .unwrap();
        repository.payloads().reset_pack_read_stats();

        assert!(repository.fsck_repair(None).await.unwrap().is_healthy());
        assert!(repository.fsck().await.unwrap().is_clean());

        let stats = repository.payloads().pack_read_stats().unwrap();
        assert!(
            stats.cache_evictions > 0,
            "fixture must exceed the pack cache"
        );
        assert!(
            stats.whole_pack_requests < 100,
            "physical ordering should prevent repeated pack reloads: {stats:?}"
        );
    }

    #[tokio::test]
    async fn a_failed_large_walk_leaves_only_bounded_durable_checkpoints() {
        let source = tempfile::tempdir().unwrap();
        for index in 0..1_100u32 {
            std::fs::write(
                source.path().join(format!("file-{index:05}")),
                format!("bounded-{index}"),
            )
            .unwrap();
        }
        let repository = Repository::with_formats(
            MemoryBlobStore::new(),
            MemoryMetadataStore::new().unwrap(),
            FormatRegistry::builtin(),
            FormatLimits {
                max_batch_objects: 256,
                // The first 1,024-entry page completes, then the second page
                // fails before it can be yielded to the importer.
                max_traversal_objects: 1_050,
                ..FormatLimits::default()
            },
        );

        assert!(
            repository
                .import(crate::FilesystemImport::new(
                    source.path(),
                    RootName::try_from("trees/too-wide").unwrap()
                ))
                .await
                .is_err()
        );
        let snapshot = repository.metadata().snapshot().await.unwrap();
        assert!(
            snapshot
                .root(&RootName::try_from("trees/too-wide").unwrap())
                .await
                .unwrap()
                .is_none(),
            "a partial import must never publish the final root"
        );
        assert_eq!(
            snapshot
                .objects()
                .try_collect::<Vec<_>>()
                .await
                .unwrap()
                .len(),
            crate::filesystem::WALK_PAGE_ENTRIES,
            "the completed page should survive as reusable bounded progress"
        );
    }

    #[tokio::test]
    async fn filesystem_construction_proof_survives_a_stale_revision_retry() {
        let source = tempfile::tempdir().unwrap();
        std::fs::write(source.path().join("file"), b"retry-safe").unwrap();
        let repository = Repository::new(
            MemoryBlobStore::new(),
            StaleOnceMetadataStore {
                inner: MemoryMetadataStore::new().unwrap(),
                stale_once: Arc::new(AtomicBool::new(true)),
            },
        );

        let root = repository
            .import(crate::FilesystemImport::new(
                source.path(),
                RootName::try_from("trees/retried").unwrap(),
            ))
            .await
            .unwrap();
        assert!(matches!(
            repository.verify_closure(&root).await.unwrap(),
            ClosureStatus::Complete { objects: 2 }
        ));
    }

    #[tokio::test]
    async fn generic_formats_cannot_claim_a_filesystem_construction_proof() {
        let repository = graph_repository();
        let mutation = repository.mutation_session().await.unwrap();
        let object = stage_graph(&mutation, 1, &[]).await;
        assert!(matches!(
            mutation
                .publish_filesystem_constructed(vec![object], Vec::new())
                .await,
            Err(RepositoryError::InvalidInput(message))
                if message.contains("filesystem construction proof")
        ));
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn ingest_cache_requires_a_validated_closure_witness() {
        let temporary = tempfile::tempdir().unwrap();
        let source = temporary.path().join("source");
        std::fs::create_dir(&source).unwrap();
        std::fs::write(source.join("file"), b"cached bytes").unwrap();
        let root = crate::fs_root::FsRoot::open_read(&source).await.unwrap();
        let identity = root
            .walk_post_order(8)
            .await
            .unwrap()
            .into_iter()
            .find_map(|entry| match entry {
                crate::fs_root::RootedEntry::File { identity, .. } => identity,
                _ => None,
            })
            .unwrap();

        let repository = Repository::local(temporary.path().join("repository"))
            .await
            .unwrap();
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation.stage_blob(b"cached bytes").await.unwrap();
        let key = object.record().key().clone();
        let digest = BlobId::new(key.native_digest().unwrap());
        mutation.publish_unrooted(vec![object]).await.unwrap();
        drop(mutation);
        repository
            .ingest_cache
            .as_ref()
            .unwrap()
            .remember(&[(identity, digest)])
            .await
            .unwrap();

        let mutation = repository.mutation_session().await.unwrap();
        assert_eq!(
            mutation
                .recognize_files(vec![Some(identity)])
                .await
                .unwrap(),
            vec![None],
            "an unrooted object without a closure witness must be reread"
        );
        mutation
            .publish_rooted(
                Vec::new(),
                RootName::try_from("blobs/validated").unwrap(),
                key,
            )
            .await
            .unwrap();
        drop(mutation);

        let mutation = repository.mutation_session().await.unwrap();
        let mut changed = identity;
        changed.ctime_nsec ^= 1;
        assert_eq!(
            mutation
                .recognize_files(vec![Some(identity), None, Some(changed), Some(identity)])
                .await
                .unwrap(),
            vec![
                Some((b"cached bytes".len() as u64, digest)),
                None,
                None,
                Some((b"cached bytes".len() as u64, digest)),
            ]
        );
        assert!(
            mutation
                .recognize_files(Vec::new())
                .await
                .unwrap()
                .is_empty()
        );
    }

    #[tokio::test]
    async fn reopen_and_fsck_recover_after_publication_commit_failure() {
        let temporary = tempfile::tempdir().unwrap();
        let store_root = temporary.path().join("store");
        let source = temporary.path().join("source");
        std::fs::create_dir(&source).unwrap();
        std::fs::write(source.join("data"), b"staged before crash").unwrap();

        let base = Repository::local(&store_root).await.unwrap();
        let repository = Repository::with_formats(
            base.payloads().clone(),
            FailingCommitMetadataStore {
                inner: base.metadata().clone(),
                fail_once: Arc::new(AtomicBool::new(true)),
            },
            FormatRegistry::builtin(),
            FormatLimits::default(),
        )
        .with_fs_coordination(&store_root);
        drop(base);
        assert!(matches!(
            repository
                .import(crate::FilesystemImport::new(&source, RootName::try_from("trees/interrupted").unwrap()))
                .await,
            Err(RepositoryError::Metadata(MetadataError::Backend(message)))
                if message.contains("injected failure")
        ));
        drop(repository);

        let reopened = Repository::local(&store_root).await.unwrap();
        let snapshot = reopened.metadata().snapshot().await.unwrap();
        assert!(
            snapshot
                .root(&RootName::try_from("trees/interrupted").unwrap())
                .await
                .unwrap()
                .is_none()
        );
        drop(snapshot);
        let report = reopened.fsck().await.unwrap();
        assert!(
            report.is_clean(),
            "uncommitted payloads are outside the catalog"
        );
        let packs = store_root.join("blobs/packs/b3");
        assert!(std::fs::read_dir(&packs).unwrap().any(|entry| {
            std::fs::read_dir(entry.unwrap().path())
                .unwrap()
                .next()
                .is_some()
        }));
        reopened.collect().await.unwrap();
        assert!(
            std::fs::read_dir(&packs).unwrap().all(|entry| {
                std::fs::read_dir(entry.unwrap().path())
                    .unwrap()
                    .next()
                    .is_none()
            }),
            "collection must remove abandoned uploads"
        );
        assert!(reopened.fsck().await.unwrap().is_clean());
    }

    #[tokio::test]
    async fn local_catalog_reclamation_runs_before_mutation_and_during_reopen() {
        fn install_garbage(root: &Path, seed: &[u8]) -> (PathBuf, PathBuf) {
            let digest = Digest::from(blake3::hash(seed)).to_hex();
            let object = root
                .join("blobs/pack-indexes/b3")
                .join(&digest[..2])
                .join(digest.as_str());
            std::fs::create_dir_all(object.parent().unwrap()).unwrap();
            std::fs::write(&object, b"unreachable catalog object").unwrap();
            let marker = root.join("blobs/pack-index-reclaim-needed");
            std::fs::write(&marker, b"catalog garbage may be present\n").unwrap();
            (object, marker)
        }

        let temporary = tempfile::tempdir().unwrap();
        let store_root = temporary.path().join("store");
        let repository = Repository::local(&store_root).await.unwrap();

        let (object, marker) = install_garbage(&store_root, b"live handle garbage");
        let mutation = repository.mutation_session().await.unwrap();
        assert!(!object.exists());
        assert!(!marker.exists());
        drop(mutation);
        drop(repository);

        let (object, marker) = install_garbage(&store_root, b"restart garbage");
        let reopened = Repository::local(&store_root).await.unwrap();
        assert!(!object.exists());
        assert!(!marker.exists());
        drop(reopened);

        let reader = Repository::local(&store_root).await.unwrap();
        let writer = Repository::local(&store_root).await.unwrap();
        let (object, marker) = install_garbage(&store_root, b"garbage unrelated to reader");
        let hold = reader.retention_hold().await.unwrap();
        let mutation = writer.mutation_session().await.unwrap();
        assert!(!object.exists());
        // The marker can remain while a reader's historical catalog is pinned.
        assert!(marker.exists());
        drop(mutation);
        drop(hold);

        let mutation = writer.mutation_session().await.unwrap();
        assert!(!object.exists());
        assert!(!marker.exists());
        drop(mutation);
    }

    #[tokio::test]
    async fn local_collection_recovers_an_interrupted_logical_prune_fence() {
        let directory = tempfile::tempdir().unwrap();
        let repository = Repository::local(directory.path()).await.unwrap();
        let mutation = repository.mutation_session().await.unwrap();
        let object = mutation.stage_blob(b"interrupted prune").await.unwrap();
        mutation.publish_unrooted(vec![object]).await.unwrap();
        drop(mutation);
        crate::flush_repository_leases().await.unwrap();
        let ledger = repository.metadata().pin_store().await.unwrap();
        ledger
            .begin_prune(ledger.inventory().await.unwrap().revision)
            .await
            .unwrap()
            .unwrap();
        let collected = repository.collect().await.unwrap();
        assert_eq!(collected.removed.logical_objects, 1);
        let inventory = ledger.inventory().await.unwrap();
        assert!(inventory.logical_prune.is_none());
        assert!(inventory.deletions.is_empty());
    }

    #[tokio::test]
    async fn reopen_and_fsck_recover_after_post_prune_sweep_failure() {
        let temporary = tempfile::tempdir().unwrap();
        let store_root = temporary.path().join("store");
        let object = {
            let repository = Repository::local(&store_root).await.unwrap();
            let mutation = repository.mutation_session().await.unwrap();
            let object = mutation.stage_blob(b"orphan before prune").await.unwrap();
            let key = object.record().key().clone();
            mutation.publish_unrooted(vec![object]).await.unwrap();
            key
        };

        let base = Repository::local(&store_root).await.unwrap();
        let repository = Repository::with_formats(
            FailingDeleteStore {
                inner: base.payloads().clone(),
            },
            base.metadata().clone(),
            FormatRegistry::builtin(),
            FormatLimits::default(),
        )
        .with_fs_coordination(&store_root);
        drop(base);
        assert!(matches!(
            repository.collect().await,
            Err(RepositoryError::Payload(crate::error::Error::Msg(message)))
                if message.contains("injected physical deletion failure")
        ));
        assert!(
            repository
                .metadata()
                .snapshot()
                .await
                .unwrap()
                .object(&object)
                .await
                .unwrap()
                .is_none()
        );
        drop(repository);

        let reopened = Repository::local(&store_root).await.unwrap();
        let report = reopened.fsck().await.unwrap();
        assert!(report.is_healthy());
        assert!(!report.is_clean());
        assert!(report.issues.iter().any(|issue| {
            matches!(
                issue.kind,
                FsckIssueKind::UnreferencedPayload | FsckIssueKind::UnreferencedChunk
            ) && issue.disposition == FsckDisposition::Collectible
        }));
        reopened.collect().await.unwrap();
        assert!(reopened.fsck().await.unwrap().is_clean());
    }

    #[tokio::test]
    async fn local_repository_reopens_generic_state_and_payloads() {
        let temporary = tempfile::tempdir().unwrap();
        let store_root = temporary.path().join("store");
        let source = temporary.path().join("source");
        std::fs::create_dir(&source).unwrap();
        std::fs::write(source.join("data"), b"persistent").unwrap();

        let root = {
            let repository = Repository::local(&store_root).await.unwrap();
            repository
                .import(crate::FilesystemImport::new(
                    &source,
                    RootName::try_from("trees/main").unwrap(),
                ))
                .await
                .unwrap()
        };

        let repository = Repository::local(&store_root).await.unwrap();
        assert!(matches!(
            repository.verify_closure(&root).await.unwrap(),
            ClosureStatus::Complete { .. }
        ));
        let snapshot = repository.metadata().snapshot().await.unwrap();
        assert_eq!(
            snapshot
                .root(&RootName::try_from("trees/main").unwrap())
                .await
                .unwrap(),
            Some(root)
        );
        drop(snapshot);
        assert!(repository.fsck().await.unwrap().is_clean());
    }

    #[cfg(target_os = "linux")]
    mod full_disk_crash {
        use std::fs::{File, OpenOptions};
        use std::io::{self, Write as _};
        use std::os::unix::process::ExitStatusExt as _;
        use std::path::{Path, PathBuf};
        use std::process::Command;

        use super::*;

        const NAMESPACE_ENV: &str = "CASITA_CRASH_GC_NAMESPACE_CHILD";
        const WORKER_ENV: &str = "CASITA_CRASH_GC_WORKER";
        const ROOT_ENV: &str = "CASITA_CRASH_GC_ROOT";
        const UNMOUNTED_TEST_NAME: &str = concat!(
            "repository::tests::full_disk_crash::",
            "local_emergency_sweep_recovers_after_abort_without_a_mount"
        );
        const TEST_NAME: &str = concat!(
            "repository::tests::full_disk_crash::",
            "local_emergency_sweep_recovers_after_real_process_abort"
        );

        /// The same crash and recovery as the filesystem-level test below,
        /// with the exhausted state engine stood in for rather than mounted.
        ///
        /// Everything that matters here is still real: a real local
        /// repository, a real payload sweep, a real process death at the
        /// emergency boundary, and a real reopen afterwards. Only the reason
        /// the commit could not proceed is injected, which is what lets this
        /// run on a machine that forbids unprivileged namespaces.
        #[test]
        fn local_emergency_sweep_recovers_after_abort_without_a_mount() {
            if std::env::var_os(WORKER_ENV).is_some() {
                let root = PathBuf::from(std::env::var_os(ROOT_ENV).unwrap());
                let runtime = runtime();
                runtime.block_on(async move {
                    let repository = Repository::local(root).await.unwrap();
                    let result = repository.collect().await;
                    panic!("emergency collection returned instead of aborting: {result:?}");
                });
                return;
            }

            for post_prune in [false, true] {
                let temporary = tempfile::tempdir().unwrap();
                let repository_root = temporary.path().join("repository");
                let runtime = runtime();
                let (rooted_key, rooted_payload, stale_key, stale_payload) =
                    runtime.block_on(prepare_repository(&repository_root));

                let worker = Command::new(std::env::current_exe().unwrap())
                    .args(["--exact", UNMOUNTED_TEST_NAME, "--nocapture"])
                    .env(WORKER_ENV, "1")
                    .env(ROOT_ENV, &repository_root)
                    .env(
                        if post_prune {
                            "CASITA_TEST_POST_PRUNE_STORAGE_FULL_ONCE"
                        } else {
                            "CASITA_TEST_STORAGE_FULL_ONCE"
                        },
                        "1",
                    )
                    .env("CASITA_TEST_ABORT_AFTER_EMERGENCY_SWEEP", "1")
                    .env_remove(NAMESPACE_ENV)
                    .output()
                    .expect("launch emergency collection worker");
                assert_eq!(
                    worker.status.signal(),
                    Some(libc::SIGABRT),
                    "worker did not abort at the emergency boundary: {worker:?}"
                );

                runtime.block_on(async move {
                    let repository = Repository::local(&repository_root).await.unwrap();
                    // The pre-prune failure leaves a stale logical record; the
                    // post-prune failure has already committed its removal.
                    let snapshot = repository.metadata().snapshot().await.unwrap();
                    assert_eq!(
                        snapshot.object(&stale_key).await.unwrap().is_some(),
                        !post_prune
                    );
                    drop(snapshot);
                    assert!(!repository.payloads().has(&stale_payload).await.unwrap());
                    assert!(repository.payloads().has(&rooted_payload).await.unwrap());
                    // The worker has stopped: verify the crash witness directly
                    // before recovery. Online scans must respect its abandoned fence.
                    let mut reader = repository
                        .payloads()
                        .open_read(&rooted_payload)
                        .await
                        .unwrap()
                        .unwrap();
                    let mut bytes = Vec::new();
                    reader.read_to_end(&mut bytes).await.unwrap();
                    assert_eq!(bytes, b"rooted crash witness");
                    drop(reader);
                    assert!(matches!(
                        repository.fsck().await,
                        Err(RepositoryError::Busy(_))
                    ));

                    let outcome = repository.collect().await.unwrap();
                    assert_eq!(outcome.removed.logical_objects, usize::from(!post_prune));
                    assert!(matches!(
                        repository.verify_closure(&rooted_key).await.unwrap(),
                        ClosureStatus::Complete { .. }
                    ));
                    assert!(repository.fsck().await.unwrap().is_clean());
                });
            }
        }

        #[test]
        fn local_emergency_sweep_recovers_after_real_process_abort() {
            if std::env::var_os(WORKER_ENV).is_some() {
                let root = PathBuf::from(std::env::var_os(ROOT_ENV).unwrap());
                let runtime = runtime();
                runtime.block_on(async move {
                    let repository = Repository::local(root).await.unwrap();
                    // The cfg(test) hook aborts after the stale physical set is
                    // gone and before the logical retry starts.
                    let result = repository.collect().await;
                    panic!("emergency collection returned instead of aborting: {result:?}");
                });
                return;
            }

            if std::env::var_os(NAMESPACE_ENV).is_some() {
                run_supervisor();
                return;
            }

            // A machine that refuses unprivileged namespaces is answering
            // about itself, not about casita. The recovery this proves is
            // covered without a mount by the test above; what only a real
            // filesystem can show is that a kernel ENOSPC arrives as
            // `StorageFull`, so this reports the gap instead of failing.
            if !mount_namespaces_available() {
                eprintln!(
                    "SKIP {TEST_NAME}: this machine does not permit unprivileged user and \
                     mount namespaces, so a full filesystem cannot be created to test against"
                );
                return;
            }

            let output = Command::new("unshare")
                .args(["--user", "--map-root-user", "--mount"])
                .arg(std::env::current_exe().unwrap())
                .args(["--exact", TEST_NAME, "--nocapture"])
                .env(NAMESPACE_ENV, "1")
                .env_remove(WORKER_ENV)
                .output()
                .expect("launch crash recovery test in an unprivileged mount namespace");
            assert!(
                output.status.success(),
                "crash recovery supervisor failed\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr),
            );
        }

        /// Whether this machine lets an unprivileged process create the user
        /// and mount namespaces a real full filesystem needs.
        fn mount_namespaces_available() -> bool {
            Command::new("unshare")
                .args(["--user", "--map-root-user", "--mount", "true"])
                .output()
                .map(|probe| probe.status.success())
                .unwrap_or(false)
        }

        fn run_supervisor() {
            let filesystem = MountedTmpfs::new(64 * 1024 * 1024);
            let repository_root = filesystem.path().join("repository");
            let runtime = runtime();
            let (rooted_key, rooted_payload, stale_key, stale_payload) =
                runtime.block_on(prepare_repository(&repository_root));

            let probe_path = filesystem.path().join("enospc-probe");
            File::create(&probe_path).unwrap();
            let mut filler = File::create(filesystem.path().join("filler")).unwrap();
            let block = vec![0xa5; 1024 * 1024];
            assert_enospc(&fill(&mut filler, &block));
            assert_eq!(free_space(filesystem.path()), 0);
            let mut probe = OpenOptions::new().write(true).open(&probe_path).unwrap();
            assert_enospc(&probe.write_all(&[0x5a; 4096]).unwrap_err());
            drop(probe);

            let worker = Command::new(std::env::current_exe().unwrap())
                .args(["--exact", TEST_NAME, "--nocapture"])
                .env(NAMESPACE_ENV, "1")
                .env(WORKER_ENV, "1")
                .env(ROOT_ENV, &repository_root)
                .env("CASITA_TEST_ABORT_AFTER_EMERGENCY_SWEEP", "1")
                .output()
                .expect("launch emergency collection worker");
            assert_eq!(
                worker.status.signal(),
                Some(libc::SIGABRT),
                "worker did not abort at the emergency boundary: {worker:?}"
            );

            runtime.block_on(async move {
                let repository = Repository::local(&repository_root).await.unwrap();
                let snapshot = repository.metadata().snapshot().await.unwrap();
                // Reused WAL space may let the logical prune commit before the
                // physical allocation fails. Both orders must recover safely.
                let remaining_logical =
                    usize::from(snapshot.object(&stale_key).await.unwrap().is_some());
                drop(snapshot);
                assert!(!repository.payloads().has(&stale_payload).await.unwrap());
                assert!(repository.payloads().has(&rooted_payload).await.unwrap());
                // The worker has stopped: verify the crash witness directly
                // before recovery. Online scans must respect its abandoned fence.
                let mut reader = repository
                    .payloads()
                    .open_read(&rooted_payload)
                    .await
                    .unwrap()
                    .unwrap();
                let mut bytes = Vec::new();
                reader.read_to_end(&mut bytes).await.unwrap();
                assert_eq!(bytes, b"rooted crash witness");
                drop(reader);
                assert!(matches!(
                    repository.fsck().await,
                    Err(RepositoryError::Busy(_))
                ));

                let outcome = repository.collect().await.unwrap();
                assert_eq!(outcome.removed.logical_objects, remaining_logical);
                assert!(repository.fsck().await.unwrap().is_clean());
                assert!(matches!(
                    repository.verify_closure(&rooted_key).await.unwrap(),
                    ClosureStatus::Complete { .. }
                ));
            });
            drop(filler);
        }

        async fn prepare_repository(root: &Path) -> (ObjectKey, BlobId, ObjectKey, BlobId) {
            let repository = Repository::local(root).await.unwrap();
            let mutation = repository.mutation_session().await.unwrap();
            let rooted = mutation.stage_blob(b"rooted crash witness").await.unwrap();
            let rooted_key = rooted.record().key().clone();
            let rooted_payload = rooted.record().payload();
            mutation
                .publish_rooted(
                    vec![rooted],
                    RootName::try_from("full-disk/crash-live").unwrap(),
                    rooted_key.clone(),
                )
                .await
                .unwrap();

            let stale_bytes = deterministic_bytes(12 * 1024 * 1024);
            let stale = mutation.stage_blob(&stale_bytes).await.unwrap();
            let stale_key = stale.record().key().clone();
            let stale_payload = stale.record().payload();
            mutation.publish_unrooted(vec![stale]).await.unwrap();
            drop(mutation);
            drop(repository);
            // The supervisor stops driving this current-thread runtime while
            // its child collects. Finish the setup operation's durable release
            // before that handoff; a paused owner is still a live pin owner.
            crate::flush_repository_leases().await.unwrap();
            (rooted_key, rooted_payload, stale_key, stale_payload)
        }

        fn runtime() -> tokio::runtime::Runtime {
            tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
                .unwrap()
        }

        fn fill(file: &mut File, block: &[u8]) -> io::Error {
            loop {
                match file.write(block) {
                    Ok(0) => panic!("filler made no progress before ENOSPC"),
                    Ok(_) => {}
                    Err(error) => return error,
                }
            }
        }

        fn assert_enospc(error: &io::Error) {
            assert_eq!(error.raw_os_error(), Some(libc::ENOSPC));
        }

        fn free_space(path: &Path) -> u64 {
            fs4::statvfs(path).unwrap().free_space()
        }

        fn deterministic_bytes(len: usize) -> Vec<u8> {
            let mut state = 0x4d59_5df4_d0f3_3173u64;
            (0..len)
                .map(|_| {
                    state ^= state << 13;
                    state ^= state >> 7;
                    state ^= state << 17;
                    state as u8
                })
                .collect()
        }

        struct MountedTmpfs {
            directory: tempfile::TempDir,
            path: PathBuf,
        }

        impl MountedTmpfs {
            fn new(bytes: u64) -> Self {
                let directory = tempfile::tempdir().unwrap();
                let path = directory.path().to_path_buf();
                let status = Command::new("mount")
                    .args(["-t", "tmpfs", "-o"])
                    .arg(format!("size={bytes},nr_inodes=16384"))
                    .arg("tmpfs")
                    .arg(&path)
                    .status()
                    .expect("execute mount");
                assert!(status.success(), "mount tmpfs failed: {status}");
                Self { directory, path }
            }

            fn path(&self) -> &Path {
                &self.path
            }
        }

        impl Drop for MountedTmpfs {
            fn drop(&mut self) {
                let status = Command::new("umount")
                    .args(["--lazy"])
                    .arg(&self.path)
                    .status();
                if !std::thread::panicking() && !matches!(status, Ok(status) if status.success()) {
                    panic!("unmount tmpfs failed: {status:?}");
                }
                let _ = &self.directory;
            }
        }
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn cancelling_after_a_spill_opens_removes_its_temporary_files() {
        let temp = tempfile::tempdir().unwrap();
        let source = temp.path().join("source");
        for group in 0..8 {
            let directory = source.join(format!("group-{group}"));
            std::fs::create_dir_all(&directory).unwrap();
            for entry in 0..8 {
                std::fs::write(
                    directory.join(format!("entry-{entry}")),
                    format!("{group}/{entry}"),
                )
                .unwrap();
            }
        }
        let root = temp.path().join("repository");
        let repository =
            std::sync::Arc::new(Repository::local(&root).await.unwrap().with_spill_limits(
                SpillLimits {
                    max_memory_objects: 4,
                    max_spill_bytes: 64 * 1024 * 1024,
                },
            ));
        let imported = repository
            .import(crate::FilesystemImport::new(
                &source,
                RootName::try_from("test/cancelled").unwrap(),
            ))
            .await
            .unwrap();

        let spill_directory = root.join(crate::spill::SPILL_DIRECTORY);
        for check_fsck in [false, true] {
            let pause = crate::spill::SpillOpenPauseHandle::install(&spill_directory);
            let verification = tokio::spawn({
                let repository = repository.clone();
                let imported = imported.clone();
                async move {
                    if check_fsck {
                        repository.fsck().await.map(|_| ())
                    } else {
                        repository.verify_closure(&imported).await.map(|_| ())
                    }
                }
            });
            let opened = pause.wait_until_open();
            assert!(
                opened.starts_with(&spill_directory) && opened.exists(),
                "the pause must happen after a spill database exists"
            );

            verification.abort();
            pause.resume();
            assert!(verification.await.unwrap_err().is_cancelled());
            assert!(
                std::fs::read_dir(root.join(crate::spill::SPILL_DIRECTORY))
                    .unwrap()
                    .next()
                    .is_none(),
                "cancelling after spill open leaked temporary state"
            );
        }
    }

    proptest! {
        #![proptest_config(ProptestConfig { cases: 64, ..ProptestConfig::default() })]

        #[test]
        fn generic_collection_matches_an_independent_reachability_model(
            mut operations in prop::collection::vec(gc_model_strategy(), 1..32)
        ) {
            operations.push(GcModelOperation::Collect);
            let runtime = tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
                .unwrap();
            let outcome = runtime.block_on(run_gc_model(&operations));
            prop_assert!(outcome.is_ok(), "{}", outcome.unwrap_err());
        }
    }
}
